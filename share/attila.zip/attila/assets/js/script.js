!function (e, t) {
    "use strict";
    "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function (e) {
        if (e.document)
            return t(e);
        throw new Error("jQuery requires a window with a document")
    }
     : t(e)
}
("undefined" != typeof window ? window : this, function (w, B) {
    "use strict";
    function y(e) {
        return "function" == typeof e && "number" != typeof e.nodeType
    }
    function h(e) {
        return null != e && e === e.window
    }
    var t = [],
    j = Object.getPrototypeOf,
    o = t.slice,
    $ = t.flat ? function (e) {
        return t.flat.call(e)
    }
     : function (e) {
        return t.concat.apply([], e)
    },
    F = t.push,
    P = t.indexOf,
    q = {},
    z = q.toString,
    H = q.hasOwnProperty,
    U = H.toString,
    K = U.call(Object),
    m = {},
    x = w.document,
    W = {
        type: !0,
        src: !0,
        nonce: !0,
        noModule: !0
    };
    function G(e, t, n) {
        var r,
        i,
        a = (n = n || x).createElement("script");
        if (a.text = e, t)
            for (r in W)
                (i = t[r] || t.getAttribute && t.getAttribute(r)) && a.setAttribute(r, i);
        n.head.appendChild(a).parentNode.removeChild(a)
    }
    function f(e) {
        return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? q[z.call(e)] || "object" : typeof e
    }
    var e = "3.5.0",
    N = function (e, t) {
        return new N.fn.init(e, t)
    };
    function Z(e) {
        var t = !!e && "length" in e && e.length,
        n = f(e);
        return !y(e) && !h(e) && ("array" === n || 0 === t || "number" == typeof t && 0 < t && t - 1 in e)
    }
    N.fn = N.prototype = {
        jquery: e,
        constructor: N,
        length: 0,
        toArray: function () {
            return o.call(this)
        },
        get: function (e) {
            return null == e ? o.call(this) : e < 0 ? this[e + this.length] : this[e]
        },
        pushStack: function (e) {
            e = N.merge(this.constructor(), e);
            return e.prevObject = this,
            e
        },
        each: function (e) {
            return N.each(this, e)
        },
        map: function (n) {
            return this.pushStack(N.map(this, function (e, t) {
                    return n.call(e, t, e)
                }))
        },
        slice: function () {
            return this.pushStack(o.apply(this, arguments))
        },
        first: function () {
            return this.eq(0)
        },
        last: function () {
            return this.eq(-1)
        },
        even: function () {
            return this.pushStack(N.grep(this, function (e, t) {
                    return (t + 1) % 2
                }))
        },
        odd: function () {
            return this.pushStack(N.grep(this, function (e, t) {
                    return t % 2
                }))
        },
        eq: function (e) {
            var t = this.length,
            e = +e + (e < 0 ? t : 0);
            return this.pushStack(0 <= e && e < t ? [this[e]] : [])
        },
        end: function () {
            return this.prevObject || this.constructor()
        },
        push: F,
        sort: t.sort,
        splice: t.splice
    },
    N.extend = N.fn.extend = function () {
        var e,
        t,
        n,
        r,
        i,
        a = arguments[0] || {},
        s = 1,
        o = arguments.length,
        l = !1;
        for ("boolean" == typeof a && (l = a, a = arguments[s] || {}, s++), "object" == typeof a || y(a) || (a = {}), s === o && (a = this, s--); s < o; s++)
            if (null != (e = arguments[s]))
                for (t in e)
                    n = e[t], "__proto__" !== t && a !== n && (l && n && (N.isPlainObject(n) || (r = Array.isArray(n))) ? (i = a[t], i = r && !Array.isArray(i) ? [] : r || N.isPlainObject(i) ? i : {}, r = !1, a[t] = N.extend(l, i, n)) : void 0 !== n && (a[t] = n));
        return a
    },
    N.extend({
        expando: "jQuery" + (e + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function (e) {
            throw new Error(e)
        },
        noop: function () {},
        isPlainObject: function (e) {
            return !(!e || "[object Object]" !== z.call(e) || (e = j(e)) && ("function" != typeof(e = H.call(e, "constructor") && e.constructor) || U.call(e) !== K))
        },
        isEmptyObject: function (e) {
            for (var t in e)
                return !1;
            return !0
        },
        globalEval: function (e, t, n) {
            G(e, {
                nonce: t && t.nonce
            }, n)
        },
        each: function (e, t) {
            var n,
            r = 0;
            if (Z(e))
                for (n = e.length; r < n && !1 !== t.call(e[r], r, e[r]); r++);
            else
                for (r in e)
                    if (!1 === t.call(e[r], r, e[r]))
                        break;
            return e
        },
        makeArray: function (e, t) {
            t = t || [];
            return null != e && (Z(Object(e)) ? N.merge(t, "string" == typeof e ? [e] : e) : F.call(t, e)),
            t
        },
        inArray: function (e, t, n) {
            return null == t ? -1 : P.call(t, e, n)
        },
        merge: function (e, t) {
            for (var n = +t.length, r = 0, i = e.length; r < n; r++)
                e[i++] = t[r];
            return e.length = i,
            e
        },
        grep: function (e, t, n) {
            for (var r = [], i = 0, a = e.length, s = !n; i < a; i++)
                !t(e[i], i) != s && r.push(e[i]);
            return r
        },
        map: function (e, t, n) {
            var r,
            i,
            a = 0,
            s = [];
            if (Z(e))
                for (r = e.length; a < r; a++)
                    null != (i = t(e[a], a, n)) && s.push(i);
            else
                for (a in e)
                    null != (i = t(e[a], a, n)) && s.push(i);
            return $(s)
        },
        guid: 1,
        support: m
    }),
    "function" == typeof Symbol && (N.fn[Symbol.iterator] = t[Symbol.iterator]),
    N.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) {
        q["[object " + t + "]"] = t.toLowerCase()
    });
    function r(e, t, n) {
        for (var r = [], i = void 0 !== n; (e = e[t]) && 9 !== e.nodeType; )
            if (1 === e.nodeType) {
                if (i && N(e).is(n))
                    break;
                r.push(e)
            }
        return r
    }
    function X(e, t) {
        for (var n = []; e; e = e.nextSibling)
            1 === e.nodeType && e !== t && n.push(e);
        return n
    }
    var e = function (B) {
        function d(e, t) {
            return e = "0x" + e.slice(1) - 65536,
            t || (e < 0 ? String.fromCharCode(65536 + e) : String.fromCharCode(e >> 10 | 55296, 1023 & e | 56320))
        }
        function j(e, t) {
            return t ? "\0" === e ? "�" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e
        }
        function $() {
            w()
        }
        var e,
        p,
        _,
        a,
        F,
        g,
        P,
        q,
        E,
        l,
        c,
        w,
        x,
        n,
        N,
        f,
        r,
        i,
        h,
        k = "sizzle" + +new Date,
        u = B.document,
        C = 0,
        z = 0,
        H = M(),
        U = M(),
        K = M(),
        m = M(),
        W = function (e, t) {
            return e === t && (c = !0),
            0
        },
        G = {}
        .hasOwnProperty,
        t = [],
        Z = t.pop,
        X = t.push,
        S = t.push,
        Q = t.slice,
        y = function (e, t) {
            for (var n = 0, r = e.length; n < r; n++)
                if (e[n] === t)
                    return n;
            return -1
        },
        V = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
        s = "[\\x20\\t\\r\\n\\f]",
        o = "(?:\\\\[\\da-fA-F]{1,6}" + s + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+",
        J = "\\[" + s + "*(" + o + ")(?:" + s + "*([*^$|!~]?=)" + s + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + o + "))|)" + s + "*\\]",
        Y = ":(" + o + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + J + ")*)|.*)\\)|)",
        ee = new RegExp(s + "+", "g"),
        b = new RegExp("^" + s + "+|((?:^|[^\\\\])(?:\\\\.)*)" + s + "+$", "g"),
        te = new RegExp("^" + s + "*," + s + "*"),
        ne = new RegExp("^" + s + "*([>+~]|" + s + ")" + s + "*"),
        re = new RegExp(s + "|>"),
        ie = new RegExp(Y),
        ae = new RegExp("^" + o + "$"),
        v = {
            ID: new RegExp("^#(" + o + ")"),
            CLASS: new RegExp("^\\.(" + o + ")"),
            TAG: new RegExp("^(" + o + "|[*])"),
            ATTR: new RegExp("^" + J),
            PSEUDO: new RegExp("^" + Y),
            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + s + "*(even|odd|(([+-]|)(\\d*)n|)" + s + "*(?:([+-]|)" + s + "*(\\d+)|))" + s + "*\\)|)", "i"),
            bool: new RegExp("^(?:" + V + ")$", "i"),
            needsContext: new RegExp("^" + s + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + s + "*((?:-\\d)?\\d*)" + s + "*\\)|)(?=[^-]|$)", "i")
        },
        se = /HTML$/i,
        oe = /^(?:input|select|textarea|button)$/i,
        le = /^h\d$/i,
        T = /^[^{]+\{\s*\[native \w/,
        ce = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
        ue = /[+~]/,
        A = new RegExp("\\\\[\\da-fA-F]{1,6}" + s + "?|\\\\([^\\r\\n\\f])", "g"),
        de = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
        pe = ye(function (e) {
            return !0 === e.disabled && "fieldset" === e.nodeName.toLowerCase()
        }, {
            dir: "parentNode",
            next: "legend"
        });
        try {
            S.apply(t = Q.call(u.childNodes), u.childNodes),
            t[u.childNodes.length].nodeType
        } catch (e) {
            S = {
                apply: t.length ? function (e, t) {
                    X.apply(e, Q.call(t))
                }
                 : function (e, t) {
                    for (var n = e.length, r = 0; e[n++] = t[r++]; );
                    e.length = n - 1
                }
            }
        }
        function O(e, t, n, r) {
            var i,
            a,
            s,
            o,
            l,
            c,
            u = t && t.ownerDocument,
            d = t ? t.nodeType : 9;
            if (n = n || [], "string" != typeof e || !e || 1 !== d && 9 !== d && 11 !== d)
                return n;
            if (!r && (w(t), t = t || x, N)) {
                if (11 !== d && (o = ce.exec(e)))
                    if (i = o[1]) {
                        if (9 === d) {
                            if (!(c = t.getElementById(i)))
                                return n;
                            if (c.id === i)
                                return n.push(c), n
                        } else if (u && (c = u.getElementById(i)) && h(t, c) && c.id === i)
                            return n.push(c), n
                    } else {
                        if (o[2])
                            return S.apply(n, t.getElementsByTagName(e)), n;
                        if ((i = o[3]) && p.getElementsByClassName && t.getElementsByClassName)
                            return S.apply(n, t.getElementsByClassName(i)), n
                    }
                if (p.qsa && !m[e + " "] && (!f || !f.test(e)) && (1 !== d || "object" !== t.nodeName.toLowerCase())) {
                    if (c = e, u = t, 1 === d && (re.test(e) || ne.test(e))) {
                        for ((u = ue.test(e) && me(t.parentNode) || t) === t && p.scope || ((s = t.getAttribute("id")) ? s = s.replace(de, j) : t.setAttribute("id", s = k)), a = (l = g(e)).length; a--; )
                            l[a] = (s ? "#" + s : ":scope") + " " + L(l[a]);
                        c = l.join(",")
                    }
                    try {
                        return S.apply(n, u.querySelectorAll(c)),
                        n
                    } catch (t) {
                        m(e, !0)
                    } finally {
                        s === k && t.removeAttribute("id")
                    }
                }
            }
            return q(e.replace(b, "$1"), t, n, r)
        }
        function M() {
            var r = [];
            return function e(t, n) {
                return r.push(t + " ") > _.cacheLength && delete e[r.shift()],
                e[t + " "] = n
            }
        }
        function D(e) {
            return e[k] = !0,
            e
        }
        function R(e) {
            var t = x.createElement("fieldset");
            try {
                return !!e(t)
            } catch (e) {
                return !1
            } finally {
                t.parentNode && t.parentNode.removeChild(t)
            }
        }
        function ge(e, t) {
            for (var n = e.split("|"), r = n.length; r--; )
                _.attrHandle[n[r]] = t
        }
        function fe(e, t) {
            var n = t && e,
            r = n && 1 === e.nodeType && 1 === t.nodeType && e.sourceIndex - t.sourceIndex;
            if (r)
                return r;
            if (n)
                for (; n = n.nextSibling; )
                    if (n === t)
                        return -1;
            return e ? 1 : -1
        }
        function he(t) {
            return function (e) {
                return "form" in e ? e.parentNode && !1 === e.disabled ? "label" in e ? "label" in e.parentNode ? e.parentNode.disabled === t : e.disabled === t : e.isDisabled === t || e.isDisabled !== !t && pe(e) === t : e.disabled === t : "label" in e && e.disabled === t
            }
        }
        function I(s) {
            return D(function (a) {
                return a = +a,
                D(function (e, t) {
                    for (var n, r = s([], e.length, a), i = r.length; i--; )
                        e[n = r[i]] && (e[n] = !(t[n] = e[n]))
                })
            })
        }
        function me(e) {
            return e && void 0 !== e.getElementsByTagName && e
        }
        for (e in p = O.support = {}, F = O.isXML = function (e) {
            var t = e.namespaceURI,
            e = (e.ownerDocument || e).documentElement;
            return !se.test(t || e && e.nodeName || "HTML")
        }, w = O.setDocument = function (e) {
            var e = e ? e.ownerDocument || e : u;
            return e != x && 9 === e.nodeType && e.documentElement && (n = (x = e).documentElement, N = !F(x), u != x && (e = x.defaultView) && e.top !== e && (e.addEventListener ? e.addEventListener("unload", $, !1) : e.attachEvent && e.attachEvent("onunload", $)), p.scope = R(function (e) {
                    return n.appendChild(e).appendChild(x.createElement("div")),
                    void 0 !== e.querySelectorAll && !e.querySelectorAll(":scope fieldset div").length
                }), p.attributes = R(function (e) {
                    return e.className = "i",
                    !e.getAttribute("className")
                }), p.getElementsByTagName = R(function (e) {
                    return e.appendChild(x.createComment("")),
                    !e.getElementsByTagName("*").length
                }), p.getElementsByClassName = T.test(x.getElementsByClassName), p.getById = R(function (e) {
                    return n.appendChild(e).id = k,
                    !x.getElementsByName || !x.getElementsByName(k).length
                }), p.getById ? (_.filter.ID = function (e) {
                    var t = e.replace(A, d);
                    return function (e) {
                        return e.getAttribute("id") === t
                    }
                }, _.find.ID = function (e, t) {
                    if (void 0 !== t.getElementById && N)
                        return (t = t.getElementById(e))
                             ? [t] : []
                    }) : (_.filter.ID = function (e) {
                        var t = e.replace(A, d);
                        return function (e) {
                            e = void 0 !== e.getAttributeNode && e.getAttributeNode("id");
                            return e && e.value === t
                        }
                    }, _.find.ID = function (e, t) {
                        if (void 0 !== t.getElementById && N) {
                            var n,
                            r,
                            i,
                            a = t.getElementById(e);
                            if (a) {
                                if ((n = a.getAttributeNode("id")) && n.value === e)
                                    return [a];
                                for (i = t.getElementsByName(e), r = 0; a = i[r++]; )
                                    if ((n = a.getAttributeNode("id")) && n.value === e)
                                        return [a]
                            }
                            return []
                        }
                    }), _.find.TAG = p.getElementsByTagName ? function (e, t) {
                    return void 0 !== t.getElementsByTagName ? t.getElementsByTagName(e) : p.qsa ? t.querySelectorAll(e) : void 0
                }
                     : function (e, t) {
                    var n,
                    r = [],
                    i = 0,
                    a = t.getElementsByTagName(e);
                    if ("*" !== e)
                        return a;
                    for (; n = a[i++]; )
                        1 === n.nodeType && r.push(n);
                    return r
                }, _.find.CLASS = p.getElementsByClassName && function (e, t) {
                    if (void 0 !== t.getElementsByClassName && N)
                        return t.getElementsByClassName(e)
                }, r = [], f = [], (p.qsa = T.test(x.querySelectorAll)) && (R(function (e) {
                            var t;
                            n.appendChild(e).innerHTML = "<a id='" + k + "'></a><select id='" + k + "-\r\\' msallowcapture=''><option selected=''></option></select>",
                            e.querySelectorAll("[msallowcapture^='']").length && f.push("[*^$]=" + s + "*(?:''|\"\")"),
                            e.querySelectorAll("[selected]").length || f.push("\\[" + s + "*(?:value|" + V + ")"),
                            e.querySelectorAll("[id~=" + k + "-]").length || f.push("~="),
                            (t = x.createElement("input")).setAttribute("name", ""),
                            e.appendChild(t),
                            e.querySelectorAll("[name='']").length || f.push("\\[" + s + "*name" + s + "*=" + s + "*(?:''|\"\")"),
                            e.querySelectorAll(":checked").length || f.push(":checked"),
                            e.querySelectorAll("a#" + k + "+*").length || f.push(".#.+[+~]"),
                            e.querySelectorAll("\\\f"),
                            f.push("[\\r\\n\\f]")
                        }), R(function (e) {
                            e.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
                            var t = x.createElement("input");
                            t.setAttribute("type", "hidden"),
                            e.appendChild(t).setAttribute("name", "D"),
                            e.querySelectorAll("[name=d]").length && f.push("name" + s + "*[*^$|!~]?="),
                            2 !== e.querySelectorAll(":enabled").length && f.push(":enabled", ":disabled"),
                            n.appendChild(e).disabled = !0,
                            2 !== e.querySelectorAll(":disabled").length && f.push(":enabled", ":disabled"),
                            e.querySelectorAll("*,:x"),
                            f.push(",.*:")
                        })), (p.matchesSelector = T.test(i = n.matches || n.webkitMatchesSelector || n.mozMatchesSelector || n.oMatchesSelector || n.msMatchesSelector)) && R(function (e) {
                        p.disconnectedMatch = i.call(e, "*"),
                        i.call(e, "[s!='']:x"),
                        r.push("!=", Y)
                    }), f = f.length && new RegExp(f.join("|")), r = r.length && new RegExp(r.join("|")), e = T.test(n.compareDocumentPosition), h = e || T.test(n.contains) ? function (e, t) {
                    var n = 9 === e.nodeType ? e.documentElement : e,
                    t = t && t.parentNode;
                    return e === t || !(!t || 1 !== t.nodeType || !(n.contains ? n.contains(t) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(t)))
                }
                     : function (e, t) {
                    if (t)
                        for (; t = t.parentNode; )
                            if (t === e)
                                return !0;
                    return !1
                }, W = e ? function (e, t) {
                    var n;
                    return e === t ? (c = !0, 0) : !e.compareDocumentPosition - !t.compareDocumentPosition || (1 & (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !p.sortDetached && t.compareDocumentPosition(e) === n ? e == x || e.ownerDocument == u && h(u, e) ? -1 : t == x || t.ownerDocument == u && h(u, t) ? 1 : l ? y(l, e) - y(l, t) : 0 : 4 & n ? -1 : 1)
                }
                     : function (e, t) {
                    if (e === t)
                        return c = !0, 0;
                    var n,
                    r = 0,
                    i = e.parentNode,
                    a = t.parentNode,
                    s = [e],
                    o = [t];
                    if (!i || !a)
                        return e == x ? -1 : t == x ? 1 : i ? -1 : a ? 1 : l ? y(l, e) - y(l, t) : 0;
                    if (i === a)
                        return fe(e, t);
                    for (n = e; n = n.parentNode; )
                        s.unshift(n);
                    for (n = t; n = n.parentNode; )
                        o.unshift(n);
                    for (; s[r] === o[r]; )
                        r++;
                    return r ? fe(s[r], o[r]) : s[r] == u ? -1 : o[r] == u ? 1 : 0
                }),
                x
            }, O.matches = function (e, t) {
                return O(e, null, null, t)
            }, O.matchesSelector = function (e, t) {
                if (w(e), p.matchesSelector && N && !m[t + " "] && (!r || !r.test(t)) && (!f || !f.test(t)))
                    try {
                        var n = i.call(e, t);
                        if (n || p.disconnectedMatch || e.document && 11 !== e.document.nodeType)
                            return n
                    } catch (e) {
                        m(t, !0)
                    }
                return 0 < O(t, x, null, [e]).length
            }, O.contains = function (e, t) {
                return (e.ownerDocument || e) != x && w(e),
                h(e, t)
            }, O.attr = function (e, t) {
                (e.ownerDocument || e) != x && w(e);
                var n = _.attrHandle[t.toLowerCase()],
                n = n && G.call(_.attrHandle, t.toLowerCase()) ? n(e, t, !N) : void 0;
                return void 0 !== n ? n : p.attributes || !N ? e.getAttribute(t) : (n = e.getAttributeNode(t)) && n.specified ? n.value : null
            }, O.escape = function (e) {
                return (e + "").replace(de, j)
            }, O.error = function (e) {
                throw new Error("Syntax error, unrecognized expression: " + e)
            }, O.uniqueSort = function (e) {
                var t,
                n = [],
                r = 0,
                i = 0;
                if (c = !p.detectDuplicates, l = !p.sortStable && e.slice(0), e.sort(W), c) {
                    for (; t = e[i++]; )
                        t === e[i] && (r = n.push(i));
                    for (; r--; )
                        e.splice(n[r], 1)
                }
                return l = null,
                e
            }, a = O.getText = function (e) {
                var t,
                n = "",
                r = 0,
                i = e.nodeType;
                if (i) {
                    if (1 === i || 9 === i || 11 === i) {
                        if ("string" == typeof e.textContent)
                            return e.textContent;
                        for (e = e.firstChild; e; e = e.nextSibling)
                            n += a(e)
                    } else if (3 === i || 4 === i)
                        return e.nodeValue
                } else
                    for (; t = e[r++]; )
                        n += a(t);
                return n
            }, (_ = O.selectors = {
                        cacheLength: 50,
                        createPseudo: D,
                        match: v,
                        attrHandle: {},
                        find: {},
                        relative: {
                            ">": {
                                dir: "parentNode",
                                first: !0
                            },
                            " ": {
                                dir: "parentNode"
                            },
                            "+": {
                                dir: "previousSibling",
                                first: !0
                            },
                            "~": {
                                dir: "previousSibling"
                            }
                        },
                        preFilter: {
                            ATTR: function (e) {
                                return e[1] = e[1].replace(A, d),
                                e[3] = (e[3] || e[4] || e[5] || "").replace(A, d),
                                "~=" === e[2] && (e[3] = " " + e[3] + " "),
                                e.slice(0, 4)
                            },
                            CHILD: function (e) {
                                return e[1] = e[1].toLowerCase(),
                                "nth" === e[1].slice(0, 3) ? (e[3] || O.error(e[0]), e[4] =  + (e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] =  + (e[7] + e[8] || "odd" === e[3])) : e[3] && O.error(e[0]),
                                e
                            },
                            PSEUDO: function (e) {
                                var t,
                                n = !e[6] && e[2];
                                return v.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && ie.test(n) && (t = (t = g(n, !0)) && n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                            }
                        },
                        filter: {
                            TAG: function (e) {
                                var t = e.replace(A, d).toLowerCase();
                                return "*" === e ? function () {
                                    return !0
                                }
                                 : function (e) {
                                    return e.nodeName && e.nodeName.toLowerCase() === t
                                }
                            },
                            CLASS: function (e) {
                                var t = H[e + " "];
                                return t || (t = new RegExp("(^|" + s + ")" + e + "(" + s + "|$)")) && H(e, function (e) {
                                    return t.test("string" == typeof e.className && e.className || void 0 !== e.getAttribute && e.getAttribute("class") || "")
                                })
                            },
                            ATTR: function (t, n, r) {
                                return function (e) {
                                    e = O.attr(e, t);
                                    return null == e ? "!=" === n : !n || (e += "", "=" === n ? e === r : "!=" === n ? e !== r : "^=" === n ? r && 0 === e.indexOf(r) : "*=" === n ? r && -1 < e.indexOf(r) : "$=" === n ? r && e.slice(-r.length) === r : "~=" === n ? -1 < (" " + e.replace(ee, " ") + " ").indexOf(r) : "|=" === n && (e === r || e.slice(0, r.length + 1) === r + "-"))
                                }
                            },
                            CHILD: function (f, e, t, h, m) {
                                var b = "nth" !== f.slice(0, 3),
                                y = "last" !== f.slice(-4),
                                v = "of-type" === e;
                                return 1 === h && 0 === m ? function (e) {
                                    return !!e.parentNode
                                }
                                 : function (e, t, n) {
                                    var r,
                                    i,
                                    a,
                                    s,
                                    o,
                                    l,
                                    c = b != y ? "nextSibling" : "previousSibling",
                                    u = e.parentNode,
                                    d = v && e.nodeName.toLowerCase(),
                                    p = !n && !v,
                                    g = !1;
                                    if (u) {
                                        if (b) {
                                            for (; c; ) {
                                                for (s = e; s = s[c]; )
                                                    if (v ? s.nodeName.toLowerCase() === d : 1 === s.nodeType)
                                                        return !1;
                                                l = c = "only" === f && !l && "nextSibling"
                                            }
                                            return !0
                                        }
                                        if (l = [y ? u.firstChild : u.lastChild], y && p) {
                                            for (g = (o = (r = (i = (a = (s = u)[k] || (s[k] = {}))[s.uniqueID] || (a[s.uniqueID] = {}))[f] || [])[0] === C && r[1]) && r[2], s = o && u.childNodes[o]; s = ++o && s && s[c] || (g = o = 0, l.pop()); )
                                                if (1 === s.nodeType && ++g && s === e) {
                                                    i[f] = [C, o, g];
                                                    break
                                                }
                                        } else if (!1 === (g = p ? o = (r = (i = (a = (s = e)[k] || (s[k] = {}))[s.uniqueID] || (a[s.uniqueID] = {}))[f] || [])[0] === C && r[1] : g))
                                            for (; (s = ++o && s && s[c] || (g = o = 0, l.pop())) && ((v ? s.nodeName.toLowerCase() !== d : 1 !== s.nodeType) || !++g || (p && ((i = (a = s[k] || (s[k] = {}))[s.uniqueID] || (a[s.uniqueID] = {}))[f] = [C, g]), s !== e)); );
                                        return (g -= m) === h || g % h == 0 && 0 <= g / h
                                    }
                                }
                            },
                            PSEUDO: function (e, a) {
                                var t,
                                s = _.pseudos[e] || _.setFilters[e.toLowerCase()] || O.error("unsupported pseudo: " + e);
                                return s[k] ? s(a) : 1 < s.length ? (t = [e, e, "", a], _.setFilters.hasOwnProperty(e.toLowerCase()) ? D(function (e, t) {
                                        for (var n, r = s(e, a), i = r.length; i--; )
                                            e[n = y(e, r[i])] = !(t[n] = r[i])
                                    }) : function (e) {
                                    return s(e, 0, t)
                                }) : s
                            }
                        },
                        pseudos: {
                            not: D(function (e) {
                                var r = [],
                                i = [],
                                o = P(e.replace(b, "$1"));
                                return o[k] ? D(function (e, t, n, r) {
                                    for (var i, a = o(e, null, r, []), s = e.length; s--; )
                                        (i = a[s]) && (e[s] = !(t[s] = i))
                                }) : function (e, t, n) {
                                    return r[0] = e,
                                    o(r, null, n, i),
                                    r[0] = null,
                                    !i.pop()
                                }
                            }),
                            has: D(function (t) {
                                return function (e) {
                                    return 0 < O(t, e).length
                                }
                            }),
                            contains: D(function (t) {
                                return t = t.replace(A, d),
                                function (e) {
                                    return -1 < (e.textContent || a(e)).indexOf(t)
                                }
                            }),
                            lang: D(function (n) {
                                return ae.test(n || "") || O.error("unsupported lang: " + n),
                                n = n.replace(A, d).toLowerCase(),
                                function (e) {
                                    var t;
                                    do {
                                        if (t = N ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang"))
                                            return (t = t.toLowerCase()) === n || 0 === t.indexOf(n + "-")
                                    } while ((e = e.parentNode) && 1 === e.nodeType);
                                    return !1
                                }
                            }),
                            target: function (e) {
                                var t = B.location && B.location.hash;
                                return t && t.slice(1) === e.id
                            },
                            root: function (e) {
                                return e === n
                            },
                            focus: function (e) {
                                return e === x.activeElement && (!x.hasFocus || x.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
                            },
                            enabled: he(!1),
                            disabled: he(!0),
                            checked: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && !!e.checked || "option" === t && !!e.selected
                            },
                            selected: function (e) {
                                return e.parentNode && e.parentNode.selectedIndex,
                                !0 === e.selected
                            },
                            empty: function (e) {
                                for (e = e.firstChild; e; e = e.nextSibling)
                                    if (e.nodeType < 6)
                                        return !1;
                                return !0
                            },
                            parent: function (e) {
                                return !_.pseudos.empty(e)
                            },
                            header: function (e) {
                                return le.test(e.nodeName)
                            },
                            input: function (e) {
                                return oe.test(e.nodeName)
                            },
                            button: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && "button" === e.type || "button" === t
                            },
                            text: function (e) {
                                return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (e = e.getAttribute("type")) || "text" === e.toLowerCase())
                            },
                            first: I(function () {
                                return [0]
                            }),
                            last: I(function (e, t) {
                                return [t - 1]
                            }),
                            eq: I(function (e, t, n) {
                                return [n < 0 ? n + t : n]
                            }),
                            even: I(function (e, t) {
                                for (var n = 0; n < t; n += 2)
                                    e.push(n);
                                return e
                            }),
                            odd: I(function (e, t) {
                                for (var n = 1; n < t; n += 2)
                                    e.push(n);
                                return e
                            }),
                            lt: I(function (e, t, n) {
                                for (var r = n < 0 ? n + t : t < n ? t : n; 0 <= --r; )
                                    e.push(r);
                                return e
                            }),
                            gt: I(function (e, t, n) {
                                for (var r = n < 0 ? n + t : n; ++r < t; )
                                    e.push(r);
                                return e
                            })
                        }
                    }).pseudos.nth = _.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            })_.pseudos[e] = function (t) {
                return function (e) {
                    return "input" === e.nodeName.toLowerCase() && e.type === t
                }
            }
        (e);
        for (e in {
            submit: !0,
            reset: !0
        })
            _.pseudos[e] = function (n) {
                return function (e) {
                    var t = e.nodeName.toLowerCase();
                    return ("input" === t || "button" === t) && e.type === n
                }
            }
        (e);
        function be() {}
        function L(e) {
            for (var t = 0, n = e.length, r = ""; t < n; t++)
                r += e[t].value;
            return r
        }
        function ye(s, e, t) {
            var o = e.dir,
            l = e.next,
            c = l || o,
            u = t && "parentNode" === c,
            d = z++;
            return e.first ? function (e, t, n) {
                for (; e = e[o]; )
                    if (1 === e.nodeType || u)
                        return s(e, t, n);
                return !1
            }
             : function (e, t, n) {
                var r,
                i,
                a = [C, d];
                if (n) {
                    for (; e = e[o]; )
                        if ((1 === e.nodeType || u) && s(e, t, n))
                            return !0
                } else
                    for (; e = e[o]; )
                        if (1 === e.nodeType || u)
                            if (i = (i = e[k] || (e[k] = {}))[e.uniqueID] || (i[e.uniqueID] = {}), l && l === e.nodeName.toLowerCase())
                                e = e[o] || e;
                            else {
                                if ((r = i[c]) && r[0] === C && r[1] === d)
                                    return a[2] = r[2];
                                if ((i[c] = a)[2] = s(e, t, n))
                                    return !0
                            }
                return !1
            }
        }
        function ve(i) {
            return 1 < i.length ? function (e, t, n) {
                for (var r = i.length; r--; )
                    if (!i[r](e, t, n))
                        return !1;
                return !0
            }
             : i[0]
        }
        function _e(e, t, n, r, i) {
            for (var a, s = [], o = 0, l = e.length, c = null != t; o < l; o++)
                !(a = e[o]) || n && !n(a, r, i) || (s.push(a), c && t.push(o));
            return s
        }
        function Ee(e) {
            for (var r, t, n, i = e.length, a = _.relative[e[0].type], s = a || _.relative[" "], o = a ? 1 : 0, l = ye(function (e) {
                    return e === r
                }, s, !0), c = ye(function (e) {
                    return -1 < y(r, e)
                }, s, !0), u = [function (e, t, n) {
                        e = !a && (n || t !== E) || ((r = t).nodeType ? l : c)(e, t, n);
                        return r = null,
                        e
                    }
                ]; o < i; o++)
                if (t = _.relative[e[o].type])
                    u = [ye(ve(u), t)];
                else {
                    if ((t = _.filter[e[o].type].apply(null, e[o].matches))[k]) {
                        for (n = ++o; n < i && !_.relative[e[n].type]; n++);
                        return function e(g, f, h, m, b, t) {
                            return m && !m[k] && (m = e(m)),
                            b && !b[k] && (b = e(b, t)),
                            D(function (e, t, n, r) {
                                var i,
                                a,
                                s,
                                o = [],
                                l = [],
                                c = t.length,
                                u = e || function (e, t, n) {
                                    for (var r = 0, i = t.length; r < i; r++)
                                        O(e, t[r], n);
                                    return n
                                }
                                (f || "*", n.nodeType ? [n] : n, []),
                                d = !g || !e && f ? u : _e(u, o, g, n, r),
                                p = h ? b || (e ? g : c || m) ? [] : t : d;
                                if (h && h(d, p, n, r), m)
                                    for (i = _e(p, l), m(i, [], n, r), a = i.length; a--; )
                                        (s = i[a]) && (p[l[a]] = !(d[l[a]] = s));
                                if (e) {
                                    if (b || g) {
                                        if (b) {
                                            for (i = [], a = p.length; a--; )
                                                (s = p[a]) && i.push(d[a] = s);
                                            b(null, p = [], i, r)
                                        }
                                        for (a = p.length; a--; )
                                            (s = p[a]) && -1 < (i = b ? y(e, s) : o[a]) && (e[i] = !(t[i] = s))
                                    }
                                } else
                                    p = _e(p === t ? p.splice(c, p.length) : p), b ? b(null, t, p, r) : S.apply(t, p)
                            })
                        }
                        (1 < o && ve(u), 1 < o && L(e.slice(0, o - 1).concat({
                                    value: " " === e[o - 2].type ? "*" : ""
                                })).replace(b, "$1"), t, o < n && Ee(e.slice(o, n)), n < i && Ee(e = e.slice(n)), n < i && L(e))
                    }
                    u.push(t)
                }
            return ve(u)
        }
        return be.prototype = _.filters = _.pseudos,
        _.setFilters = new be,
        g = O.tokenize = function (e, t) {
            var n,
            r,
            i,
            a,
            s,
            o,
            l,
            c = U[e + " "];
            if (c)
                return t ? 0 : c.slice(0);
            for (s = e, o = [], l = _.preFilter; s; ) {
                for (a in n && !(r = te.exec(s)) || (r && (s = s.slice(r[0].length) || s), o.push(i = [])), n = !1, (r = ne.exec(s)) && (n = r.shift(), i.push({
                            value: n,
                            type: r[0].replace(b, " ")
                        }), s = s.slice(n.length)), _.filter)
                    !(r = v[a].exec(s)) || l[a] && !(r = l[a](r)) || (n = r.shift(), i.push({
                            value: n,
                            type: a,
                            matches: r
                        }), s = s.slice(n.length));
                if (!n)
                    break
            }
            return t ? s.length : s ? O.error(e) : U(e, o).slice(0)
        },
        P = O.compile = function (e, t) {
            var n,
            m,
            b,
            y,
            v,
            r,
            i = [],
            a = [],
            s = K[e + " "];
            if (!s) {
                for (n = (t = t || g(e)).length; n--; )
                    ((s = Ee(t[n]))[k] ? i : a).push(s);
                (s = K(e, (y = 0 < (b = i).length, v = 0 < (m = a).length, r = function (e, t, n, r, i) {
                                var a,
                                s,
                                o,
                                l = 0,
                                c = "0",
                                u = e && [],
                                d = [],
                                p = E,
                                g = e || v && _.find.TAG("*", i),
                                f = C += null == p ? 1 : Math.random() || .1,
                                h = g.length;
                                for (i && (E = t == x || t || i); c !== h && null != (a = g[c]); c++) {
                                    if (v && a) {
                                        for (s = 0, t || a.ownerDocument == x || (w(a), n = !N); o = m[s++]; )
                                            if (o(a, t || x, n)) {
                                                r.push(a);
                                                break
                                            }
                                        i && (C = f)
                                    }
                                    y && ((a = !o && a) && l--, e) && u.push(a)
                                }
                                if (l += c, y && c !== l) {
                                    for (s = 0; o = b[s++]; )
                                        o(u, d, t, n);
                                    if (e) {
                                        if (0 < l)
                                            for (; c--; )
                                                u[c] || d[c] || (d[c] = Z.call(r));
                                        d = _e(d)
                                    }
                                    S.apply(r, d),
                                    i && !e && 0 < d.length && 1 < l + b.length && O.uniqueSort(r)
                                }
                                return i && (C = f, E = p),
                                u
                            }, y ? D(r) : r))).selector = e
            }
            return s
        },
        q = O.select = function (e, t, n, r) {
            var i,
            a,
            s,
            o,
            l,
            c = "function" == typeof e && e,
            u = !r && g(e = c.selector || e);
            if (n = n || [], 1 === u.length) {
                if (2 < (a = u[0] = u[0].slice(0)).length && "ID" === (s = a[0]).type && 9 === t.nodeType && N && _.relative[a[1].type]) {
                    if (!(t = (_.find.ID(s.matches[0].replace(A, d), t) || [])[0]))
                        return n;
                    c && (t = t.parentNode),
                    e = e.slice(a.shift().value.length)
                }
                for (i = v.needsContext.test(e) ? 0 : a.length; i-- && (s = a[i], !_.relative[o = s.type]); )
                    if ((l = _.find[o]) && (r = l(s.matches[0].replace(A, d), ue.test(a[0].type) && me(t.parentNode) || t))) {
                        if (a.splice(i, 1), e = r.length && L(a))
                            break;
                        return S.apply(n, r),
                        n
                    }
            }
            return (c || P(e, u))(r, t, !N, n, !t || ue.test(e) && me(t.parentNode) || t),
            n
        },
        p.sortStable = k.split("").sort(W).join("") === k,
        p.detectDuplicates = !!c,
        w(),
        p.sortDetached = R(function (e) {
            return 1 & e.compareDocumentPosition(x.createElement("fieldset"))
        }),
        R(function (e) {
            return e.innerHTML = "<a href='#'></a>",
            "#" === e.firstChild.getAttribute("href")
        }) || ge("type|href|height|width", function (e, t, n) {
            if (!n)
                return e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
        }),
        p.attributes && R(function (e) {
            return e.innerHTML = "<input/>",
            e.firstChild.setAttribute("value", ""),
            "" === e.firstChild.getAttribute("value")
        }) || ge("value", function (e, t, n) {
            if (!n && "input" === e.nodeName.toLowerCase())
                return e.defaultValue
        }),
        R(function (e) {
            return null == e.getAttribute("disabled")
        }) || ge(V, function (e, t, n) {
            if (!n)
                return !0 === e[t] ? t.toLowerCase() : (n = e.getAttributeNode(t)) && n.specified ? n.value : null
        }),
        O
    }
    (w),
    Q = (N.find = e, N.expr = e.selectors, N.expr[":"] = N.expr.pseudos, N.uniqueSort = N.unique = e.uniqueSort, N.text = e.getText, N.isXMLDoc = e.isXML, N.contains = e.contains, N.escapeSelector = e.escape, N.expr.match.needsContext);
    function l(e, t) {
        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
    }
    var V = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    function J(e, n, r) {
        return y(n) ? N.grep(e, function (e, t) {
            return !!n.call(e, t, e) !== r
        }) : n.nodeType ? N.grep(e, function (e) {
            return e === n !== r
        }) : "string" != typeof n ? N.grep(e, function (e) {
            return -1 < P.call(n, e) !== r
        }) : N.filter(n, e, r)
    }
    N.filter = function (e, t, n) {
        var r = t[0];
        return n && (e = ":not(" + e + ")"),
        1 === t.length && 1 === r.nodeType ? N.find.matchesSelector(r, e) ? [r] : [] : N.find.matches(e, N.grep(t, function (e) {
                return 1 === e.nodeType
            }))
    },
    N.fn.extend({
        find: function (e) {
            var t,
            n,
            r = this.length,
            i = this;
            if ("string" != typeof e)
                return this.pushStack(N(e).filter(function () {
                        for (t = 0; t < r; t++)
                            if (N.contains(i[t], this))
                                return !0
                    }));
            for (n = this.pushStack([]), t = 0; t < r; t++)
                N.find(e, i[t], n);
            return 1 < r ? N.uniqueSort(n) : n
        },
        filter: function (e) {
            return this.pushStack(J(this, e || [], !1))
        },
        not: function (e) {
            return this.pushStack(J(this, e || [], !0))
        },
        is: function (e) {
            return !!J(this, "string" == typeof e && Q.test(e) ? N(e) : e || [], !1).length
        }
    });
    var Y,
    ee = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/,
    te = ((N.fn.init = function (e, t, n) {
            if (e) {
                if (n = n || Y, "string" != typeof e)
                    return e.nodeType ? (this[0] = e, this.length = 1, this) : y(e) ? void 0 !== n.ready ? n.ready(e) : e(N) : N.makeArray(e, this);
                if (!(r = "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length ? [null, e, null] : ee.exec(e)) || !r[1] && t)
                    return (!t || t.jquery ? t || n : this.constructor(t)).find(e);
                if (r[1]) {
                    if (t = t instanceof N ? t[0] : t, N.merge(this, N.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : x, !0)), V.test(r[1]) && N.isPlainObject(t))
                        for (var r in t)
                            y(this[r]) ? this[r](t[r]) : this.attr(r, t[r])
                } else (n = x.getElementById(r[2])) && (this[0] = n, this.length = 1)
            }
            return this
        }).prototype = N.fn, Y = N(x), /^(?:parents|prev(?:Until|All))/),
    ne = {
        children: !0,
        contents: !0,
        next: !0,
        prev: !0
    };
    function re(e, t) {
        for (; (e = e[t]) && 1 !== e.nodeType; );
        return e
    }
    N.fn.extend({
        has: function (e) {
            var t = N(e, this),
            n = t.length;
            return this.filter(function () {
                for (var e = 0; e < n; e++)
                    if (N.contains(this, t[e]))
                        return !0
            })
        },
        closest: function (e, t) {
            var n,
            r = 0,
            i = this.length,
            a = [],
            s = "string" != typeof e && N(e);
            if (!Q.test(e))
                for (; r < i; r++)
                    for (n = this[r]; n && n !== t; n = n.parentNode)
                        if (n.nodeType < 11 && (s ? -1 < s.index(n) : 1 === n.nodeType && N.find.matchesSelector(n, e))) {
                            a.push(n);
                            break
                        }
            return this.pushStack(1 < a.length ? N.uniqueSort(a) : a)
        },
        index: function (e) {
            return e ? "string" == typeof e ? P.call(N(e), this[0]) : P.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function (e, t) {
            return this.pushStack(N.uniqueSort(N.merge(this.get(), N(e, t))))
        },
        addBack: function (e) {
            return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
        }
    }),
    N.each({
        parent: function (e) {
            e = e.parentNode;
            return e && 11 !== e.nodeType ? e : null
        },
        parents: function (e) {
            return r(e, "parentNode")
        },
        parentsUntil: function (e, t, n) {
            return r(e, "parentNode", n)
        },
        next: function (e) {
            return re(e, "nextSibling")
        },
        prev: function (e) {
            return re(e, "previousSibling")
        },
        nextAll: function (e) {
            return r(e, "nextSibling")
        },
        prevAll: function (e) {
            return r(e, "previousSibling")
        },
        nextUntil: function (e, t, n) {
            return r(e, "nextSibling", n)
        },
        prevUntil: function (e, t, n) {
            return r(e, "previousSibling", n)
        },
        siblings: function (e) {
            return X((e.parentNode || {}).firstChild, e)
        },
        children: function (e) {
            return X(e.firstChild)
        },
        contents: function (e) {
            return null != e.contentDocument && j(e.contentDocument) ? e.contentDocument : (l(e, "template") && (e = e.content || e), N.merge([], e.childNodes))
        }
    }, function (r, i) {
        N.fn[r] = function (e, t) {
            var n = N.map(this, i, e);
            return (t = "Until" !== r.slice(-5) ? e : t) && "string" == typeof t && (n = N.filter(t, n)),
            1 < this.length && (ne[r] || N.uniqueSort(n), te.test(r)) && n.reverse(),
            this.pushStack(n)
        }
    });
    var k = /[^\x20\t\r\n\f]+/g;
    function u(e) {
        return e
    }
    function ie(e) {
        throw e
    }
    function ae(e, t, n, r) {
        var i;
        try {
            e && y(i = e.promise) ? i.call(e).done(t).fail(n) : e && y(i = e.then) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r))
        } catch (e) {
            n.apply(void 0, [e])
        }
    }
    N.Callbacks = function (r) {
        var e,
        n;
        r = "string" == typeof r ? (e = r, n = {}, N.each(e.match(k) || [], function (e, t) {
                    n[t] = !0
                }), n) : N.extend({}, r);
        function i() {
            for (o = o || r.once, s = a = !0; c.length; u = -1)
                for (t = c.shift(); ++u < l.length; )
                    !1 === l[u].apply(t[0], t[1]) && r.stopOnFalse && (u = l.length, t = !1);
            r.memory || (t = !1),
            a = !1,
            o && (l = t ? [] : "")
        }
        var a,
        t,
        s,
        o,
        l = [],
        c = [],
        u = -1,
        d = {
            add: function () {
                return l && (t && !a && (u = l.length - 1, c.push(t)), function n(e) {
                    N.each(e, function (e, t) {
                        y(t) ? r.unique && d.has(t) || l.push(t) : t && t.length && "string" !== f(t) && n(t)
                    })
                }
                    (arguments), t) && !a && i(),
                this
            },
            remove: function () {
                return N.each(arguments, function (e, t) {
                    for (var n; -1 < (n = N.inArray(t, l, n)); )
                        l.splice(n, 1), n <= u && u--
                }),
                this
            },
            has: function (e) {
                return e ? -1 < N.inArray(e, l) : 0 < l.length
            },
            empty: function () {
                return l = l && [],
                this
            },
            disable: function () {
                return o = c = [],
                l = t = "",
                this
            },
            disabled: function () {
                return !l
            },
            lock: function () {
                return o = c = [],
                t || a || (l = t = ""),
                this
            },
            locked: function () {
                return !!o
            },
            fireWith: function (e, t) {
                return o || (t = [e, (t = t || []).slice ? t.slice() : t], c.push(t), a) || i(),
                this
            },
            fire: function () {
                return d.fireWith(this, arguments),
                this
            },
            fired: function () {
                return !!s
            }
        };
        return d
    },
    N.extend({
        Deferred: function (e) {
            var a = [["notify", "progress", N.Callbacks("memory"), N.Callbacks("memory"), 2], ["resolve", "done", N.Callbacks("once memory"), N.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", N.Callbacks("once memory"), N.Callbacks("once memory"), 1, "rejected"]],
            i = "pending",
            s = {
                state: function () {
                    return i
                },
                always: function () {
                    return o.done(arguments).fail(arguments),
                    this
                },
                catch : function (e) {
                    return s.then(null, e)
                },
            pipe: function () {
                var i = arguments;
                return N.Deferred(function (r) {
                    N.each(a, function (e, t) {
                        var n = y(i[t[4]]) && i[t[4]];
                        o[t[1]](function () {
                            var e = n && n.apply(this, arguments);
                            e && y(e.promise) ? e.promise().progress(r.notify).done(r.resolve).fail(r.reject) : r[t[0] + "With"](this, n ? [e] : arguments)
                        })
                    }),
                    i = null
                }).promise()
            },
            then: function (t, n, r) {
                var l = 0;
                function c(i, a, s, o) {
                    return function () {
                        function e() {
                            var e,
                            t;
                            if (!(i < l)) {
                                if ((e = s.apply(n, r)) === a.promise())
                                    throw new TypeError("Thenable self-resolution");
                                    t = e && ("object" == typeof e || "function" == typeof e) && e.then,
                                    y(t) ? o ? t.call(e, c(l, a, u, o), c(l, a, ie, o)) : (l++, t.call(e, c(l, a, u, o), c(l, a, ie, o), c(l, a, u, a.notifyWith))) : (s !== u && (n = void 0, r = [e]), (o || a.resolveWith)(n, r))
                                }
                            }
                            var n = this,
                            r = arguments,
                            t = o ? e : function () {
                                try {
                                    e()
                                } catch (e) {
                                    N.Deferred.exceptionHook && N.Deferred.exceptionHook(e, t.stackTrace),
                                    l <= i + 1 && (s !== ie && (n = void 0, r = [e]), a.rejectWith(n, r))
                                }
                            };
                            i ? t() : (N.Deferred.getStackHook && (t.stackTrace = N.Deferred.getStackHook()), w.setTimeout(t))
                        }
                    }
                    return N.Deferred(function (e) {
                        a[0][3].add(c(0, e, y(r) ? r : u, e.notifyWith)),
                        a[1][3].add(c(0, e, y(t) ? t : u)),
                        a[2][3].add(c(0, e, y(n) ? n : ie))
                    }).promise()
                },
                promise: function (e) {
                    return null != e ? N.extend(e, s) : s
                }
            },
            o = {};
            return N.each(a, function (e, t) {
                var n = t[2],
                r = t[5];
                s[t[1]] = n.add,
                r && n.add(function () {
                    i = r
                }, a[3 - e][2].disable, a[3 - e][3].disable, a[0][2].lock, a[0][3].lock),
                n.add(t[3].fire),
                o[t[0]] = function () {
                    return o[t[0] + "With"](this === o ? void 0 : this, arguments),
                    this
                },
                o[t[0] + "With"] = n.fireWith
            }),
            s.promise(o),
            e && e.call(o, o),
            o
        },
        when: function (e) {
            function t(t) {
                return function (e) {
                    i[t] = this,
                    a[t] = 1 < arguments.length ? o.call(arguments) : e,
                    --n || s.resolveWith(i, a)
                }
            }
            var n = arguments.length,
            r = n,
            i = Array(r),
            a = o.call(arguments),
            s = N.Deferred();
            if (n <= 1 && (ae(e, s.done(t(r)).resolve, s.reject, !n), "pending" === s.state() || y(a[r] && a[r].then)))
                return s.then();
            for (; r--; )
                ae(a[r], t(r), s.reject);
            return s.promise()
        }
    });
    var se = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/,
    oe = (N.Deferred.exceptionHook = function (e, t) {
        w.console && w.console.warn && e && se.test(e.name) && w.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t)
    }, N.readyException = function (e) {
        w.setTimeout(function () {
            throw e
        })
    }, N.Deferred());
    function le() {
        x.removeEventListener("DOMContentLoaded", le),
        w.removeEventListener("load", le),
        N.ready()
    }
    N.fn.ready = function (e) {
        return oe.then(e).catch(function (e) {
            N.readyException(e)
        }),
        this
    },
    N.extend({
        isReady: !1,
        readyWait: 1,
        ready: function (e) {
            (!0 === e ? --N.readyWait : N.isReady) || (N.isReady = !0) !== e && 0 < --N.readyWait || oe.resolveWith(x, [N])
        }
    }),
    N.ready.then = oe.then,
    "complete" === x.readyState || "loading" !== x.readyState && !x.documentElement.doScroll ? w.setTimeout(N.ready) : (x.addEventListener("DOMContentLoaded", le), w.addEventListener("load", le));
    function d(e, t, n, r, i, a, s) {
        var o = 0,
        l = e.length,
        c = null == n;
        if ("object" === f(n))
            for (o in i = !0, n)
                d(e, t, o, n[o], !0, a, s);
        else if (void 0 !== r && (i = !0, y(r) || (s = !0), t = c ? s ? (t.call(e, r), null) : (c = t, function (e, t, n) {
                    return c.call(N(e), n)
                }) : t))
            for (; o < l; o++)
                t(e[o], n, s ? r : r.call(e[o], o, t(e[o], n)));
        return i ? e : c ? t.call(e) : l ? t(e[0], n) : a
    }
    var ce = /^-ms-/,
    ue = /-([a-z])/g;
    function de(e, t) {
        return t.toUpperCase()
    }
    function v(e) {
        return e.replace(ce, "ms-").replace(ue, de)
    }
    function b(e) {
        return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType
    }
    function pe() {
        this.expando = N.expando + pe.uid++
    }
    pe.uid = 1,
    pe.prototype = {
        cache: function (e) {
            var t = e[this.expando];
            return t || (t = Object.create(null), b(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, {
                        value: t,
                        configurable: !0
                    }))),
            t
        },
        set: function (e, t, n) {
            var r,
            i = this.cache(e);
            if ("string" == typeof t)
                i[v(t)] = n;
            else
                for (r in t)
                    i[v(r)] = t[r];
            return i
        },
        get: function (e, t) {
            return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][v(t)]
        },
        access: function (e, t, n) {
            return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t)
        },
        remove: function (e, t) {
            var n,
            r = e[this.expando];
            if (void 0 !== r) {
                if (void 0 !== t) {
                    n = (t = Array.isArray(t) ? t.map(v) : (t = v(t))in r ? [t] : t.match(k) || []).length;
                    for (; n--; )
                        delete r[t[n]]
                }
                void 0 !== t && !N.isEmptyObject(r) || (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando])
            }
        },
        hasData: function (e) {
            e = e[this.expando];
            return void 0 !== e && !N.isEmptyObject(e)
        }
    };
    var _ = new pe,
    c = new pe,
    ge = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
    fe = /[A-Z]/g;
    function he(e, t, n) {
        var r,
        i;
        if (void 0 === n && 1 === e.nodeType)
            if (r = "data-" + t.replace(fe, "-$&").toLowerCase(), "string" == typeof(n = e.getAttribute(r))) {
                try {
                    n = "true" === (i = n) || "false" !== i && ("null" === i ? null : i === +i + "" ? +i : ge.test(i) ? JSON.parse(i) : i)
                } catch (e) {}
                c.set(e, t, n)
            } else
                n = void 0;
        return n
    }
    N.extend({
        hasData: function (e) {
            return c.hasData(e) || _.hasData(e)
        },
        data: function (e, t, n) {
            return c.access(e, t, n)
        },
        removeData: function (e, t) {
            c.remove(e, t)
        },
        _data: function (e, t, n) {
            return _.access(e, t, n)
        },
        _removeData: function (e, t) {
            _.remove(e, t)
        }
    }),
    N.fn.extend({
        data: function (n, e) {
            var t,
            r,
            i,
            a = this[0],
            s = a && a.attributes;
            if (void 0 !== n)
                return "object" == typeof n ? this.each(function () {
                    c.set(this, n)
                }) : d(this, function (e) {
                    var t;
                    if (a && void 0 === e)
                        return void 0 !== (t = c.get(a, n)) || void 0 !== (t = he(a, n)) ? t : void 0;
                    this.each(function () {
                        c.set(this, n, e)
                    })
                }, null, e, 1 < arguments.length, null, !0);
            if (this.length && (i = c.get(a), 1 === a.nodeType) && !_.get(a, "hasDataAttrs")) {
                for (t = s.length; t--; )
                    s[t] && 0 === (r = s[t].name).indexOf("data-") && (r = v(r.slice(5)), he(a, r, i[r]));
                _.set(a, "hasDataAttrs", !0)
            }
            return i
        },
        removeData: function (e) {
            return this.each(function () {
                c.remove(this, e)
            })
        }
    }),
    N.extend({
        queue: function (e, t, n) {
            var r;
            if (e)
                return r = _.get(e, t = (t || "fx") + "queue"), n && (!r || Array.isArray(n) ? r = _.access(e, t, N.makeArray(n)) : r.push(n)), r || []
        },
        dequeue: function (e, t) {
            t = t || "fx";
            var n = N.queue(e, t),
            r = n.length,
            i = n.shift(),
            a = N._queueHooks(e, t);
            "inprogress" === i && (i = n.shift(), r--),
            i && ("fx" === t && n.unshift("inprogress"), delete a.stop, i.call(e, function () {
                    N.dequeue(e, t)
                }, a)),
            !r && a && a.empty.fire()
        },
        _queueHooks: function (e, t) {
            var n = t + "queueHooks";
            return _.get(e, n) || _.access(e, n, {
                empty: N.Callbacks("once memory").add(function () {
                    _.remove(e, [t + "queue", n])
                })
            })
        }
    }),
    N.fn.extend({
        queue: function (t, n) {
            var e = 2;
            return "string" != typeof t && (n = t, t = "fx", e--),
            arguments.length < e ? N.queue(this[0], t) : void 0 === n ? this : this.each(function () {
                var e = N.queue(this, t, n);
                N._queueHooks(this, t),
                "fx" === t && "inprogress" !== e[0] && N.dequeue(this, t)
            })
        },
        dequeue: function (e) {
            return this.each(function () {
                N.dequeue(this, e)
            })
        },
        clearQueue: function (e) {
            return this.queue(e || "fx", [])
        },
        promise: function (e, t) {
            function n() {
                --i || a.resolveWith(s, [s])
            }
            var r,
            i = 1,
            a = N.Deferred(),
            s = this,
            o = this.length;
            for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; o--; )
                (r = _.get(s[o], e + "queueHooks")) && r.empty && (i++, r.empty.add(n));
            return n(),
            a.promise(t)
        }
    });
    function me(e, t) {
        return "none" === (e = t || e).style.display || "" === e.style.display && C(e) && "none" === N.css(e, "display")
    }
    var e = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    be = new RegExp("^(?:([+-])=|)(" + e + ")([a-z%]*)$", "i"),
    p = ["Top", "Right", "Bottom", "Left"],
    E = x.documentElement,
    C = function (e) {
        return N.contains(e.ownerDocument, e)
    },
    ye = {
        composed: !0
    };
    E.getRootNode && (C = function (e) {
        return N.contains(e.ownerDocument, e) || e.getRootNode(ye) === e.ownerDocument
    });
    function ve(e, t, n, r) {
        var i,
        a,
        s = 20,
        o = r ? function () {
            return r.cur()
        }
         : function () {
            return N.css(e, t, "")
        },
        l = o(),
        c = n && n[3] || (N.cssNumber[t] ? "" : "px"),
        u = e.nodeType && (N.cssNumber[t] || "px" !== c && +l) && be.exec(N.css(e, t));
        if (u && u[3] !== c) {
            for (c = c || u[3], u =  + (l /= 2) || 1; s--; )
                N.style(e, t, u + c), (1 - a) * (1 - (a = o() / l || .5)) <= 0 && (s = 0), u /= a;
            N.style(e, t, (u *= 2) + c),
            n = n || []
        }
        return n && (u = +u || +l || 0, i = n[1] ? u + (n[1] + 1) * n[2] : +n[2], r) && (r.unit = c, r.start = u, r.end = i),
        i
    }
    var _e = {};
    function S(e, t) {
        for (var n, r, i, a, s, o, l = [], c = 0, u = e.length; c < u; c++)
            (r = e[c]).style && (n = r.style.display, t ? ("none" === n && (l[c] = _.get(r, "display") || null, l[c] || (r.style.display = "")), "" === r.style.display && me(r) && (l[c] = (o = a = i = void 0, a = r.ownerDocument, s = r.nodeName, (o = _e[s]) || (i = a.body.appendChild(a.createElement(s)), o = N.css(i, "display"), i.parentNode.removeChild(i), _e[s] = o = "none" === o ? "block" : o)))) : "none" !== n && (l[c] = "none", _.set(r, "display", n)));
        for (c = 0; c < u; c++)
            null != l[c] && (e[c].style.display = l[c]);
        return e
    }
    N.fn.extend({
        show: function () {
            return S(this, !0)
        },
        hide: function () {
            return S(this)
        },
        toggle: function (e) {
            return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function () {
                me(this) ? N(this).show() : N(this).hide()
            })
        }
    });
    var Ee = /^(?:checkbox|radio)$/i,
    we = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
    xe = /^$|^module$|\/(?:java|ecma)script/i,
    n = x.createDocumentFragment().appendChild(x.createElement("div")),
    T = ((D = x.createElement("input")).setAttribute("type", "radio"), D.setAttribute("checked", "checked"), D.setAttribute("name", "t"), n.appendChild(D), m.checkClone = n.cloneNode(!0).cloneNode(!0).lastChild.checked, n.innerHTML = "<textarea>x</textarea>", m.noCloneChecked = !!n.cloneNode(!0).lastChild.defaultValue, n.innerHTML = "<option></option>", m.option = !!n.lastChild, {
        thead: [1, "<table>", "</table>"],
        col: [2, "<table><colgroup>", "</colgroup></table>"],
        tr: [2, "<table><tbody>", "</tbody></table>"],
        td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
        _default: [0, "", ""]
    });
    function A(e, t) {
        var n = void 0 !== e.getElementsByTagName ? e.getElementsByTagName(t || "*") : void 0 !== e.querySelectorAll ? e.querySelectorAll(t || "*") : [];
        return void 0 === t || t && l(e, t) ? N.merge([e], n) : n
    }
    function Ne(e, t) {
        for (var n = 0, r = e.length; n < r; n++)
            _.set(e[n], "globalEval", !t || _.get(t[n], "globalEval"))
    }
    T.tbody = T.tfoot = T.colgroup = T.caption = T.thead,
    T.th = T.td,
    m.option || (T.optgroup = T.option = [1, "<select multiple='multiple'>", "</select>"]);
    var ke = /<|&#?\w+;/;
    function Ce(e, t, n, r, i) {
        for (var a, s, o, l, c, u = t.createDocumentFragment(), d = [], p = 0, g = e.length; p < g; p++)
            if ((a = e[p]) || 0 === a)
                if ("object" === f(a))
                    N.merge(d, a.nodeType ? [a] : a);
                else if (ke.test(a)) {
                    for (s = s || u.appendChild(t.createElement("div")), o = (we.exec(a) || ["", ""])[1].toLowerCase(), o = T[o] || T._default, s.innerHTML = o[1] + N.htmlPrefilter(a) + o[2], c = o[0]; c--; )
                        s = s.lastChild;
                    N.merge(d, s.childNodes),
                    (s = u.firstChild).textContent = ""
                } else
                    d.push(t.createTextNode(a));
        for (u.textContent = "", p = 0; a = d[p++]; )
            if (r && -1 < N.inArray(a, r))
                i && i.push(a);
            else if (l = C(a), s = A(u.appendChild(a), "script"), l && Ne(s), n)
                for (c = 0; a = s[c++]; )
                    xe.test(a.type || "") && n.push(a);
        return u
    }
    var Se = /^key/,
    Te = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
    Ae = /^([^.]*)(?:\.(.+)|)/;
    function s() {
        return !0
    }
    function g() {
        return !1
    }
    function Oe(e, t) {
        return e === function () {
            try {
                return x.activeElement
            } catch (e) {}
        }
        () == ("focus" === t)
    }
    function Me(e, t, n, r, i, a) {
        var s,
        o;
        if ("object" == typeof t) {
            for (o in "string" != typeof n && (r = r || n, n = void 0), t)
                Me(e, o, n, r, t[o], a);
            return e
        }
        if (null == r && null == i ? (i = n, r = n = void 0) : null == i && ("string" == typeof n ? (i = r, r = void 0) : (i = r, r = n, n = void 0)), !1 === i)
            i = g;
        else if (!i)
            return e;
        return 1 === a && (s = i, (i = function (e) {
                return N().off(e),
                s.apply(this, arguments)
            }).guid = s.guid || (s.guid = N.guid++)),
        e.each(function () {
            N.event.add(this, t, i, r, n)
        })
    }
    function De(e, i, a) {
        a ? (_.set(e, i, !1), N.event.add(e, i, {
                namespace: !1,
                handler: function (e) {
                    var t,
                    n,
                    r = _.get(this, i);
                    if (1 & e.isTrigger && this[i]) {
                        if (r.length)
                            (N.event.special[i] || {}).delegateType && e.stopPropagation();
                        else if (r = o.call(arguments), _.set(this, i, r), t = a(this, i), this[i](), r !== (n = _.get(this, i)) || t ? _.set(this, i, !1) : n = {}, r !== n)
                            return e.stopImmediatePropagation(), e.preventDefault(), n.value
                    } else
                        r.length && (_.set(this, i, {
                                value: N.event.trigger(N.extend(r[0], N.Event.prototype), r.slice(1), this)
                            }), e.stopImmediatePropagation())
                }
            })) : void 0 === _.get(e, i) && N.event.add(e, i, s)
    }
    N.event = {
        global: {},
        add: function (t, e, n, r, i) {
            var a,
            s,
            o,
            l,
            c,
            u,
            d,
            p,
            g,
            f = _.get(t);
            if (b(t))
                for (n.handler && (n = (a = n).handler, i = a.selector), i && N.find.matchesSelector(E, i), n.guid || (n.guid = N.guid++), o = (o = f.events) || (f.events = Object.create(null)), s = (s = f.handle) || (f.handle = function (e) {
                        return void 0 !== N && N.event.triggered !== e.type ? N.event.dispatch.apply(t, arguments) : void 0
                    }), l = (e = (e || "").match(k) || [""]).length; l--; )
                    d = g = (p = Ae.exec(e[l]) || [])[1], p = (p[2] || "").split(".").sort(), d && (c = N.event.special[d] || {}, d = (i ? c.delegateType : c.bindType) || d, c = N.event.special[d] || {}, g = N.extend({
                            type: d,
                            origType: g,
                            data: r,
                            handler: n,
                            guid: n.guid,
                            selector: i,
                            needsContext: i && N.expr.match.needsContext.test(i),
                            namespace: p.join(".")
                        }, a), (u = o[d]) || ((u = o[d] = []).delegateCount = 0, c.setup && !1 !== c.setup.call(t, r, p, s)) || t.addEventListener && t.addEventListener(d, s), c.add && (c.add.call(t, g), g.handler.guid || (g.handler.guid = n.guid)), i ? u.splice(u.delegateCount++, 0, g) : u.push(g), N.event.global[d] = !0)
        },
        remove: function (e, t, n, r, i) {
            var a,
            s,
            o,
            l,
            c,
            u,
            d,
            p,
            g,
            f,
            h,
            m = _.hasData(e) && _.get(e);
            if (m && (l = m.events)) {
                for (c = (t = (t || "").match(k) || [""]).length; c--; )
                    if (g = h = (o = Ae.exec(t[c]) || [])[1], f = (o[2] || "").split(".").sort(), g) {
                        for (d = N.event.special[g] || {}, p = l[g = (r ? d.delegateType : d.bindType) || g] || [], o = o[2] && new RegExp("(^|\\.)" + f.join("\\.(?:.*\\.|)") + "(\\.|$)"), s = a = p.length; a--; )
                            u = p[a], !i && h !== u.origType || n && n.guid !== u.guid || o && !o.test(u.namespace) || r && r !== u.selector && ("**" !== r || !u.selector) || (p.splice(a, 1), u.selector && p.delegateCount--, d.remove && d.remove.call(e, u));
                        s && !p.length && (d.teardown && !1 !== d.teardown.call(e, f, m.handle) || N.removeEvent(e, g, m.handle), delete l[g])
                    } else
                        for (g in l)
                            N.event.remove(e, g + t[c], n, r, !0);
                N.isEmptyObject(l) && _.remove(e, "handle events")
            }
        },
        dispatch: function (e) {
            var t,
            n,
            r,
            i,
            a,
            s = new Array(arguments.length),
            o = N.event.fix(e),
            e = (_.get(this, "events") || Object.create(null))[o.type] || [],
            l = N.event.special[o.type] || {};
            for (s[0] = o, t = 1; t < arguments.length; t++)
                s[t] = arguments[t];
            if (o.delegateTarget = this, !l.preDispatch || !1 !== l.preDispatch.call(this, o)) {
                for (a = N.event.handlers.call(this, o, e), t = 0; (r = a[t++]) && !o.isPropagationStopped(); )
                    for (o.currentTarget = r.elem, n = 0; (i = r.handlers[n++]) && !o.isImmediatePropagationStopped(); )
                        o.rnamespace && !1 !== i.namespace && !o.rnamespace.test(i.namespace) || (o.handleObj = i, o.data = i.data, void 0 !== (i = ((N.event.special[i.origType] || {}).handle || i.handler).apply(r.elem, s)) && !1 === (o.result = i) && (o.preventDefault(), o.stopPropagation()));
                return l.postDispatch && l.postDispatch.call(this, o),
                o.result
            }
        },
        handlers: function (e, t) {
            var n,
            r,
            i,
            a,
            s,
            o = [],
            l = t.delegateCount,
            c = e.target;
            if (l && c.nodeType && !("click" === e.type && 1 <= e.button))
                for (; c !== this; c = c.parentNode || this)
                    if (1 === c.nodeType && ("click" !== e.type || !0 !== c.disabled)) {
                        for (a = [], s = {}, n = 0; n < l; n++)
                            void 0 === s[i = (r = t[n]).selector + " "] && (s[i] = r.needsContext ? -1 < N(i, this).index(c) : N.find(i, this, null, [c]).length), s[i] && a.push(r);
                        a.length && o.push({
                            elem: c,
                            handlers: a
                        })
                    }
            return c = this,
            l < t.length && o.push({
                elem: c,
                handlers: t.slice(l)
            }),
            o
        },
        addProp: function (t, e) {
            Object.defineProperty(N.Event.prototype, t, {
                enumerable: !0,
                configurable: !0,
                get: y(e) ? function () {
                    if (this.originalEvent)
                        return e(this.originalEvent)
                }
                 : function () {
                    if (this.originalEvent)
                        return this.originalEvent[t]
                },
                set: function (e) {
                    Object.defineProperty(this, t, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: e
                    })
                }
            })
        },
        fix: function (e) {
            return e[N.expando] ? e : new N.Event(e)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function (e) {
                    e = this || e;
                    return Ee.test(e.type) && e.click && l(e, "input") && De(e, "click", s),
                    !1
                },
                trigger: function (e) {
                    e = this || e;
                    return Ee.test(e.type) && e.click && l(e, "input") && De(e, "click"),
                    !0
                },
                _default: function (e) {
                    e = e.target;
                    return Ee.test(e.type) && e.click && l(e, "input") && _.get(e, "click") || l(e, "a")
                }
            },
            beforeunload: {
                postDispatch: function (e) {
                    void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                }
            }
        }
    },
    N.removeEvent = function (e, t, n) {
        e.removeEventListener && e.removeEventListener(t, n)
    },
    N.Event = function (e, t) {
        if (!(this instanceof N.Event))
            return new N.Event(e, t);
        e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? s : g, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e,
        t && N.extend(this, t),
        this.timeStamp = e && e.timeStamp || Date.now(),
        this[N.expando] = !0
    },
    N.Event.prototype = {
        constructor: N.Event,
        isDefaultPrevented: g,
        isPropagationStopped: g,
        isImmediatePropagationStopped: g,
        isSimulated: !1,
        preventDefault: function () {
            var e = this.originalEvent;
            this.isDefaultPrevented = s,
            e && !this.isSimulated && e.preventDefault()
        },
        stopPropagation: function () {
            var e = this.originalEvent;
            this.isPropagationStopped = s,
            e && !this.isSimulated && e.stopPropagation()
        },
        stopImmediatePropagation: function () {
            var e = this.originalEvent;
            this.isImmediatePropagationStopped = s,
            e && !this.isSimulated && e.stopImmediatePropagation(),
            this.stopPropagation()
        }
    },
    N.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        char: !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: function (e) {
            var t = e.button;
            return null == e.which && Se.test(e.type) ? null != e.charCode ? e.charCode : e.keyCode : !e.which && void 0 !== t && Te.test(e.type) ? 1 & t ? 1 : 2 & t ? 3 : 4 & t ? 2 : 0 : e.which
        }
    }, N.event.addProp),
    N.each({
        focus: "focusin",
        blur: "focusout"
    }, function (e, t) {
        N.event.special[e] = {
            setup: function () {
                return De(this, e, Oe),
                !1
            },
            trigger: function () {
                return De(this, e),
                !0
            },
            delegateType: t
        }
    }),
    N.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function (e, i) {
        N.event.special[e] = {
            delegateType: i,
            bindType: i,
            handle: function (e) {
                var t,
                n = e.relatedTarget,
                r = e.handleObj;
                return n && (n === this || N.contains(this, n)) || (e.type = r.origType, t = r.handler.apply(this, arguments), e.type = i),
                t
            }
        }
    }),
    N.fn.extend({
        on: function (e, t, n, r) {
            return Me(this, e, t, n, r)
        },
        one: function (e, t, n, r) {
            return Me(this, e, t, n, r, 1)
        },
        off: function (e, t, n) {
            var r,
            i;
            if (e && e.preventDefault && e.handleObj)
                r = e.handleObj, N(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler);
            else {
                if ("object" != typeof e)
                    return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = g), this.each(function () {
                        N.event.remove(this, e, n, t)
                    });
                for (i in e)
                    this.off(i, t, e[i])
            }
            return this
        }
    });
    var Re = /<script|<style|<link/i,
    Ie = /checked\s*(?:[^=]|=\s*.checked.)/i,
    Le = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
    function Be(e, t) {
        return l(e, "table") && l(11 !== t.nodeType ? t : t.firstChild, "tr") && N(e).children("tbody")[0] || e
    }
    function je(e) {
        return e.type = (null !== e.getAttribute("type")) + "/" + e.type,
        e
    }
    function $e(e) {
        return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"),
        e
    }
    function Fe(e, t) {
        var n,
        r,
        i,
        a;
        if (1 === t.nodeType) {
            if (_.hasData(e) && (a = _.get(e).events))
                for (i in _.remove(t, "handle events"), a)
                    for (n = 0, r = a[i].length; n < r; n++)
                        N.event.add(t, i, a[i][n]);
            c.hasData(e) && (e = c.access(e), e = N.extend({}, e), c.set(t, e))
        }
    }
    function O(n, r, i, a) {
        r = $(r);
        var e,
        t,
        s,
        o,
        l,
        c,
        u = 0,
        d = n.length,
        p = d - 1,
        g = r[0],
        f = y(g);
        if (f || 1 < d && "string" == typeof g && !m.checkClone && Ie.test(g))
            return n.each(function (e) {
                var t = n.eq(e);
                f && (r[0] = g.call(this, e, t.html())),
                O(t, r, i, a)
            });
        if (d && (t = (e = Ce(r, n[0].ownerDocument, !1, n, a)).firstChild, 1 === e.childNodes.length && (e = t), t || a)) {
            for (o = (s = N.map(A(e, "script"), je)).length; u < d; u++)
                l = e, u !== p && (l = N.clone(l, !0, !0), o) && N.merge(s, A(l, "script")), i.call(n[u], l, u);
            if (o)
                for (c = s[s.length - 1].ownerDocument, N.map(s, $e), u = 0; u < o; u++)
                    l = s[u], xe.test(l.type || "") && !_.access(l, "globalEval") && N.contains(c, l) && (l.src && "module" !== (l.type || "").toLowerCase() ? N._evalUrl && !l.noModule && N._evalUrl(l.src, {
                            nonce: l.nonce || l.getAttribute("nonce")
                        }, c) : G(l.textContent.replace(Le, ""), l, c))
        }
        return n
    }
    function Pe(e, t, n) {
        for (var r, i = t ? N.filter(t, e) : e, a = 0; null != (r = i[a]); a++)
            n || 1 !== r.nodeType || N.cleanData(A(r)), r.parentNode && (n && C(r) && Ne(A(r, "script")), r.parentNode.removeChild(r));
        return e
    }
    N.extend({
        htmlPrefilter: function (e) {
            return e
        },
        clone: function (e, t, n) {
            var r,
            i,
            a,
            s,
            o,
            l,
            c,
            u = e.cloneNode(!0),
            d = C(e);
            if (!(m.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || N.isXMLDoc(e)))
                for (s = A(u), r = 0, i = (a = A(e)).length; r < i; r++)
                    o = a[r], "input" === (c = (l = s[r]).nodeName.toLowerCase()) && Ee.test(o.type) ? l.checked = o.checked : "input" !== c && "textarea" !== c || (l.defaultValue = o.defaultValue);
            if (t)
                if (n)
                    for (a = a || A(e), s = s || A(u), r = 0, i = a.length; r < i; r++)
                        Fe(a[r], s[r]);
                else
                    Fe(e, u);
            return 0 < (s = A(u, "script")).length && Ne(s, !d && A(e, "script")),
            u
        },
        cleanData: function (e) {
            for (var t, n, r, i = N.event.special, a = 0; void 0 !== (n = e[a]); a++)
                if (b(n)) {
                    if (t = n[_.expando]) {
                        if (t.events)
                            for (r in t.events)
                                i[r] ? N.event.remove(n, r) : N.removeEvent(n, r, t.handle);
                        n[_.expando] = void 0
                    }
                    n[c.expando] && (n[c.expando] = void 0)
                }
        }
    }),
    N.fn.extend({
        detach: function (e) {
            return Pe(this, e, !0)
        },
        remove: function (e) {
            return Pe(this, e)
        },
        text: function (e) {
            return d(this, function (e) {
                return void 0 === e ? N.text(this) : this.empty().each(function () {
                    1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e)
                })
            }, null, e, arguments.length)
        },
        append: function () {
            return O(this, arguments, function (e) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Be(this, e).appendChild(e)
            })
        },
        prepend: function () {
            return O(this, arguments, function (e) {
                var t;
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (t = Be(this, e)).insertBefore(e, t.firstChild)
            })
        },
        before: function () {
            return O(this, arguments, function (e) {
                this.parentNode && this.parentNode.insertBefore(e, this)
            })
        },
        after: function () {
            return O(this, arguments, function (e) {
                this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
            })
        },
        empty: function () {
            for (var e, t = 0; null != (e = this[t]); t++)
                1 === e.nodeType && (N.cleanData(A(e, !1)), e.textContent = "");
            return this
        },
        clone: function (e, t) {
            return e = null != e && e,
            t = null == t ? e : t,
            this.map(function () {
                return N.clone(this, e, t)
            })
        },
        html: function (e) {
            return d(this, function (e) {
                var t = this[0] || {},
                n = 0,
                r = this.length;
                if (void 0 === e && 1 === t.nodeType)
                    return t.innerHTML;
                if ("string" == typeof e && !Re.test(e) && !T[(we.exec(e) || ["", ""])[1].toLowerCase()]) {
                    e = N.htmlPrefilter(e);
                    try {
                        for (; n < r; n++)
                            1 === (t = this[n] || {}).nodeType && (N.cleanData(A(t, !1)), t.innerHTML = e);
                        t = 0
                    } catch (e) {}
                }
                t && this.empty().append(e)
            }, null, e, arguments.length)
        },
        replaceWith: function () {
            var n = [];
            return O(this, arguments, function (e) {
                var t = this.parentNode;
                N.inArray(this, n) < 0 && (N.cleanData(A(this)), t) && t.replaceChild(e, this)
            }, n)
        }
    }),
    N.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function (e, s) {
        N.fn[e] = function (e) {
            for (var t, n = [], r = N(e), i = r.length - 1, a = 0; a <= i; a++)
                t = a === i ? this : this.clone(!0), N(r[a])[s](t), F.apply(n, t.get());
            return this.pushStack(n)
        }
    });
    function qe(e) {
        var t = e.ownerDocument.defaultView;
        return (t = t && t.opener ? t : w).getComputedStyle(e)
    }
    function ze(e, t, n) {
        var r,
        i = {};
        for (r in t)
            i[r] = e.style[r], e.style[r] = t[r];
        for (r in n = n.call(e), t)
            e.style[r] = i[r];
        return n
    }
    var He,
    Ue,
    Ke,
    We,
    Ge,
    Ze,
    Xe,
    i,
    Qe = new RegExp("^(" + e + ")(?!px)[a-z%]+$", "i"),
    Ve = new RegExp(p.join("|"), "i");
    function Je(e, t, n) {
        var r,
        i,
        a = e.style;
        return (n = n || qe(e)) && ("" !== (i = n.getPropertyValue(t) || n[t]) || C(e) || (i = N.style(e, t)), !m.pixelBoxStyles()) && Qe.test(i) && Ve.test(t) && (e = a.width, t = a.minWidth, r = a.maxWidth, a.minWidth = a.maxWidth = a.width = i, i = n.width, a.width = e, a.minWidth = t, a.maxWidth = r),
        void 0 !== i ? i + "" : i
    }
    function Ye(e, t) {
        return {
            get: function () {
                if (!e())
                    return (this.get = t).apply(this, arguments);
                delete this.get
            }
        }
    }
    function et() {
        var e;
        i && (Xe.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", i.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", E.appendChild(Xe).appendChild(i), e = w.getComputedStyle(i), He = "1%" !== e.top, Ze = 12 === tt(e.marginLeft), i.style.right = "60%", We = 36 === tt(e.right), Ue = 36 === tt(e.width), i.style.position = "absolute", Ke = 12 === tt(i.offsetWidth / 3), E.removeChild(Xe), i = null)
    }
    function tt(e) {
        return Math.round(parseFloat(e))
    }
    Xe = x.createElement("div"),
    (i = x.createElement("div")).style && (i.style.backgroundClip = "content-box", i.cloneNode(!0).style.backgroundClip = "", m.clearCloneStyle = "content-box" === i.style.backgroundClip, N.extend(m, {
            boxSizingReliable: function () {
                return et(),
                Ue
            },
            pixelBoxStyles: function () {
                return et(),
                We
            },
            pixelPosition: function () {
                return et(),
                He
            },
            reliableMarginLeft: function () {
                return et(),
                Ze
            },
            scrollboxSize: function () {
                return et(),
                Ke
            },
            reliableTrDimensions: function () {
                var e,
                t,
                n;
                return null == Ge && (e = x.createElement("table"), t = x.createElement("tr"), n = x.createElement("div"), e.style.cssText = "position:absolute;left:-11111px", t.style.height = "1px", n.style.height = "9px", E.appendChild(e).appendChild(t).appendChild(n), n = w.getComputedStyle(t), Ge = 3 < parseInt(n.height), E.removeChild(e)),
                Ge
            }
        }));
    var nt = ["Webkit", "Moz", "ms"],
    rt = x.createElement("div").style,
    it = {};
    function at(e) {
        return N.cssProps[e] || it[e] || (e in rt ? e : it[e] = function (e) {
            for (var t = e[0].toUpperCase() + e.slice(1), n = nt.length; n--; )
                if ((e = nt[n] + t)in rt)
                    return e
        }
            (e) || e)
    }
    var st = /^(none|table(?!-c[ea]).+)/,
    ot = /^--/,
    lt = {
        position: "absolute",
        visibility: "hidden",
        display: "block"
    },
    ct = {
        letterSpacing: "0",
        fontWeight: "400"
    };
    function ut(e, t, n) {
        var r = be.exec(t);
        return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t
    }
    function dt(e, t, n, r, i, a) {
        var s = "width" === t ? 1 : 0,
        o = 0,
        l = 0;
        if (n === (r ? "border" : "content"))
            return 0;
        for (; s < 4; s += 2)
            "margin" === n && (l += N.css(e, n + p[s], !0, i)), r ? ("content" === n && (l -= N.css(e, "padding" + p[s], !0, i)), "margin" !== n && (l -= N.css(e, "border" + p[s] + "Width", !0, i))) : (l += N.css(e, "padding" + p[s], !0, i), "padding" !== n ? l += N.css(e, "border" + p[s] + "Width", !0, i) : o += N.css(e, "border" + p[s] + "Width", !0, i));
        return !r && 0 <= a && (l += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - a - l - o - .5)) || 0),
        l
    }
    function pt(e, t, n) {
        var r = qe(e),
        i = (!m.boxSizingReliable() || n) && "border-box" === N.css(e, "boxSizing", !1, r),
        a = i,
        s = Je(e, t, r),
        o = "offset" + t[0].toUpperCase() + t.slice(1);
        if (Qe.test(s)) {
            if (!n)
                return s;
            s = "auto"
        }
        return (!m.boxSizingReliable() && i || !m.reliableTrDimensions() && l(e, "tr") || "auto" === s || !parseFloat(s) && "inline" === N.css(e, "display", !1, r)) && e.getClientRects().length && (i = "border-box" === N.css(e, "boxSizing", !1, r), a = o in e) && (s = e[o]),
        (s = parseFloat(s) || 0) + dt(e, t, n || (i ? "border" : "content"), a, r, s) + "px"
    }
    function a(e, t, n, r, i) {
        return new a.prototype.init(e, t, n, r, i)
    }
    N.extend({
        cssHooks: {
            opacity: {
                get: function (e, t) {
                    if (t)
                        return "" === (t = Je(e, "opacity")) ? "1" : t
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {},
        style: function (e, t, n, r) {
            if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                var i,
                a,
                s,
                o = v(t),
                l = ot.test(t),
                c = e.style;
                if (l || (t = at(o)), s = N.cssHooks[t] || N.cssHooks[o], void 0 === n)
                    return s && "get" in s && void 0 !== (i = s.get(e, !1, r)) ? i : c[t];
                "string" == (a = typeof n) && (i = be.exec(n)) && i[1] && (n = ve(e, t, i), a = "number"),
                null != n && n == n && ("number" !== a || l || (n += i && i[3] || (N.cssNumber[o] ? "" : "px")), m.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (c[t] = "inherit"), s && "set" in s && void 0 === (n = s.set(e, n, r)) || (l ? c.setProperty(t, n) : c[t] = n))
            }
        },
        css: function (e, t, n, r) {
            var i,
            a = v(t);
            return ot.test(t) || (t = at(a)),
            "normal" === (i = void 0 === (i = (a = N.cssHooks[t] || N.cssHooks[a]) && "get" in a ? a.get(e, !0, n) : i) ? Je(e, t, r) : i) && t in ct && (i = ct[t]),
            ("" === n || n) && (a = parseFloat(i), !0 === n || isFinite(a)) ? a || 0 : i
        }
    }),
    N.each(["height", "width"], function (e, s) {
        N.cssHooks[s] = {
            get: function (e, t, n) {
                if (t)
                    return !st.test(N.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? pt(e, s, n) : ze(e, lt, function () {
                        return pt(e, s, n)
                    })
            },
            set: function (e, t, n) {
                var r = qe(e),
                i = !m.scrollboxSize() && "absolute" === r.position,
                a = (i || n) && "border-box" === N.css(e, "boxSizing", !1, r),
                n = n ? dt(e, s, n, a, r) : 0;
                return a && i && (n -= Math.ceil(e["offset" + s[0].toUpperCase() + s.slice(1)] - parseFloat(r[s]) - dt(e, s, "border", !1, r) - .5)),
                n && (a = be.exec(t)) && "px" !== (a[3] || "px") && (e.style[s] = t, t = N.css(e, s)),
                ut(0, t, n)
            }
        }
    }),
    N.cssHooks.marginLeft = Ye(m.reliableMarginLeft, function (e, t) {
        if (t)
            return (parseFloat(Je(e, "marginLeft")) || e.getBoundingClientRect().left - ze(e, {
                    marginLeft: 0
                }, function () {
                    return e.getBoundingClientRect().left
                })) + "px"
    }),
    N.each({
        margin: "",
        padding: "",
        border: "Width"
    }, function (i, a) {
        N.cssHooks[i + a] = {
            expand: function (e) {
                for (var t = 0, n = {}, r = "string" == typeof e ? e.split(" ") : [e]; t < 4; t++)
                    n[i + p[t] + a] = r[t] || r[t - 2] || r[0];
                return n
            }
        },
        "margin" !== i && (N.cssHooks[i + a].set = ut)
    }),
    N.fn.extend({
        css: function (e, t) {
            return d(this, function (e, t, n) {
                var r,
                i,
                a = {},
                s = 0;
                if (Array.isArray(t)) {
                    for (r = qe(e), i = t.length; s < i; s++)
                        a[t[s]] = N.css(e, t[s], !1, r);
                    return a
                }
                return void 0 !== n ? N.style(e, t, n) : N.css(e, t)
            }, e, t, 1 < arguments.length)
        }
    }),
    ((N.Tween = a).prototype = {
            constructor: a,
            init: function (e, t, n, r, i, a) {
                this.elem = e,
                this.prop = n,
                this.easing = i || N.easing._default,
                this.options = t,
                this.start = this.now = this.cur(),
                this.end = r,
                this.unit = a || (N.cssNumber[n] ? "" : "px")
            },
            cur: function () {
                var e = a.propHooks[this.prop];
                return (e && e.get ? e : a.propHooks._default).get(this)
            },
            run: function (e) {
                var t,
                n = a.propHooks[this.prop];
                return this.options.duration ? this.pos = t = N.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e,
                this.now = (this.end - this.start) * t + this.start,
                this.options.step && this.options.step.call(this.elem, this.now, this),
                (n && n.set ? n : a.propHooks._default).set(this),
                this
            }
        }).init.prototype = a.prototype,
    (a.propHooks = {
            _default: {
                get: function (e) {
                    return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (e = N.css(e.elem, e.prop, "")) && "auto" !== e ? e : 0
                },
                set: function (e) {
                    N.fx.step[e.prop] ? N.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !N.cssHooks[e.prop] && null == e.elem.style[at(e.prop)] ? e.elem[e.prop] = e.now : N.style(e.elem, e.prop, e.now + e.unit)
                }
            }
        }).scrollTop = a.propHooks.scrollLeft = {
        set: function (e) {
            e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
        }
    },
    N.easing = {
        linear: function (e) {
            return e
        },
        swing: function (e) {
            return .5 - Math.cos(e * Math.PI) / 2
        },
        _default: "swing"
    },
    N.fx = a.prototype.init,
    N.fx.step = {};
    var M,
    gt,
    D,
    ft = /^(?:toggle|show|hide)$/,
    ht = /queueHooks$/;
    function mt() {
        gt && (!1 === x.hidden && w.requestAnimationFrame ? w.requestAnimationFrame(mt) : w.setTimeout(mt, N.fx.interval), N.fx.tick())
    }
    function bt() {
        return w.setTimeout(function () {
            M = void 0
        }),
        M = Date.now()
    }
    function yt(e, t) {
        var n,
        r = 0,
        i = {
            height: e
        };
        for (t = t ? 1 : 0; r < 4; r += 2 - t)
            i["margin" + (n = p[r])] = i["padding" + n] = e;
        return t && (i.opacity = i.width = e),
        i
    }
    function vt(e, t, n) {
        for (var r, i = (R.tweeners[t] || []).concat(R.tweeners["*"]), a = 0, s = i.length; a < s; a++)
            if (r = i[a].call(n, t, e))
                return r
    }
    function R(i, e, t) {
        var n,
        a,
        r,
        s,
        o,
        l,
        c,
        u = 0,
        d = R.prefilters.length,
        p = N.Deferred().always(function () {
            delete g.elem
        }),
        g = function () {
            if (a)
                return !1;
            for (var e = M || bt(), e = Math.max(0, f.startTime + f.duration - e), t = 1 - (e / f.duration || 0), n = 0, r = f.tweens.length; n < r; n++)
                f.tweens[n].run(t);
            return p.notifyWith(i, [f, t, e]),
            t < 1 && r ? e : (r || p.notifyWith(i, [f, 1, 0]), p.resolveWith(i, [f]), !1)
        },
        f = p.promise({
            elem: i,
            props: N.extend({}, e),
            opts: N.extend(!0, {
                specialEasing: {},
                easing: N.easing._default
            }, t),
            originalProperties: e,
            originalOptions: t,
            startTime: M || bt(),
            duration: t.duration,
            tweens: [],
            createTween: function (e, t) {
                t = N.Tween(i, f.opts, e, t, f.opts.specialEasing[e] || f.opts.easing);
                return f.tweens.push(t),
                t
            },
            stop: function (e) {
                var t = 0,
                n = e ? f.tweens.length : 0;
                if (!a) {
                    for (a = !0; t < n; t++)
                        f.tweens[t].run(1);
                    e ? (p.notifyWith(i, [f, 1, 0]), p.resolveWith(i, [f, e])) : p.rejectWith(i, [f, e])
                }
                return this
            }
        }),
        h = f.props,
        m = h,
        b = f.opts.specialEasing;
        for (r in m)
            if (o = b[s = v(r)], l = m[r], Array.isArray(l) && (o = l[1], l = m[r] = l[0]), r !== s && (m[s] = l, delete m[r]), (c = N.cssHooks[s]) && "expand" in c)
                for (r in l = c.expand(l), delete m[s], l)
                    r in m || (m[r] = l[r], b[r] = o);
            else
                b[s] = o;
        for (; u < d; u++)
            if (n = R.prefilters[u].call(f, i, h, f.opts))
                return y(n.stop) && (N._queueHooks(f.elem, f.opts.queue).stop = n.stop.bind(n)), n;
        return N.map(h, vt, f),
        y(f.opts.start) && f.opts.start.call(i, f),
        f.progress(f.opts.progress).done(f.opts.done, f.opts.complete).fail(f.opts.fail).always(f.opts.always),
        N.fx.timer(N.extend(g, {
                elem: i,
                anim: f,
                queue: f.opts.queue
            })),
        f
    }
    N.Animation = N.extend(R, {
        tweeners: {
            "*": [function (e, t) {
                    var n = this.createTween(e, t);
                    return ve(n.elem, e, be.exec(t), n),
                    n
                }
            ]
        },
        tweener: function (e, t) {
            for (var n, r = 0, i = (e = y(e) ? (t = e, ["*"]) : e.match(k)).length; r < i; r++)
                n = e[r], R.tweeners[n] = R.tweeners[n] || [], R.tweeners[n].unshift(t)
        },
        prefilters: [function (e, t, n) {
                var r,
                i,
                a,
                s,
                o,
                l,
                c,
                u = "width" in t || "height" in t,
                d = this,
                p = {},
                g = e.style,
                f = e.nodeType && me(e),
                h = _.get(e, "fxshow");
                for (r in n.queue || (null == (s = N._queueHooks(e, "fx")).unqueued && (s.unqueued = 0, o = s.empty.fire, s.empty.fire = function () {
                            s.unqueued || o()
                        }), s.unqueued++, d.always(function () {
                            d.always(function () {
                                s.unqueued--,
                                N.queue(e, "fx").length || s.empty.fire()
                            })
                        })), t)
                    if (i = t[r], ft.test(i)) {
                        if (delete t[r], a = a || "toggle" === i, i === (f ? "hide" : "show")) {
                            if ("show" !== i || !h || void 0 === h[r])
                                continue;
                            f = !0
                        }
                        p[r] = h && h[r] || N.style(e, r)
                    }
                if ((l = !N.isEmptyObject(t)) || !N.isEmptyObject(p))
                    for (r in u && 1 === e.nodeType && (n.overflow = [g.overflow, g.overflowX, g.overflowY], null == (c = h && h.display) && (c = _.get(e, "display")), "none" === (u = N.css(e, "display")) && (c ? u = c : (S([e], !0), c = e.style.display || c, u = N.css(e, "display"), S([e]))), "inline" === u || "inline-block" === u && null != c) && "none" === N.css(e, "float") && (l || (d.done(function () {
                                    g.display = c
                                }), null == c && (u = g.display, c = "none" === u ? "" : u)), g.display = "inline-block"), n.overflow && (g.overflow = "hidden", d.always(function () {
                                g.overflow = n.overflow[0],
                                g.overflowX = n.overflow[1],
                                g.overflowY = n.overflow[2]
                            })), l = !1, p)
                        l || (h ? "hidden" in h && (f = h.hidden) : h = _.access(e, "fxshow", {
                                display: c
                            }), a && (h.hidden = !f), f && S([e], !0), d.done(function () {
                                for (r in f || S([e]), _.remove(e, "fxshow"), p)
                                    N.style(e, r, p[r])
                            })), l = vt(f ? h[r] : 0, r, d), r in h || (h[r] = l.start, f && (l.end = l.start, l.start = 0))
            }
        ],
        prefilter: function (e, t) {
            t ? R.prefilters.unshift(e) : R.prefilters.push(e)
        }
    }),
    N.speed = function (e, t, n) {
        var r = e && "object" == typeof e ? N.extend({}, e) : {
            complete: n || !n && t || y(e) && e,
            duration: e,
            easing: n && t || t && !y(t) && t
        };
        return N.fx.off ? r.duration = 0 : "number" != typeof r.duration && (r.duration in N.fx.speeds ? r.duration = N.fx.speeds[r.duration] : r.duration = N.fx.speeds._default),
        null != r.queue && !0 !== r.queue || (r.queue = "fx"),
        r.old = r.complete,
        r.complete = function () {
            y(r.old) && r.old.call(this),
            r.queue && N.dequeue(this, r.queue)
        },
        r
    },
    N.fn.extend({
        fadeTo: function (e, t, n, r) {
            return this.filter(me).css("opacity", 0).show().end().animate({
                opacity: t
            }, e, n, r)
        },
        animate: function (t, e, n, r) {
            function i() {
                var e = R(this, N.extend({}, t), s);
                (a || _.get(this, "finish")) && e.stop(!0)
            }
            var a = N.isEmptyObject(t),
            s = N.speed(e, n, r);
            return i.finish = i,
            a || !1 === s.queue ? this.each(i) : this.queue(s.queue, i)
        },
        stop: function (i, e, a) {
            function s(e) {
                var t = e.stop;
                delete e.stop,
                t(a)
            }
            return "string" != typeof i && (a = e, e = i, i = void 0),
            e && this.queue(i || "fx", []),
            this.each(function () {
                var e = !0,
                t = null != i && i + "queueHooks",
                n = N.timers,
                r = _.get(this);
                if (t)
                    r[t] && r[t].stop && s(r[t]);
                else
                    for (t in r)
                        r[t] && r[t].stop && ht.test(t) && s(r[t]);
                for (t = n.length; t--; )
                    n[t].elem !== this || null != i && n[t].queue !== i || (n[t].anim.stop(a), e = !1, n.splice(t, 1));
                !e && a || N.dequeue(this, i)
            })
        },
        finish: function (s) {
            return !1 !== s && (s = s || "fx"),
            this.each(function () {
                var e,
                t = _.get(this),
                n = t[s + "queue"],
                r = t[s + "queueHooks"],
                i = N.timers,
                a = n ? n.length : 0;
                for (t.finish = !0, N.queue(this, s, []), r && r.stop && r.stop.call(this, !0), e = i.length; e--; )
                    i[e].elem === this && i[e].queue === s && (i[e].anim.stop(!0), i.splice(e, 1));
                for (e = 0; e < a; e++)
                    n[e] && n[e].finish && n[e].finish.call(this);
                delete t.finish
            })
        }
    }),
    N.each(["toggle", "show", "hide"], function (e, r) {
        var i = N.fn[r];
        N.fn[r] = function (e, t, n) {
            return null == e || "boolean" == typeof e ? i.apply(this, arguments) : this.animate(yt(r, !0), e, t, n)
        }
    }),
    N.each({
        slideDown: yt("show"),
        slideUp: yt("hide"),
        slideToggle: yt("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function (e, r) {
        N.fn[e] = function (e, t, n) {
            return this.animate(r, e, t, n)
        }
    }),
    N.timers = [],
    N.fx.tick = function () {
        var e,
        t = 0,
        n = N.timers;
        for (M = Date.now(); t < n.length; t++)
            (e = n[t])() || n[t] !== e || n.splice(t--, 1);
        n.length || N.fx.stop(),
        M = void 0
    },
    N.fx.timer = function (e) {
        N.timers.push(e),
        N.fx.start()
    },
    N.fx.interval = 13,
    N.fx.start = function () {
        gt || (gt = !0, mt())
    },
    N.fx.stop = function () {
        gt = null
    },
    N.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    },
    N.fn.delay = function (r, e) {
        return r = N.fx && N.fx.speeds[r] || r,
        this.queue(e = e || "fx", function (e, t) {
            var n = w.setTimeout(e, r);
            t.stop = function () {
                w.clearTimeout(n)
            }
        })
    },
    D = x.createElement("input"),
    n = x.createElement("select").appendChild(x.createElement("option")),
    D.type = "checkbox",
    m.checkOn = "" !== D.value,
    m.optSelected = n.selected,
    (D = x.createElement("input")).value = "t",
    D.type = "radio",
    m.radioValue = "t" === D.value;
    var _t,
    Et = N.expr.attrHandle,
    wt = (N.fn.extend({
            attr: function (e, t) {
                return d(this, N.attr, e, t, 1 < arguments.length)
            },
            removeAttr: function (e) {
                return this.each(function () {
                    N.removeAttr(this, e)
                })
            }
        }), N.extend({
            attr: function (e, t, n) {
                var r,
                i,
                a = e.nodeType;
                if (3 !== a && 8 !== a && 2 !== a)
                    return void 0 === e.getAttribute ? N.prop(e, t, n) : (1 === a && N.isXMLDoc(e) || (i = N.attrHooks[t.toLowerCase()] || (N.expr.match.bool.test(t) ? _t : void 0)), void 0 !== n ? null === n ? void N.removeAttr(e, t) : i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e.setAttribute(t, n + ""), n) : !(i && "get" in i && null !== (r = i.get(e, t))) && null == (r = N.find.attr(e, t)) ? void 0 : r)
            },
            attrHooks: {
                type: {
                    set: function (e, t) {
                        var n;
                        if (!m.radioValue && "radio" === t && l(e, "input"))
                            return n = e.value, e.setAttribute("type", t), n && (e.value = n), t
                    }
                }
            },
            removeAttr: function (e, t) {
                var n,
                r = 0,
                i = t && t.match(k);
                if (i && 1 === e.nodeType)
                    for (; n = i[r++]; )
                        e.removeAttribute(n)
            }
        }), _t = {
            set: function (e, t, n) {
                return !1 === t ? N.removeAttr(e, n) : e.setAttribute(n, n),
                n
            }
        }, N.each(N.expr.match.bool.source.match(/\w+/g), function (e, t) {
            var s = Et[t] || N.find.attr;
            Et[t] = function (e, t, n) {
                var r,
                i,
                a = t.toLowerCase();
                return n || (i = Et[a], Et[a] = r, r = null != s(e, t, n) ? a : null, Et[a] = i),
                r
            }
        }), /^(?:input|select|textarea|button)$/i),
    xt = /^(?:a|area)$/i;
    function I(e) {
        return (e.match(k) || []).join(" ")
    }
    function L(e) {
        return e.getAttribute && e.getAttribute("class") || ""
    }
    function Nt(e) {
        return Array.isArray(e) ? e : "string" == typeof e && e.match(k) || []
    }
    N.fn.extend({
        prop: function (e, t) {
            return d(this, N.prop, e, t, 1 < arguments.length)
        },
        removeProp: function (e) {
            return this.each(function () {
                delete this[N.propFix[e] || e]
            })
        }
    }),
    N.extend({
        prop: function (e, t, n) {
            var r,
            i,
            a = e.nodeType;
            if (3 !== a && 8 !== a && 2 !== a)
                return 1 === a && N.isXMLDoc(e) || (t = N.propFix[t] || t, i = N.propHooks[t]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t]
        },
        propHooks: {
            tabIndex: {
                get: function (e) {
                    var t = N.find.attr(e, "tabindex");
                    return t ? parseInt(t, 10) : wt.test(e.nodeName) || xt.test(e.nodeName) && e.href ? 0 : -1
                }
            }
        },
        propFix: {
            for : "htmlFor", class: "className"
    }
}),
m.optSelected || (N.propHooks.selected = {
        get: function (e) {
            e = e.parentNode;
            return e && e.parentNode && e.parentNode.selectedIndex,
            null
        },
        set: function (e) {
            e = e.parentNode;
            e && (e.selectedIndex, e.parentNode) && e.parentNode.selectedIndex
        }
    }),
N.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
    N.propFix[this.toLowerCase()] = this
}),
N.fn.extend({
    addClass: function (t) {
        var e,
        n,
        r,
        i,
        a,
        s,
        o = 0;
        if (y(t))
            return this.each(function (e) {
                N(this).addClass(t.call(this, e, L(this)))
            });
            if ((e = Nt(t)).length)
                for (; n = this[o++]; )
                    if (s = L(n), r = 1 === n.nodeType && " " + I(s) + " ") {
                        for (a = 0; i = e[a++]; )
                            r.indexOf(" " + i + " ") < 0 && (r += i + " ");
                        s !== (s = I(r)) && n.setAttribute("class", s)
                    }
            return this
        },
        removeClass: function (t) {
            var e,
            n,
            r,
            i,
            a,
            s,
            o = 0;
            if (y(t))
                return this.each(function (e) {
                    N(this).removeClass(t.call(this, e, L(this)))
                });
            if (!arguments.length)
                return this.attr("class", "");
            if ((e = Nt(t)).length)
                for (; n = this[o++]; )
                    if (s = L(n), r = 1 === n.nodeType && " " + I(s) + " ") {
                        for (a = 0; i = e[a++]; )
                            for (; -1 < r.indexOf(" " + i + " "); )
                                r = r.replace(" " + i + " ", " ");
                        s !== (s = I(r)) && n.setAttribute("class", s)
                    }
            return this
        },
        toggleClass: function (i, t) {
            var a = typeof i,
            s = "string" == a || Array.isArray(i);
            return "boolean" == typeof t && s ? t ? this.addClass(i) : this.removeClass(i) : y(i) ? this.each(function (e) {
                N(this).toggleClass(i.call(this, e, L(this), t), t)
            }) : this.each(function () {
                var e,
                t,
                n,
                r;
                if (s)
                    for (t = 0, n = N(this), r = Nt(i); e = r[t++]; )
                        n.hasClass(e) ? n.removeClass(e) : n.addClass(e);
                else
                    void 0 !== i && "boolean" != a || ((e = L(this)) && _.set(this, "__className__", e), this.setAttribute && this.setAttribute("class", !e && !1 !== i && _.get(this, "__className__") || ""))
            })
        },
        hasClass: function (e) {
            for (var t, n = 0, r = " " + e + " "; t = this[n++]; )
                if (1 === t.nodeType && -1 < (" " + I(L(t)) + " ").indexOf(r))
                    return !0;
            return !1
        }
    });
    function kt(e) {
        e.stopPropagation()
    }
    var Ct = /\r/g,
    St = (N.fn.extend({
            val: function (t) {
                var n,
                e,
                r,
                i = this[0];
                return arguments.length ? (r = y(t), this.each(function (e) {
                        1 === this.nodeType && (null == (e = r ? t.call(this, e, N(this).val()) : t) ? e = "" : "number" == typeof e ? e += "" : Array.isArray(e) && (e = N.map(e, function (e) {
                                        return null == e ? "" : e + ""
                                    })), (n = N.valHooks[this.type] || N.valHooks[this.nodeName.toLowerCase()]) && "set" in n && void 0 !== n.set(this, e, "value") || (this.value = e))
                    })) : i ? (n = N.valHooks[i.type] || N.valHooks[i.nodeName.toLowerCase()]) && "get" in n && void 0 !== (e = n.get(i, "value")) ? e : "string" == typeof(e = i.value) ? e.replace(Ct, "") : null == e ? "" : e : void 0
            }
        }), N.extend({
            valHooks: {
                option: {
                    get: function (e) {
                        var t = N.find.attr(e, "value");
                        return null != t ? t : I(N.text(e))
                    }
                },
                select: {
                    get: function (e) {
                        for (var t, n = e.options, r = e.selectedIndex, i = "select-one" === e.type, a = i ? null : [], s = i ? r + 1 : n.length, o = r < 0 ? s : i ? r : 0; o < s; o++)
                            if (((t = n[o]).selected || o === r) && !t.disabled && (!t.parentNode.disabled || !l(t.parentNode, "optgroup"))) {
                                if (t = N(t).val(), i)
                                    return t;
                                a.push(t)
                            }
                        return a
                    },
                    set: function (e, t) {
                        for (var n, r, i = e.options, a = N.makeArray(t), s = i.length; s--; )
                            ((r = i[s]).selected = -1 < N.inArray(N.valHooks.option.get(r), a)) && (n = !0);
                        return n || (e.selectedIndex = -1),
                        a
                    }
                }
            }
        }), N.each(["radio", "checkbox"], function () {
            N.valHooks[this] = {
                set: function (e, t) {
                    if (Array.isArray(t))
                        return e.checked = -1 < N.inArray(N(e).val(), t)
                }
            },
            m.checkOn || (N.valHooks[this].get = function (e) {
                return null === e.getAttribute("value") ? "on" : e.value
            })
        }), m.focusin = "onfocusin" in w, /^(?:focusinfocus|focusoutblur)$/),
    Tt = (N.extend(N.event, {
            trigger: function (e, t, n, r) {
                var i,
                a,
                s,
                o,
                l,
                c,
                u,
                d = [n || x],
                p = H.call(e, "type") ? e.type : e,
                g = H.call(e, "namespace") ? e.namespace.split(".") : [],
                f = u = a = n = n || x;
                if (3 !== n.nodeType && 8 !== n.nodeType && !St.test(p + N.event.triggered) && (-1 < p.indexOf(".") && (p = (g = p.split(".")).shift(), g.sort()), o = p.indexOf(":") < 0 && "on" + p, (e = e[N.expando] ? e : new N.Event(p, "object" == typeof e && e)).isTrigger = r ? 2 : 3, e.namespace = g.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + g.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = n), t = null == t ? [e] : N.makeArray(t, [e]), c = N.event.special[p] || {}, r || !c.trigger || !1 !== c.trigger.apply(n, t))) {
                    if (!r && !c.noBubble && !h(n)) {
                        for (s = c.delegateType || p, St.test(s + p) || (f = f.parentNode); f; f = f.parentNode)
                            d.push(f), a = f;
                        a === (n.ownerDocument || x) && d.push(a.defaultView || a.parentWindow || w)
                    }
                    for (i = 0; (f = d[i++]) && !e.isPropagationStopped(); )
                        u = f, e.type = 1 < i ? s : c.bindType || p, (l = (_.get(f, "events") || Object.create(null))[e.type] && _.get(f, "handle")) && l.apply(f, t), (l = o && f[o]) && l.apply && b(f) && (e.result = l.apply(f, t), !1 === e.result) && e.preventDefault();
                    return e.type = p,
                    r || e.isDefaultPrevented() || c._default && !1 !== c._default.apply(d.pop(), t) || !b(n) || o && y(n[p]) && !h(n) && ((a = n[o]) && (n[o] = null), N.event.triggered = p, e.isPropagationStopped() && u.addEventListener(p, kt), n[p](), e.isPropagationStopped() && u.removeEventListener(p, kt), N.event.triggered = void 0, a) && (n[o] = a),
                    e.result
                }
            },
            simulate: function (e, t, n) {
                n = N.extend(new N.Event, n, {
                    type: e,
                    isSimulated: !0
                });
                N.event.trigger(n, null, t)
            }
        }), N.fn.extend({
            trigger: function (e, t) {
                return this.each(function () {
                    N.event.trigger(e, t, this)
                })
            },
            triggerHandler: function (e, t) {
                var n = this[0];
                if (n)
                    return N.event.trigger(e, t, n, !0)
            }
        }), m.focusin || N.each({
            focus: "focusin",
            blur: "focusout"
        }, function (n, r) {
            function i(e) {
                N.event.simulate(r, e.target, N.event.fix(e))
            }
            N.event.special[r] = {
                setup: function () {
                    var e = this.ownerDocument || this.document || this,
                    t = _.access(e, r);
                    t || e.addEventListener(n, i, !0),
                    _.access(e, r, (t || 0) + 1)
                },
                teardown: function () {
                    var e = this.ownerDocument || this.document || this,
                    t = _.access(e, r) - 1;
                    t ? _.access(e, r, t) : (e.removeEventListener(n, i, !0), _.remove(e, r))
                }
            }
        }), w.location),
    At = {
        guid: Date.now()
    },
    Ot = /\?/,
    Mt = (N.parseXML = function (e) {
        var t;
        if (!e || "string" != typeof e)
            return null;
        try {
            t = (new w.DOMParser).parseFromString(e, "text/xml")
        } catch (e) {
            t = void 0
        }
        return t && !t.getElementsByTagName("parsererror").length || N.error("Invalid XML: " + e),
        t
    }, /\[\]$/),
    Dt = /\r?\n/g,
    Rt = /^(?:submit|button|image|reset|file)$/i,
    It = /^(?:input|select|textarea|keygen)/i;
    N.param = function (e, t) {
        function n(e, t) {
            t = y(t) ? t() : t,
            i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == t ? "" : t)
        }
        var r,
        i = [];
        if (null == e)
            return "";
        if (Array.isArray(e) || e.jquery && !N.isPlainObject(e))
            N.each(e, function () {
                n(this.name, this.value)
            });
        else
            for (r in e)
                !function n(r, e, i, a) {
                    if (Array.isArray(e))
                        N.each(e, function (e, t) {
                            i || Mt.test(r) ? a(r, t) : n(r + "[" + ("object" == typeof t && null != t ? e : "") + "]", t, i, a)
                        });
                    else if (i || "object" !== f(e))
                        a(r, e);
                    else
                        for (var t in e)
                            n(r + "[" + t + "]", e[t], i, a)
                }
        (r, e[r], t, n);
        return i.join("&")
    },
    N.fn.extend({
        serialize: function () {
            return N.param(this.serializeArray())
        },
        serializeArray: function () {
            return this.map(function () {
                var e = N.prop(this, "elements");
                return e ? N.makeArray(e) : this
            }).filter(function () {
                var e = this.type;
                return this.name && !N(this).is(":disabled") && It.test(this.nodeName) && !Rt.test(e) && (this.checked || !Ee.test(e))
            }).map(function (e, t) {
                var n = N(this).val();
                return null == n ? null : Array.isArray(n) ? N.map(n, function (e) {
                    return {
                        name: t.name,
                        value: e.replace(Dt, "\r\n")
                    }
                }) : {
                    name: t.name,
                    value: n.replace(Dt, "\r\n")
                }
            }).get()
        }
    });
    var Lt = /%20/g,
    Bt = /#.*$/,
    jt = /([?&])_=[^&]*/,
    $t = /^(.*?):[ \t]*([^\r\n]*)$/gm,
    Ft = /^(?:GET|HEAD)$/,
    Pt = /^\/\//,
    qt = {},
    zt = {},
    Ht = "*/".concat("*"),
    Ut = x.createElement("a");
    function Kt(a) {
        return function (e, t) {
            "string" != typeof e && (t = e, e = "*");
            var n,
            r = 0,
            i = e.toLowerCase().match(k) || [];
            if (y(t))
                for (; n = i[r++]; )
                    "+" === n[0] ? (n = n.slice(1) || "*", (a[n] = a[n] || []).unshift(t)) : (a[n] = a[n] || []).push(t)
        }
    }
    function Wt(t, r, i, a) {
        var s = {},
        o = t === zt;
        function l(e) {
            var n;
            return s[e] = !0,
            N.each(t[e] || [], function (e, t) {
                t = t(r, i, a);
                return "string" != typeof t || o || s[t] ? o ? !(n = t) : void 0 : (r.dataTypes.unshift(t), l(t), !1)
            }),
            n
        }
        return l(r.dataTypes[0]) || !s["*"] && l("*")
    }
    function Gt(e, t) {
        var n,
        r,
        i = N.ajaxSettings.flatOptions || {};
        for (n in t)
            void 0 !== t[n] && ((i[n] ? e : r = r || {})[n] = t[n]);
        return r && N.extend(!0, e, r),
        e
    }
    Ut.href = Tt.href,
    N.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Tt.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Tt.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            accepts: {
                "*": Ht,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": N.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function (e, t) {
            return t ? Gt(Gt(e, N.ajaxSettings), t) : Gt(N.ajaxSettings, e)
        },
        ajaxPrefilter: Kt(qt),
        ajaxTransport: Kt(zt),
        ajax: function (e, t) {
            "object" == typeof e && (t = e, e = void 0);
            var l,
            c,
            u,
            n,
            d,
            p,
            g,
            r,
            i,
            f = N.ajaxSetup({}, t = t || {}),
            h = f.context || f,
            m = f.context && (h.nodeType || h.jquery) ? N(h) : N.event,
            b = N.Deferred(),
            y = N.Callbacks("once memory"),
            v = f.statusCode || {},
            a = {},
            s = {},
            o = "canceled",
            _ = {
                readyState: 0,
                getResponseHeader: function (e) {
                    var t;
                    if (p) {
                        if (!n)
                            for (n = {}; t = $t.exec(u); )
                                n[t[1].toLowerCase() + " "] = (n[t[1].toLowerCase() + " "] || []).concat(t[2]);
                        t = n[e.toLowerCase() + " "]
                    }
                    return null == t ? null : t.join(", ")
                },
                getAllResponseHeaders: function () {
                    return p ? u : null
                },
                setRequestHeader: function (e, t) {
                    return null == p && (e = s[e.toLowerCase()] = s[e.toLowerCase()] || e, a[e] = t),
                    this
                },
                overrideMimeType: function (e) {
                    return null == p && (f.mimeType = e),
                    this
                },
                statusCode: function (e) {
                    if (e)
                        if (p)
                            _.always(e[_.status]);
                        else
                            for (var t in e)
                                v[t] = [v[t], e[t]];
                    return this
                },
                abort: function (e) {
                    e = e || o;
                    return l && l.abort(e),
                    E(0, e),
                    this
                }
            };
            if (b.promise(_), f.url = ((e || f.url || Tt.href) + "").replace(Pt, Tt.protocol + "//"), f.type = t.method || t.type || f.method || f.type, f.dataTypes = (f.dataType || "*").toLowerCase().match(k) || [""], null == f.crossDomain) {
                i = x.createElement("a");
                try {
                    i.href = f.url,
                    i.href = i.href,
                    f.crossDomain = Ut.protocol + "//" + Ut.host != i.protocol + "//" + i.host
                } catch (e) {
                    f.crossDomain = !0
                }
            }
            if (f.data && f.processData && "string" != typeof f.data && (f.data = N.param(f.data, f.traditional)), Wt(qt, f, t, _), !p) {
                for (r in(g = N.event && f.global) && 0 == N.active++ && N.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !Ft.test(f.type), c = f.url.replace(Bt, ""), f.hasContent ? f.data && f.processData && 0 === (f.contentType || "").indexOf("application/x-www-form-urlencoded") && (f.data = f.data.replace(Lt, "+")) : (i = f.url.slice(c.length), f.data && (f.processData || "string" == typeof f.data) && (c += (Ot.test(c) ? "&" : "?") + f.data, delete f.data), !1 === f.cache && (c = c.replace(jt, "$1"), i = (Ot.test(c) ? "&" : "?") + "_=" + At.guid++ + i), f.url = c + i), f.ifModified && (N.lastModified[c] && _.setRequestHeader("If-Modified-Since", N.lastModified[c]), N.etag[c]) && _.setRequestHeader("If-None-Match", N.etag[c]), (f.data && f.hasContent && !1 !== f.contentType || t.contentType) && _.setRequestHeader("Content-Type", f.contentType), _.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + Ht + "; q=0.01" : "") : f.accepts["*"]), f.headers)
                    _.setRequestHeader(r, f.headers[r]);
                if (f.beforeSend && (!1 === f.beforeSend.call(h, _, f) || p))
                    return _.abort();
                if (o = "abort", y.add(f.complete), _.done(f.success), _.fail(f.error), l = Wt(zt, f, t, _)) {
                    if (_.readyState = 1, g && m.trigger("ajaxSend", [_, f]), p)
                        return _;
                    f.async && 0 < f.timeout && (d = w.setTimeout(function () {
                            _.abort("timeout")
                        }, f.timeout));
                    try {
                        p = !1,
                        l.send(a, E)
                    } catch (e) {
                        if (p)
                            throw e;
                        E(-1, e)
                    }
                } else
                    E(-1, "No Transport")
            }
            return _;
            function E(e, t, n, r) {
                var i,
                a,
                s,
                o = t;
                p || (p = !0, d && w.clearTimeout(d), l = void 0, u = r || "", _.readyState = 0 < e ? 4 : 0, r = 200 <= e && e < 300 || 304 === e, n && (s = function (e, t, n) {
                        for (var r, i, a, s, o = e.contents, l = e.dataTypes; "*" === l[0]; )
                            l.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type"));
                        if (r)
                            for (i in o)
                                if (o[i] && o[i].test(r)) {
                                    l.unshift(i);
                                    break
                                }
                        if (l[0]in n)
                            a = l[0];
                        else {
                            for (i in n) {
                                if (!l[0] || e.converters[i + " " + l[0]]) {
                                    a = i;
                                    break
                                }
                                s = s || i
                            }
                            a = a || s
                        }
                        if (a)
                            return a !== l[0] && l.unshift(a), n[a]
                    }
                        (f, _, n)), !r && -1 < N.inArray("script", f.dataTypes) && (f.converters["text script"] = function () {}), s = function (e, t, n, r) {
                    var i,
                    a,
                    s,
                    o,
                    l,
                    c = {},
                    u = e.dataTypes.slice();
                    if (u[1])
                        for (s in e.converters)
                            c[s.toLowerCase()] = e.converters[s];
                    for (a = u.shift(); a; )
                        if (e.responseFields[a] && (n[e.responseFields[a]] = t), !l && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = a, a = u.shift())
                            if ("*" === a)
                                a = l;
                            else if ("*" !== l && l !== a) {
                                if (!(s = c[l + " " + a] || c["* " + a]))
                                    for (i in c)
                                        if ((o = i.split(" "))[1] === a && (s = c[l + " " + o[0]] || c["* " + o[0]])) {
                                            !0 === s ? s = c[i] : !0 !== c[i] && (a = o[0], u.unshift(o[1]));
                                            break
                                        }
                                if (!0 !== s)
                                    if (s && e.throws)
                                        t = s(t);
                                    else
                                        try {
                                            t = s(t)
                                        } catch (e) {
                                            return {
                                                state: "parsererror",
                                                error: s ? e : "No conversion from " + l + " to " + a
                                            }
                                        }
                            }
                    return {
                        state: "success",
                        data: t
                    }
                }
                    (f, s, _, r), r ? (f.ifModified && ((n = _.getResponseHeader("Last-Modified")) && (N.lastModified[c] = n), n = _.getResponseHeader("etag")) && (N.etag[c] = n), 204 === e || "HEAD" === f.type ? o = "nocontent" : 304 === e ? o = "notmodified" : (o = s.state, i = s.data, r = !(a = s.error))) : (a = o, !e && o || (o = "error", e < 0 && (e = 0))), _.status = e, _.statusText = (t || o) + "", r ? b.resolveWith(h, [i, o, _]) : b.rejectWith(h, [_, o, a]), _.statusCode(v), v = void 0, g && m.trigger(r ? "ajaxSuccess" : "ajaxError", [_, f, r ? i : a]), y.fireWith(h, [_, o]), g && (m.trigger("ajaxComplete", [_, f]), --N.active || N.event.trigger("ajaxStop")))
            }
        },
        getJSON: function (e, t, n) {
            return N.get(e, t, n, "json")
        },
        getScript: function (e, t) {
            return N.get(e, void 0, t, "script")
        }
    }),
    N.each(["get", "post"], function (e, i) {
        N[i] = function (e, t, n, r) {
            return y(t) && (r = r || n, n = t, t = void 0),
            N.ajax(N.extend({
                    url: e,
                    type: i,
                    dataType: r,
                    data: t,
                    success: n
                }, N.isPlainObject(e) && e))
        }
    }),
    N.ajaxPrefilter(function (e) {
        for (var t in e.headers)
            "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "")
    }),
    N._evalUrl = function (e, t, n) {
        return N.ajax({
            url: e,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function () {}
            },
            dataFilter: function (e) {
                N.globalEval(e, t, n)
            }
        })
    },
    N.fn.extend({
        wrapAll: function (e) {
            return this[0] && (y(e) && (e = e.call(this[0])), e = N(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && e.insertBefore(this[0]), e.map(function () {
                    for (var e = this; e.firstElementChild; )
                        e = e.firstElementChild;
                    return e
                }).append(this)),
            this
        },
        wrapInner: function (n) {
            return y(n) ? this.each(function (e) {
                N(this).wrapInner(n.call(this, e))
            }) : this.each(function () {
                var e = N(this),
                t = e.contents();
                t.length ? t.wrapAll(n) : e.append(n)
            })
        },
        wrap: function (t) {
            var n = y(t);
            return this.each(function (e) {
                N(this).wrapAll(n ? t.call(this, e) : t)
            })
        },
        unwrap: function (e) {
            return this.parent(e).not("body").each(function () {
                N(this).replaceWith(this.childNodes)
            }),
            this
        }
    }),
    N.expr.pseudos.hidden = function (e) {
        return !N.expr.pseudos.visible(e)
    },
    N.expr.pseudos.visible = function (e) {
        return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)
    },
    N.ajaxSettings.xhr = function () {
        try {
            return new w.XMLHttpRequest
        } catch (e) {}
    };
    var Zt = {
        0: 200,
        1223: 204
    },
    Xt = N.ajaxSettings.xhr();
    m.cors = !!Xt && "withCredentials" in Xt,
    m.ajax = Xt = !!Xt,
    N.ajaxTransport(function (i) {
        var a,
        s;
        if (m.cors || Xt && !i.crossDomain)
            return {
                send: function (e, t) {
                    var n,
                    r = i.xhr();
                    if (r.open(i.type, i.url, i.async, i.username, i.password), i.xhrFields)
                        for (n in i.xhrFields)
                            r[n] = i.xhrFields[n];
                    for (n in i.mimeType && r.overrideMimeType && r.overrideMimeType(i.mimeType), i.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest"), e)
                        r.setRequestHeader(n, e[n]);
                    a = function (e) {
                        return function () {
                            a && (a = s = r.onload = r.onerror = r.onabort = r.ontimeout = r.onreadystatechange = null, "abort" === e ? r.abort() : "error" === e ? "number" != typeof r.status ? t(0, "error") : t(r.status, r.statusText) : t(Zt[r.status] || r.status, r.statusText, "text" !== (r.responseType || "text") || "string" != typeof r.responseText ? {
                                    binary: r.response
                                }
                                     : {
                                    text: r.responseText
                                }, r.getAllResponseHeaders()))
                        }
                    },
                    r.onload = a(),
                    s = r.onerror = r.ontimeout = a("error"),
                    void 0 !== r.onabort ? r.onabort = s : r.onreadystatechange = function () {
                        4 === r.readyState && w.setTimeout(function () {
                            a && s()
                        })
                    },
                    a = a("abort");
                    try {
                        r.send(i.hasContent && i.data || null)
                    } catch (e) {
                        if (a)
                            throw e
                    }
                },
                abort: function () {
                    a && a()
                }
            }
    }),
    N.ajaxPrefilter(function (e) {
        e.crossDomain && (e.contents.script = !1)
    }),
    N.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function (e) {
                return N.globalEval(e),
                e
            }
        }
    }),
    N.ajaxPrefilter("script", function (e) {
        void 0 === e.cache && (e.cache = !1),
        e.crossDomain && (e.type = "GET")
    }),
    N.ajaxTransport("script", function (n) {
        var r,
        i;
        if (n.crossDomain || n.scriptAttrs)
            return {
                send: function (e, t) {
                    r = N("<script>").attr(n.scriptAttrs || {}).prop({
                        charset: n.scriptCharset,
                        src: n.url
                    }).on("load error", i = function (e) {
                            r.remove(),
                            i = null,
                            e && t("error" === e.type ? 404 : 200, e.type)
                        }),
                    x.head.appendChild(r[0])
                },
                abort: function () {
                    i && i()
                }
            }
    });
    var Qt = [],
    Vt = /(=)\?(?=&|$)|\?\?/,
    Jt = (N.ajaxSetup({
            jsonp: "callback",
            jsonpCallback: function () {
                var e = Qt.pop() || N.expando + "_" + At.guid++;
                return this[e] = !0,
                e
            }
        }), N.ajaxPrefilter("json jsonp", function (e, t, n) {
            var r,
            i,
            a,
            s = !1 !== e.jsonp && (Vt.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && Vt.test(e.data) && "data");
            if (s || "jsonp" === e.dataTypes[0])
                return r = e.jsonpCallback = y(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, s ? e[s] = e[s].replace(Vt, "$1" + r) : !1 !== e.jsonp && (e.url += (Ot.test(e.url) ? "&" : "?") + e.jsonp + "=" + r), e.converters["script json"] = function () {
                    return a || N.error(r + " was not called"),
                    a[0]
                },
            e.dataTypes[0] = "json",
            i = w[r],
            w[r] = function () {
                a = arguments
            },
            n.always(function () {
                void 0 === i ? N(w).removeProp(r) : w[r] = i,
                e[r] && (e.jsonpCallback = t.jsonpCallback, Qt.push(r)),
                a && y(i) && i(a[0]),
                a = i = void 0
            }),
            "script"
        }), m.createHTMLDocument = ((e = x.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === e.childNodes.length), N.parseHTML = function (e, t, n) {
        return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (m.createHTMLDocument ? ((r = (t = x.implementation.createHTMLDocument("")).createElement("base")).href = x.location.href, t.head.appendChild(r)) : t = x), r = !n && [], (n = V.exec(e)) ? [t.createElement(n[1])] : (n = Ce([e], t, r), r && r.length && N(r).remove(), N.merge([], n.childNodes)));
        var r
    }, N.fn.load = function (e, t, n) {
        var r,
        i,
        a,
        s = this,
        o = e.indexOf(" ");
        return -1 < o && (r = I(e.slice(o)), e = e.slice(0, o)),
        y(t) ? (n = t, t = void 0) : t && "object" == typeof t && (i = "POST"),
        0 < s.length && N.ajax({
            url: e,
            type: i || "GET",
            dataType: "html",
            data: t
        }).done(function (e) {
            a = arguments,
            s.html(r ? N("<div>").append(N.parseHTML(e)).find(r) : e)
        }).always(n && function (e, t) {
            s.each(function () {
                n.apply(this, a || [e.responseText, t, e])
            })
        }),
        this
    }, N.expr.pseudos.animated = function (t) {
        return N.grep(N.timers, function (e) {
            return t === e.elem
        }).length
    }, N.offset = {
            setOffset: function (e, t, n) {
                var r,
                i,
                a,
                s,
                o = N.css(e, "position"),
                l = N(e),
                c = {};
                "static" === o && (e.style.position = "relative"),
                a = l.offset(),
                r = N.css(e, "top"),
                s = N.css(e, "left"),
                o = ("absolute" === o || "fixed" === o) && -1 < (r + s).indexOf("auto") ? (i = (o = l.position()).top, o.left) : (i = parseFloat(r) || 0, parseFloat(s) || 0),
                null != (t = y(t) ? t.call(e, n, N.extend({}, a)) : t).top && (c.top = t.top - a.top + i),
                null != t.left && (c.left = t.left - a.left + o),
                "using" in t ? t.using.call(e, c) : ("number" == typeof c.top && (c.top += "px"), "number" == typeof c.left && (c.left += "px"), l.css(c))
            }
        }, N.fn.extend({
            offset: function (t) {
                var e,
                n;
                return arguments.length ? void 0 === t ? this : this.each(function (e) {
                    N.offset.setOffset(this, t, e)
                }) : (n = this[0]) ? n.getClientRects().length ? (e = n.getBoundingClientRect(), n = n.ownerDocument.defaultView, {
                    top: e.top + n.pageYOffset,
                    left: e.left + n.pageXOffset
                }) : {
                    top: 0,
                    left: 0
                }
                 : void 0
            },
            position: function () {
                if (this[0]) {
                    var e,
                    t,
                    n,
                    r = this[0],
                    i = {
                        top: 0,
                        left: 0
                    };
                    if ("fixed" === N.css(r, "position"))
                        t = r.getBoundingClientRect();
                    else {
                        for (t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; e && (e === n.body || e === n.documentElement) && "static" === N.css(e, "position"); )
                            e = e.parentNode;
                        e && e !== r && 1 === e.nodeType && ((i = N(e).offset()).top += N.css(e, "borderTopWidth", !0), i.left += N.css(e, "borderLeftWidth", !0))
                    }
                    return {
                        top: t.top - i.top - N.css(r, "marginTop", !0),
                        left: t.left - i.left - N.css(r, "marginLeft", !0)
                    }
                }
            },
            offsetParent: function () {
                return this.map(function () {
                    for (var e = this.offsetParent; e && "static" === N.css(e, "position"); )
                        e = e.offsetParent;
                    return e || E
                })
            }
        }), N.each({
            scrollLeft: "pageXOffset",
            scrollTop: "pageYOffset"
        }, function (t, i) {
            var a = "pageYOffset" === i;
            N.fn[t] = function (e) {
                return d(this, function (e, t, n) {
                    var r;
                    if (h(e) ? r = e : 9 === e.nodeType && (r = e.defaultView), void 0 === n)
                        return r ? r[i] : e[t];
                    r ? r.scrollTo(a ? r.pageXOffset : n, a ? n : r.pageYOffset) : e[t] = n
                }, t, e, arguments.length)
            }
        }), N.each(["top", "left"], function (e, n) {
            N.cssHooks[n] = Ye(m.pixelPosition, function (e, t) {
                if (t)
                    return t = Je(e, n), Qe.test(t) ? N(e).position()[n] + "px" : t
            })
        }), N.each({
            Height: "height",
            Width: "width"
        }, function (s, o) {
            N.each({
                padding: "inner" + s,
                content: o,
                "": "outer" + s
            }, function (r, a) {
                N.fn[a] = function (e, t) {
                    var n = arguments.length && (r || "boolean" != typeof e),
                    i = r || (!0 === e || !0 === t ? "margin" : "border");
                    return d(this, function (e, t, n) {
                        var r;
                        return h(e) ? 0 === a.indexOf("outer") ? e["inner" + s] : e.document.documentElement["client" + s] : 9 === e.nodeType ? (r = e.documentElement, Math.max(e.body["scroll" + s], r["scroll" + s], e.body["offset" + s], r["offset" + s], r["client" + s])) : void 0 === n ? N.css(e, t, i) : N.style(e, t, n, i)
                    }, o, n ? e : void 0, n)
                }
            })
        }), N.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) {
            N.fn[t] = function (e) {
                return this.on(t, e)
            }
        }), N.fn.extend({
            bind: function (e, t, n) {
                return this.on(e, null, t, n)
            },
            unbind: function (e, t) {
                return this.off(e, null, t)
            },
            delegate: function (e, t, n, r) {
                return this.on(t, e, n, r)
            },
            undelegate: function (e, t, n) {
                return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
            },
            hover: function (e, t) {
                return this.mouseenter(e).mouseleave(t || e)
            }
        }), N.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function (e, n) {
            N.fn[n] = function (e, t) {
                return 0 < arguments.length ? this.on(n, null, e, t) : this.trigger(n)
            }
        }), /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g),
    Yt = (N.proxy = function (e, t) {
        var n,
        r;
        if ("string" == typeof t && (r = e[t], t = e, e = r), y(e))
            return n = o.call(arguments, 2), (r = function () {
                return e.apply(t || this, n.concat(o.call(arguments)))
            }).guid = e.guid = e.guid || N.guid++, r
    }, N.holdReady = function (e) {
        e ? N.readyWait++ : N.ready(!0)
    }, N.isArray = Array.isArray, N.parseJSON = JSON.parse, N.nodeName = l, N.isFunction = y, N.isWindow = h, N.camelCase = v, N.type = f, N.now = Date.now, N.isNumeric = function (e) {
        var t = N.type(e);
        return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e))
    }, N.trim = function (e) {
        return null == e ? "" : (e + "").replace(Jt, "")
    }, "function" == typeof define && define.amd && define("jquery", [], function () {
            return N
        }), w.jQuery),
    en = w.$;
    return N.noConflict = function (e) {
        return w.$ === N && (w.$ = en),
        e && w.jQuery === N && (w.jQuery = Yt),
        N
    },
    void 0 === B && (w.jQuery = w.$ = N),
    N
}), function (a) {
    "use strict";
    a.fn.fitVids = function (e) {
        var t,
        n,
        i = {
            customSelector: null,
            ignore: null
        };
        return document.getElementById("fit-vids-style") || (t = document.head || document.getElementsByTagName("head")[0], (n = document.createElement("div")).innerHTML = '<p>x</p><style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style>', t.appendChild(n.childNodes[1])),
        e && a.extend(i, e),
        this.each(function () {
            var e = ["iframe[src*='player.vimeo.com']", "iframe[src*='youtube.com']", "iframe[src*='youtube-nocookie.com']", "iframe[src*='kickstarter.com'][src*='video.html']", "object", "embed"],
            r = (i.customSelector && e.push(i.customSelector), ".fitvidsignore"),
            e = (i.ignore && (r = r + ", " + i.ignore), a(this).find(e.join(",")));
            (e = (e = e.not("object object")).not(r)).each(function () {
                var e,
                t,
                n = a(this);
                0 < n.parents(r).length || "embed" === this.tagName.toLowerCase() && n.parent("object").length || n.parent(".fluid-width-video-wrapper").length || (n.css("height") || n.css("width") || !isNaN(n.attr("height")) && !isNaN(n.attr("width")) || (n.attr("height", 9), n.attr("width", 16)), e = ("object" === this.tagName.toLowerCase() || n.attr("height") && !isNaN(parseInt(n.attr("height"), 10)) ? parseInt(n.attr("height"), 10) : n.height()) / (isNaN(parseInt(n.attr("width"), 10)) ? n.width() : parseInt(n.attr("width"), 10)), n.attr("id") || (t = "fitvid" + Math.floor(999999 * Math.random()), n.attr("id", t)), n.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top", 100 * e + "%"), n.removeAttr("height").removeAttr("width"))
            })
        })
    }
}
(window.jQuery || window.Zepto);
var hljs = function () {
    "use strict";
    var p = {
        exports: {}
    };
    function n(t) {
        return t instanceof Map ? t.clear = t.delete = t.set = () => {
            throw Error("map is read-only")
        }
         : t instanceof Set && (t.add = t.clear = t.delete = () => {
                throw Error("set is read-only")
            }),
        Object.freeze(t),
        Object.getOwnPropertyNames(t).forEach(e => {
            e = t[e];
            "object" != typeof e || Object.isFrozen(e) || n(e)
        }),
        t
    }
    p.exports = n,
    p.exports.default = n;
    class M {
        constructor(e) {
            void 0 === e.data && (e.data = {}),
            this.data = e.data,
            this.isMatchIgnored = !1
        }
        ignoreMatch() {
            this.isMatchIgnored = !0
        }
    }
    function t(e) {
        return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
    }
    function l(e, ...t) {
        const n = Object.create(null);
        for (const t in e)
            n[t] = e[t];
        return t.forEach(e => {
            for (const t in e)
                n[t] = e[t]
        }),
        n
    }
    const i = e => !!e.scope || e.sublanguage && e.language;
    class x {
        constructor(e, t) {
            this.buffer = "",
            this.classPrefix = t.classPrefix,
            e.walk(this)
        }
        addText(e) {
            this.buffer += t(e)
        }
        openNode(e) {
            var t,
            n,
            r;
            i(e) && (r = "", r = e.sublanguage ? "language-" + e.language : ([e, t] = [e.scope, {
                                prefix: this.classPrefix
                            }
                            ["prefix"]], e.includes(".") ? ["" + t + (n = e.split(".")).shift(), ...n.map((e, t) => "" + e + "_".repeat(t + 1))].join(" ") : "" + t + e), this.span(r))
        }
        closeNode(e) {
            i(e) && (this.buffer += "</span>")
        }
        value() {
            return this.buffer
        }
        span(e) {
            this.buffer += `<span class="${e}">`
        }
    }
    const r = (e = {}) => {
        var t = {
            children: []
        };
        return Object.assign(t, e),
        t
    };
    class a {
        constructor() {
            this.rootNode = r(),
            this.stack = [this.rootNode]
        }
        get top() {
            return this.stack[this.stack.length - 1]
        }
        get root() {
            return this.rootNode
        }
        add(e) {
            this.top.children.push(e)
        }
        openNode(e) {
            e = r({
                scope: e
            });
            this.add(e),
            this.stack.push(e)
        }
        closeNode() {
            if (1 < this.stack.length)
                return this.stack.pop()
        }
        closeAllNodes() {
            for (; this.closeNode(); );
        }
        toJSON() {
            return JSON.stringify(this.rootNode, null, 4)
        }
        walk(e) {
            return this.constructor._walk(e, this.rootNode)
        }
        static _walk(t, e) {
            return "string" == typeof e ? t.addText(e) : e.children && (t.openNode(e), e.children.forEach(e => this._walk(t, e)), t.closeNode(e)),
            t
        }
        static _collapse(e) {
            "string" != typeof e && e.children && (e.children.every(e => "string" == typeof e) ? e.children = [e.children.join("")] : e.children.forEach(e => {
                    a._collapse(e)
                }))
        }
    }
    class z extends a {
        constructor(e) {
            super(),
            this.options = e
        }
        addKeyword(e, t) {
            "" !== e && (this.openNode(t), this.addText(e), this.closeNode())
        }
        addText(e) {
            "" !== e && this.add(e)
        }
        addSublanguage(e, t) {
            e = e.root;
            e.sublanguage = !0,
            e.language = t,
            this.add(e)
        }
        toHTML() {
            return new x(this, this.options).value()
        }
        finalize() {
            return !0
        }
    }
    function c(e) {
        return e ? "string" == typeof e ? e : e.source : null
    }
    function D(e) {
        return R("(?=", e, ")")
    }
    function H(e) {
        return R("(?:", e, ")*")
    }
    function U(e) {
        return R("(?:", e, ")?")
    }
    function R(...e) {
        return e.map(e => c(e)).join("")
    }
    function I(...e) {
        var t,
        n = "object" == typeof(t = (n = e)[n.length - 1]) && t.constructor === Object ? (n.splice(n.length - 1, 1), t) : {};
        return "(" + (n.capture ? "" : "?:") + e.map(e => c(e)).join("|") + ")"
    }
    function N(e) {
        return RegExp(e.toString() + "|").exec("").length - 1
    }
    const k = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;
    function u(e, {
        joinWith: t
    }) {
        let i = 0;
        return e.map(e => {
            var t = i += 1;
            let n = c(e),
            r = "";
            for (; 0 < n.length; ) {
                const e = k.exec(n);
                if (!e) {
                    r += n;
                    break
                }
                r += n.substring(0, e.index),
                n = n.substring(e.index + e[0].length),
                "\\" === e[0][0] && e[1] ? r += "\\" + (Number(e[1]) + t) : (r += e[0], "(" === e[0] && i++)
            }
            return r
        }).map(e => `(${e})`).join(t)
    }
    var S = "[a-zA-Z]\\w*",
    T = "[a-zA-Z_]\\w*",
    A = "\\b\\d+(\\.\\d+)?",
    K = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)",
    W = "\\b(0b[01]+)",
    e = {
        begin: "\\\\[\\s\\S]",
        relevance: 0
    },
    s = {
        scope: "string",
        begin: "'",
        end: "'",
        illegal: "\\n",
        contains: [e]
    },
    o = {
        scope: "string",
        begin: '"',
        end: '"',
        illegal: "\\n",
        contains: [e]
    },
    d = (e, t, n = {}) => {
        e = l({
            scope: "comment",
            begin: e,
            end: t,
            contains: []
        }, n),
        e.contains.push({
            scope: "doctag",
            begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
            end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
            excludeBegin: !0,
            relevance: 0
        }),
        t = I("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/);
        return e.contains.push({
            begin: R(/[ ]+/, "(", t, /[.]?[:]?([.][ ]|[ ])/, "){3}")
        }),
        e
    },
    G = d("//", "$"),
    Z = d("/\\*", "\\*/"),
    X = d("#", "$"),
    g = Object.freeze({
        __proto__: null,
        MATCH_NOTHING_RE: /\b\B/,
        IDENT_RE: S,
        UNDERSCORE_IDENT_RE: T,
        NUMBER_RE: A,
        C_NUMBER_RE: K,
        BINARY_NUMBER_RE: W,
        RE_STARTERS_RE: "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~",
        SHEBANG: (e = {}) => {
            var t = /^#![ ]*\//;
            return e.binary && (e.begin = R(t, /.*\b/, e.binary, /\b.*/)),
            l({
                scope: "meta",
                begin: t,
                end: /$/,
                relevance: 0,
                "on:begin": (e, t) => {
                    0 !== e.index && t.ignoreMatch()
                }
            }, e)
        },
        BACKSLASH_ESCAPE: e,
        APOS_STRING_MODE: s,
        QUOTE_STRING_MODE: o,
        PHRASAL_WORDS_MODE: {
            begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/
        },
        COMMENT: d,
        C_LINE_COMMENT_MODE: G,
        C_BLOCK_COMMENT_MODE: Z,
        HASH_COMMENT_MODE: X,
        NUMBER_MODE: {
            scope: "number",
            begin: A,
            relevance: 0
        },
        C_NUMBER_MODE: {
            scope: "number",
            begin: K,
            relevance: 0
        },
        BINARY_NUMBER_MODE: {
            scope: "number",
            begin: W,
            relevance: 0
        },
        REGEXP_MODE: {
            begin: /(?=\/[^/\n]*\/)/,
            contains: [{
                    scope: "regexp",
                    begin: /\//,
                    end: /\/[gimuy]*/,
                    illegal: /\n/,
                    contains: [e, {
                            begin: /\[/,
                            end: /\]/,
                            relevance: 0,
                            contains: [e]
                        }
                    ]
                }
            ]
        },
        TITLE_MODE: {
            scope: "title",
            begin: S,
            relevance: 0
        },
        UNDERSCORE_TITLE_MODE: {
            scope: "title",
            begin: T,
            relevance: 0
        },
        METHOD_GUARD: {
            begin: "\\.\\s*[a-zA-Z_]\\w*",
            relevance: 0
        },
        END_SAME_AS_BEGIN: e => Object.assign(e, {
            "on:begin": (e, t) => {
                t.data._beginMatch = e[1]
            },
            "on:end": (e, t) => {
                t.data._beginMatch !== e[1] && t.ignoreMatch()
            }
        })
    });
    function Q(e, t) {
        "." === e.input[e.index - 1] && t.ignoreMatch()
    }
    const V = (t, e) => {
        if (t.beforeMatch) {
            if (t.starts)
                throw Error("beforeMatch cannot be used with starts");
            var n = Object.assign({}, t);
            Object.keys(t).forEach(e => {
                delete t[e]
            }),
            t.keywords = n.keywords,
            t.begin = R(n.beforeMatch, D(n.begin)),
            t.starts = {
                relevance: 0,
                contains: [Object.assign(n, {
                        endsParent: !0
                    })]
            },
            t.relevance = 0,
            delete n.beforeMatch
        }
    },
    J = ["of", "and", "for", "in", "not", "or", "if", "then", "parent", "list", "value"];
    function Y(t, r, e = "keyword") {
        const i = Object.create(null);
        return "string" == typeof t ? n(e, t.split(" ")) : Array.isArray(t) ? n(e, t) : Object.keys(t).forEach(e => {
            Object.assign(i, Y(t[e], r, e))
        }),
        i;
        function n(n, e) {
            (e = r ? e.map(e => e.toLowerCase()) : e).forEach(e => {
                var t,
                e = e.split("|");
                i[e[0]] = [n, (t = e[0], (e = e[1]) ? Number(e) : (e => J.includes(e.toLowerCase()))(t) ? 0 : 1)]
            })
        }
    }
    const ee = {},
    L = e => {
        console.error(e)
    },
    te = (e, ...t) => {
        console.log("WARN: " + e, ...t)
    },
    f = (e, t) => {
        ee[e + "/" + t] || (console.log(`Deprecated as of ${e}. ` + t), ee[e + "/" + t] = !0)
    },
    h = Error();
    function ne(e, t, {
        key: n
    }) {
        let r = 0;
        var i = e[n],
        a = {},
        s = {};
        for (let e = 1; e <= t.length; e++)
            s[e + r] = i[e], a[e + r] = !0, r += N(t[e - 1]);
        e[n] = s,
        e[n]._emit = a,
        e[n]._multi = !0
    }
    function re(a) {
        function s(e, t) {
            return RegExp(c(e), "m" + (a.case_insensitive ? "i" : "") + (a.unicodeRegex ? "u" : "") + (t ? "g" : ""))
        }
        class t {
            constructor() {
                this.matchIndexes = {},
                this.regexes = [],
                this.matchAt = 1,
                this.position = 0
            }
            addRule(e, t) {
                t.position = this.position++,
                this.matchIndexes[this.matchAt] = t,
                this.regexes.push([t, e]),
                this.matchAt += N(e) + 1
            }
            compile() {
                0 === this.regexes.length && (this.exec = () => null);
                var e = this.regexes.map(e => e[1]);
                this.matcherRe = s(u(e, {
                            joinWith: "|"
                        }), !0),
                this.lastIndex = 0
            }
            exec(e) {
                this.matcherRe.lastIndex = this.lastIndex;
                var t,
                n,
                e = this.matcherRe.exec(e);
                return e ? (t = e.findIndex((e, t) => 0 < t && void 0 !== e), n = this.matchIndexes[t], e.splice(0, t), Object.assign(e, n)) : null
            }
        }
        class o {
            constructor() {
                this.rules = [],
                this.multiRegexes = [],
                this.count = 0,
                this.lastIndex = 0,
                this.regexIndex = 0
            }
            getMatcher(e) {
                if (this.multiRegexes[e])
                    return this.multiRegexes[e];
                const n = new t;
                return this.rules.slice(e).forEach(([e, t]) => n.addRule(e, t)),
                n.compile(),
                this.multiRegexes[e] = n
            }
            resumingScanAtSamePosition() {
                return 0 !== this.regexIndex
            }
            considerAll() {
                this.regexIndex = 0
            }
            addRule(e, t) {
                this.rules.push([e, t]),
                "begin" === t.type && this.count++
            }
            exec(e) {
                const t = this.getMatcher(this.regexIndex);
                t.lastIndex = this.lastIndex;
                let n = t.exec(e);
                if (this.resumingScanAtSamePosition() && (!n || n.index !== this.lastIndex)) {
                    const t = this.getMatcher(0);
                    t.lastIndex = this.lastIndex + 1,
                    n = t.exec(e)
                }
                return n && (this.regexIndex += n.position + 1, this.regexIndex === this.count) && this.considerAll(),
                n
            }
        }
        if (a.compilerExtensions || (a.compilerExtensions = []), a.contains && a.contains.includes("self"))
            throw Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
        return a.classNameAliases = l(a.classNameAliases || {}),
        function t(n, r) {
            const i = n;
            if (!n.isCompiled) {
                [function (e, t) {
                        void 0 !== e.className && (e.scope = e.className, delete e.className)
                    }, function (e, t) {
                        if (e.match) {
                            if (e.begin || e.end)
                                throw Error("begin & end are not supported with match");
                            e.begin = e.match,
                            delete e.match
                        }
                    }, function (e) {
                        if ((t = e).scope && "object" == typeof t.scope && null !== t.scope && (t.beginScope = t.scope, delete t.scope), "string" == typeof e.beginScope && (e.beginScope = {
                                    _wrap: e.beginScope
                                }), "string" == typeof e.endScope && (e.endScope = {
                                    _wrap: e.endScope
                                }), t = e, Array.isArray(t.begin)) {
                            if (t.skip || t.excludeBegin || t.returnBegin)
                                throw L("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), h;
                            if ("object" != typeof t.beginScope || null === t.beginScope)
                                throw L("beginScope must be object"), h;
                            ne(t, t.begin, {
                                key: "beginScope"
                            }),
                            t.begin = u(t.begin, {
                                joinWith: ""
                            })
                        }
                        var t = e;
                        if (Array.isArray(t.end)) {
                            if (t.skip || t.excludeEnd || t.returnEnd)
                                throw L("skip, excludeEnd, returnEnd not compatible with endScope: {}"), h;
                            if ("object" != typeof t.endScope || null === t.endScope)
                                throw L("endScope must be object"), h;
                            ne(t, t.end, {
                                key: "endScope"
                            }),
                            t.end = u(t.end, {
                                joinWith: ""
                            })
                        }
                    }, V].forEach(e => e(n, r)),
                a.compilerExtensions.forEach(e => e(n, r)),
                n.__beforeBegin = null,
                [function (e, t) {
                        t && e.beginKeywords && (e.begin = "\\b(" + e.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", e.__beforeBegin = Q, e.keywords = e.keywords || e.beginKeywords, delete e.beginKeywords, void 0 === e.relevance) && (e.relevance = 0)
                    }, function (e, t) {
                        Array.isArray(e.illegal) && (e.illegal = I(...e.illegal))
                    }, function (e, t) {
                        void 0 === e.relevance && (e.relevance = 1)
                    }
                ].forEach(e => e(n, r)),
                n.isCompiled = !0;
                let e = null;
                "object" == typeof n.keywords && n.keywords.$pattern && (n.keywords = Object.assign({}, n.keywords), e = n.keywords.$pattern, delete n.keywords.$pattern),
                e = e || /\w+/,
                n.keywords && (n.keywords = Y(n.keywords, a.case_insensitive)),
                i.keywordPatternRe = s(e, !0),
                r && (n.begin || (n.begin = /\B|\b/), i.beginRe = s(i.begin), n.end || n.endsWithParent || (n.end = /\B|\b/), n.end && (i.endRe = s(i.end)), i.terminatorEnd = c(i.end) || "", n.endsWithParent) && r.terminatorEnd && (i.terminatorEnd += (n.end ? "|" : "") + r.terminatorEnd),
                n.illegal && (i.illegalRe = s(n.illegal)),
                n.contains || (n.contains = []),
                n.contains = [].concat(...n.contains.map(e => {
                        return (t = "self" === e ? n : e).variants && !t.cachedVariants && (t.cachedVariants = t.variants.map(e => l(t, {
                                        variants: null
                                    }, e))),
                        t.cachedVariants || (function e(t) {
                            return !!t && (t.endsWithParent || e(t.starts))
                        }
                            (t) ? l(t, {
                                starts: t.starts ? l(t.starts) : null
                            }) : Object.isFrozen(t) ? l(t) : t);
                        var t
                    })),
                n.contains.forEach(e => {
                    t(e, i)
                }),
                n.starts && t(n.starts, r),
                i.matcher = (e => {
                    const t = new o;
                    return e.contains.forEach(e => t.addRule(e.begin, {
                            rule: e,
                            type: "begin"
                        })),
                    e.terminatorEnd && t.addRule(e.terminatorEnd, {
                        type: "end"
                    }),
                    e.illegal && t.addRule(e.illegal, {
                        type: "illegal"
                    }),
                    t
                })(i)
            }
            return i
        }
        (a)
    }
    class ie extends Error {
        constructor(e, t) {
            super(e),
            this.name = "HTMLInjectionError",
            this.html = t
        }
    }
    const B = t,
    ae = l,
    se = Symbol("nomatch");
    s = (r => {
        const N = Object.create(null),
        s = Object.create(null),
        i = [];
        let k = !0;
        const C = "Could not find the language '{}', did you forget to load/include a language module?",
        a = {
            disableAutodetect: !0,
            name: "Plain text",
            contains: []
        };
        let S = {
            ignoreUnescapedHTML: !1,
            throwUnescapedHTML: !1,
            noHighlightRe: /^(no-?highlight)$/i,
            languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
            classPrefix: "hljs-",
            cssSelector: "pre code",
            languages: null,
            __emitter: z
        };
        function o(e) {
            return S.noHighlightRe.test(e)
        }
        function l(e, t, n) {
            let r = "",
            i = "";
            "object" == typeof t ? (r = e, n = t.ignoreIllegals, i = t.language) : (f("10.7.0", "highlight(lang, code, ...args) has been deprecated."), f("10.7.0", "Please use highlight(code, options) instead.\nhttps://github.com/highlightjs/highlight.js/issues/2277"), i = e, r = t),
            void 0 === n && (n = !0);
            e = {
                code: r,
                language: i
            },
            d("before:highlight", e),
            t = e.result || T(e.language, e.code, n);
            return t.code = e.code,
            d("after:highlight", t),
            t
        }
        function T(o, l, c, e) {
            const s = Object.create(null);
            function a() {
                if (!h.keywords)
                    return b.addText(v);
                let e = 0,
                t = (h.keywordPatternRe.lastIndex = 0, h.keywordPatternRe.exec(v)),
                n = "";
                for (; t; ) {
                    n += v.substring(e, t.index);
                    var r = f.case_insensitive ? t[0].toLowerCase() : t[0],
                    i = (a = r, h.keywords[a]);
                    if (i) {
                        const [e, a] = i;
                        if (b.addText(n), n = "", s[r] = (s[r] || 0) + 1, s[r] <= 7 && (_ += a), e.startsWith("_"))
                            n += t[0];
                        else {
                            const n = f.classNameAliases[e] || e;
                            b.addKeyword(t[0], n)
                        }
                    } else
                        n += t[0];
                    e = h.keywordPatternRe.lastIndex,
                    t = h.keywordPatternRe.exec(v)
                }
                var a;
                n += v.substring(e),
                b.addText(n)
            }
            function u() {
                (null != h.subLanguage ? () => {
                    if ("" !== v) {
                        let e = null;
                        if ("string" == typeof h.subLanguage) {
                            if (!N[h.subLanguage])
                                return void b.addText(v);
                            e = T(h.subLanguage, v, !0, m[h.subLanguage]),
                            m[h.subLanguage] = e._top
                        } else
                            e = A(v, h.subLanguage.length ? h.subLanguage : null);
                        0 < h.relevance && (_ += e.relevance),
                        b.addSublanguage(e._emitter, e.language)
                    }
                }
                     : a)(),
                v = ""
            }
            function i(e, t) {
                let n = 1;
                const r = t.length - 1;
                for (; n <= r; ) {
                    if (e._emit[n]) {
                        const r = f.classNameAliases[e[n]] || e[n],
                        i = t[n];
                        r ? b.addKeyword(i, r) : (v = i, a(), v = "")
                    }
                    n++
                }
            }
            function d(e, t) {
                e.scope && "string" == typeof e.scope && b.openNode(f.classNameAliases[e.scope] || e.scope),
                e.beginScope && (e.beginScope._wrap ? (b.addKeyword(v, f.classNameAliases[e.beginScope._wrap] || e.beginScope._wrap), v = "") : e.beginScope._multi && (i(e.beginScope, t), v = "")),
                h = Object.create(e, {
                    parent: {
                        value: h
                    }
                })
            }
            function p(e) {
                var t = e[0],
                n = l.substring(e.index),
                r = function e(t, n, r) {
                    let i = (e => (e = e && e.exec(r)) && 0 === e.index)(t.endRe);
                    if (i) {
                        if (t["on:end"]) {
                            const r = new M(t);
                            t["on:end"](n, r),
                            r.isMatchIgnored && (i = !1)
                        }
                        if (i) {
                            for (; t.endsParent && t.parent; )
                                t = t.parent;
                            return t
                        }
                    }
                    if (t.endsWithParent)
                        return e(t.parent, n, r)
                }
                (h, e, n);
                if (!r)
                    return se;
                n = h;
                for (h.endScope && h.endScope._wrap ? (u(), b.addKeyword(t, h.endScope._wrap)) : h.endScope && h.endScope._multi ? (u(), i(h.endScope, e)) : n.skip ? v += t : (n.returnEnd || n.excludeEnd || (v += t), u(), n.excludeEnd && (v = t)); h.scope && b.closeNode(), h.skip || h.subLanguage || (_ += h.relevance), (h = h.parent) !== r.parent; );
                return r.starts && d(r.starts, e),
                n.returnEnd ? 0 : t.length
            }
            let g = {};
            function t(e, t) {
                var n = t && t[0];
                if (v += e, null == n)
                    return u(), 0;
                if ("begin" === g.type && "end" === t.type && g.index === t.index && "" === n) {
                    if (v += l.slice(t.index, t.index + 1), k)
                        return 1; {
                        const l = Error(`0 width match regex (${o})`);
                        throw l.languageName = o,
                        l.badRule = g.rule,
                        l
                    }
                }
                if ("begin" === (g = t).type) {
                    var r,
                    i = t,
                    a = i[0],
                    e = i.rule,
                    s = new M(e);
                    for (const M of[e.__beforeBegin, e["on:begin"]])
                        if (M && (M(i, s), s.isMatchIgnored))
                            return r = a, 0 === h.matcher.regexIndex ? (v += r[0], 1) : (x = !0, 0);
                    return e.skip ? v += a : (e.excludeBegin && (v += a), u(), e.returnBegin || e.excludeBegin || (v = a)),
                    d(e, i),
                    e.returnBegin ? 0 : a.length
                }
                if ("illegal" === t.type && !c) {
                    const o = Error('Illegal lexeme "' + n + '" for mode "' + (h.scope || "<unnamed>") + '"');
                    throw o.mode = h,
                    o
                }
                if ("end" === t.type) {
                    const o = p(t);
                    if (o !== se)
                        return o
                }
                if ("illegal" === t.type && "" === n)
                    return 1;
                if (1e5 < w && w > 3 * t.index)
                    throw Error("potential infinite loop, way more iterations than matches");
                return v += n,
                n.length
            }
            const f = O(o);
            if (!f)
                throw L(C.replace("{}", o)), Error('Unknown language: "' + o + '"');
            var n = re(f);
            let r = "",
            h = e || n;
            const m = {},
            b = new S.__emitter(S);
            var y = [];
            for (let e = h; e !== f; e = e.parent)
                e.scope && y.unshift(e.scope);
            y.forEach(e => b.openNode(e));
            let v = "",
            _ = 0,
            E = 0,
            w = 0,
            x = !1;
            try {
                for (h.matcher.considerAll(); ; ) {
                    w++,
                    x ? x = !1 : h.matcher.considerAll(),
                    h.matcher.lastIndex = E;
                    const o = h.matcher.exec(l);
                    if (!o)
                        break;
                    const M = t(l.substring(E, o.index), o);
                    E = o.index + M
                }
                return t(l.substring(E)),
                b.closeAllNodes(),
                b.finalize(),
                r = b.toHTML(), {
                    language: o,
                    value: r,
                    relevance: _,
                    illegal: !1,
                    _emitter: b,
                    _top: h
                }
            } catch (e) {
                if (e.message && e.message.includes("Illegal"))
                    return {
                        language: o,
                        value: B(l),
                        illegal: !0,
                        relevance: 0,
                        _illegalBy: {
                            message: e.message,
                            index: E,
                            context: l.slice(E - 100, E + 100),
                            mode: e.mode,
                            resultSoFar: r
                        },
                        _emitter: b
                    };
                if (k)
                    return {
                        language: o,
                        value: B(l),
                        illegal: !1,
                        relevance: 0,
                        errorRaised: e,
                        _emitter: b,
                        _top: h
                    };
                throw e
            }
        }
        function A(t, e) {
            e = e || S.languages || Object.keys(N);
            n = t,
            (r = {
                    value: B(n),
                    illegal: !1,
                    relevance: 0,
                    _top: a,
                    _emitter: new S.__emitter(S)
                })._emitter.addText(n);
            var n = r,
            r = e.filter(O).filter(u).map(e => T(e, t, !1)),
            e = (r.unshift(n), r.sort((e, t) => {
                    if (e.relevance !== t.relevance)
                        return t.relevance - e.relevance;
                    if (e.language && t.language) {
                        if (O(e.language).supersetOf === t.language)
                            return 1;
                        if (O(t.language).supersetOf === e.language)
                            return -1
                    }
                    return 0
                })),
            [n, r] = e,
            e = n;
            return e.secondBest = r,
            e
        }
        function t(e) {
            var t = (e => {
                let t = e.className + " ";
                t += e.parentNode ? e.parentNode.className : "";
                var n = S.languageDetectRe.exec(t);
                if (n) {
                    const t = O(n[1]);
                    return t || (te(C.replace("{}", n[1])), te("Falling back to no-highlight mode for this block.", e)),
                    t ? n[1] : "no-highlight"
                }
                return t.split(/\s+/).find(e => o(e) || O(e))
            })(e);
            if (!o(t)) {
                if (d("before:highlightElement", {
                        el: e,
                        language: t
                    }), 0 < e.children.length && (S.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(e)), S.throwUnescapedHTML))
                    throw new ie("One of your code blocks includes unescaped HTML.", e.innerHTML);
                var n = e.textContent,
                r = t ? l(n, {
                    language: t,
                    ignoreIllegals: !0
                }) : A(n),
                i = (e.innerHTML = r.value, e),
                a = r.language;
                t = t && s[t] || a,
                i.classList.add("hljs"),
                i.classList.add("language-" + t),
                e.result = {
                    language: r.language,
                    re: r.relevance,
                    relevance: r.relevance
                },
                r.secondBest && (e.secondBest = {
                        language: r.secondBest.language,
                        relevance: r.secondBest.relevance
                    }),
                d("after:highlightElement", {
                    el: e,
                    result: r,
                    text: n
                })
            }
        }
        let e = !1;
        function n() {
            "loading" !== document.readyState ? document.querySelectorAll(S.cssSelector).forEach(t) : e = !0
        }
        function O(e) {
            return e = (e || "").toLowerCase(),
            N[e] || N[s[e]]
        }
        function c(e, {
            languageName: t
        }) {
            (e = "string" == typeof e ? [e] : e).forEach(e => {
                s[e.toLowerCase()] = t
            })
        }
        function u(e) {
            e = O(e);
            return e && !e.disableAutodetect
        }
        function d(e, t) {
            const n = e;
            i.forEach(e => {
                e[n] && e[n](t)
            })
        }
        "undefined" != typeof window && window.addEventListener && window.addEventListener("DOMContentLoaded", () => {
            e && n()
        }, !1),
        Object.assign(r, {
            highlight: l,
            highlightAuto: A,
            highlightAll: n,
            highlightElement: t,
            highlightBlock: e => (f("10.7.0", "highlightBlock will be removed entirely in v12.0"), f("10.7.0", "Please use highlightElement now."), t(e)),
            configure: e => {
                S = ae(S, e)
            },
            initHighlighting: () => {
                n(),
                f("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.")
            },
            initHighlightingOnLoad: () => {
                n(),
                f("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.")
            },
            registerLanguage: (t, e) => {
                let n = null;
                try {
                    n = e(r)
                } catch (e) {
                    if (L("Language definition for '{}' could not be registered.".replace("{}", t)), !k)
                        throw e;
                    L(e),
                    n = a
                }
                n.name || (n.name = t),
                (N[t] = n).rawDefinition = e.bind(null, r),
                n.aliases && c(n.aliases, {
                    languageName: t
                })
            },
            unregisterLanguage: e => {
                delete N[e];
                for (const t of Object.keys(s))
                    s[t] === e && delete s[t]
            },
            listLanguages: () => Object.keys(N),
            getLanguage: O,
            registerAliases: c,
            autoDetection: u,
            inherit: ae,
            addPlugin: e => {
                var t;
                (t = e)["before:highlightBlock"] && !t["before:highlightElement"] && (t["before:highlightElement"] = e => {
                        t["before:highlightBlock"](Object.assign({
                                block: e.el
                            }, e))
                    }),
                t["after:highlightBlock"] && !t["after:highlightElement"] && (t["after:highlightElement"] = e => {
                        t["after:highlightBlock"](Object.assign({
                                block: e.el
                            }, e))
                    }),
                i.push(e)
            }
        }),
        r.debugMode = () => {
            k = !1
        },
        r.safeMode = () => {
            k = !0
        },
        r.versionString = "11.6.0",
        r.regex = {
            concat: R,
            lookahead: D,
            either: I,
            optional: U,
            anyNumberOfTimes: H
        };
        for (const r in g)
            "object" == typeof g[r] && p.exports(g[r]);
        return Object.assign(r, g),
        r
    })({});
    const m = e => ({
        IMPORTANT: {
            scope: "meta",
            begin: "!important"
        },
        BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
        HEXCOLOR: {
            scope: "number",
            begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
        },
        FUNCTION_DISPATCH: {
            className: "built_in",
            begin: /[\w-]+(?=\()/
        },
        ATTRIBUTE_SELECTOR_MODE: {
            scope: "selector-attr",
            begin: /\[/,
            end: /\]/,
            illegal: "$",
            contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
        },
        CSS_NUMBER_MODE: {
            scope: "number",
            begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
            relevance: 0
        },
        CSS_VARIABLE: {
            className: "attr",
            begin: /--[A-Za-z][A-Za-z0-9_-]*/
        }
    }),
    b = ["a", "abbr", "address", "article", "aside", "audio", "b", "blockquote", "body", "button", "canvas", "caption", "cite", "code", "dd", "del", "details", "dfn", "div", "dl", "dt", "em", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hgroup", "html", "i", "iframe", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "mark", "menu", "nav", "object", "ol", "p", "q", "quote", "samp", "section", "span", "strong", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "tr", "ul", "var", "video"],
    y = ["any-hover", "any-pointer", "aspect-ratio", "color", "color-gamut", "color-index", "device-aspect-ratio", "device-height", "device-width", "display-mode", "forced-colors", "grid", "height", "hover", "inverted-colors", "monochrome", "orientation", "overflow-block", "overflow-inline", "pointer", "prefers-color-scheme", "prefers-contrast", "prefers-reduced-motion", "prefers-reduced-transparency", "resolution", "scan", "scripting", "update", "width", "min-width", "max-width", "min-height", "max-height"],
    v = ["active", "any-link", "blank", "checked", "current", "default", "defined", "dir", "disabled", "drop", "empty", "enabled", "first", "first-child", "first-of-type", "fullscreen", "future", "focus", "focus-visible", "focus-within", "has", "host", "host-context", "hover", "indeterminate", "in-range", "invalid", "is", "lang", "last-child", "last-of-type", "left", "link", "local-link", "not", "nth-child", "nth-col", "nth-last-child", "nth-last-col", "nth-last-of-type", "nth-of-type", "only-child", "only-of-type", "optional", "out-of-range", "past", "placeholder-shown", "read-only", "read-write", "required", "right", "root", "scope", "target", "target-within", "user-invalid", "valid", "visited", "where"],
    _ = ["after", "backdrop", "before", "cue", "cue-region", "first-letter", "first-line", "grammar-error", "marker", "part", "placeholder", "selection", "slotted", "spelling-error"],
    E = ["align-content", "align-items", "align-self", "all", "animation", "animation-delay", "animation-direction", "animation-duration", "animation-fill-mode", "animation-iteration-count", "animation-name", "animation-play-state", "animation-timing-function", "backface-visibility", "background", "background-attachment", "background-blend-mode", "background-clip", "background-color", "background-image", "background-origin", "background-position", "background-repeat", "background-size", "block-size", "border", "border-block", "border-block-color", "border-block-end", "border-block-end-color", "border-block-end-style", "border-block-end-width", "border-block-start", "border-block-start-color", "border-block-start-style", "border-block-start-width", "border-block-style", "border-block-width", "border-bottom", "border-bottom-color", "border-bottom-left-radius", "border-bottom-right-radius", "border-bottom-style", "border-bottom-width", "border-collapse", "border-color", "border-image", "border-image-outset", "border-image-repeat", "border-image-slice", "border-image-source", "border-image-width", "border-inline", "border-inline-color", "border-inline-end", "border-inline-end-color", "border-inline-end-style", "border-inline-end-width", "border-inline-start", "border-inline-start-color", "border-inline-start-style", "border-inline-start-width", "border-inline-style", "border-inline-width", "border-left", "border-left-color", "border-left-style", "border-left-width", "border-radius", "border-right", "border-right-color", "border-right-style", "border-right-width", "border-spacing", "border-style", "border-top", "border-top-color", "border-top-left-radius", "border-top-right-radius", "border-top-style", "border-top-width", "border-width", "bottom", "box-decoration-break", "box-shadow", "box-sizing", "break-after", "break-before", "break-inside", "caption-side", "caret-color", "clear", "clip", "clip-path", "clip-rule", "color", "column-count", "column-fill", "column-gap", "column-rule", "column-rule-color", "column-rule-style", "column-rule-width", "column-span", "column-width", "columns", "contain", "content", "content-visibility", "counter-increment", "counter-reset", "cue", "cue-after", "cue-before", "cursor", "direction", "display", "empty-cells", "filter", "flex", "flex-basis", "flex-direction", "flex-flow", "flex-grow", "flex-shrink", "flex-wrap", "float", "flow", "font", "font-display", "font-family", "font-feature-settings", "font-kerning", "font-language-override", "font-size", "font-size-adjust", "font-smoothing", "font-stretch", "font-style", "font-synthesis", "font-variant", "font-variant-caps", "font-variant-east-asian", "font-variant-ligatures", "font-variant-numeric", "font-variant-position", "font-variation-settings", "font-weight", "gap", "glyph-orientation-vertical", "grid", "grid-area", "grid-auto-columns", "grid-auto-flow", "grid-auto-rows", "grid-column", "grid-column-end", "grid-column-start", "grid-gap", "grid-row", "grid-row-end", "grid-row-start", "grid-template", "grid-template-areas", "grid-template-columns", "grid-template-rows", "hanging-punctuation", "height", "hyphens", "icon", "image-orientation", "image-rendering", "image-resolution", "ime-mode", "inline-size", "isolation", "justify-content", "left", "letter-spacing", "line-break", "line-height", "list-style", "list-style-image", "list-style-position", "list-style-type", "margin", "margin-block", "margin-block-end", "margin-block-start", "margin-bottom", "margin-inline", "margin-inline-end", "margin-inline-start", "margin-left", "margin-right", "margin-top", "marks", "mask", "mask-border", "mask-border-mode", "mask-border-outset", "mask-border-repeat", "mask-border-slice", "mask-border-source", "mask-border-width", "mask-clip", "mask-composite", "mask-image", "mask-mode", "mask-origin", "mask-position", "mask-repeat", "mask-size", "mask-type", "max-block-size", "max-height", "max-inline-size", "max-width", "min-block-size", "min-height", "min-inline-size", "min-width", "mix-blend-mode", "nav-down", "nav-index", "nav-left", "nav-right", "nav-up", "none", "normal", "object-fit", "object-position", "opacity", "order", "orphans", "outline", "outline-color", "outline-offset", "outline-style", "outline-width", "overflow", "overflow-wrap", "overflow-x", "overflow-y", "padding", "padding-block", "padding-block-end", "padding-block-start", "padding-bottom", "padding-inline", "padding-inline-end", "padding-inline-start", "padding-left", "padding-right", "padding-top", "page-break-after", "page-break-before", "page-break-inside", "pause", "pause-after", "pause-before", "perspective", "perspective-origin", "pointer-events", "position", "quotes", "resize", "rest", "rest-after", "rest-before", "right", "row-gap", "scroll-margin", "scroll-margin-block", "scroll-margin-block-end", "scroll-margin-block-start", "scroll-margin-bottom", "scroll-margin-inline", "scroll-margin-inline-end", "scroll-margin-inline-start", "scroll-margin-left", "scroll-margin-right", "scroll-margin-top", "scroll-padding", "scroll-padding-block", "scroll-padding-block-end", "scroll-padding-block-start", "scroll-padding-bottom", "scroll-padding-inline", "scroll-padding-inline-end", "scroll-padding-inline-start", "scroll-padding-left", "scroll-padding-right", "scroll-padding-top", "scroll-snap-align", "scroll-snap-stop", "scroll-snap-type", "scrollbar-color", "scrollbar-gutter", "scrollbar-width", "shape-image-threshold", "shape-margin", "shape-outside", "speak", "speak-as", "src", "tab-size", "table-layout", "text-align", "text-align-all", "text-align-last", "text-combine-upright", "text-decoration", "text-decoration-color", "text-decoration-line", "text-decoration-style", "text-emphasis", "text-emphasis-color", "text-emphasis-position", "text-emphasis-style", "text-indent", "text-justify", "text-orientation", "text-overflow", "text-rendering", "text-shadow", "text-transform", "text-underline-position", "top", "transform", "transform-box", "transform-origin", "transform-style", "transition", "transition-delay", "transition-duration", "transition-property", "transition-timing-function", "unicode-bidi", "vertical-align", "visibility", "voice-balance", "voice-duration", "voice-family", "voice-pitch", "voice-range", "voice-rate", "voice-stress", "voice-volume", "white-space", "widows", "width", "will-change", "word-break", "word-spacing", "word-wrap", "writing-mode", "z-index"].reverse(),
    oe = v.concat(_);
    var o = "\\.([0-9](_*[0-9])*)",
    d = "[0-9a-fA-F](_*[0-9a-fA-F])*",
    w = {
        className: "number",
        variants: [{
                begin: `(\\b([0-9](_*[0-9])*)((${o})|\\.)?|(${o}))[eE][+-]?([0-9](_*[0-9])*)[fFdD]?\\b`
            }, {
                begin: `\\b([0-9](_*[0-9])*)((${o})[fFdD]?\\b|\\.([fFdD]\\b)?)`
            }, {
                begin: `(${o})[fFdD]?\\b`
            }, {
                begin: "\\b([0-9](_*[0-9])*)[fFdD]\\b"
            }, {
                begin: `\\b0[xX]((${d})\\.?|(${d})?\\.(${d}))[pP][+-]?([0-9](_*[0-9])*)[fFdD]?\\b`
            }, {
                begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b"
            }, {
                begin: `\\b0[xX](${d})[lL]?\\b`
            }, {
                begin: "\\b0(_*[0-7])*[lL]?\\b"
            }, {
                begin: "\\b0[bB][01](_*[01])*[lL]?\\b"
            }
        ],
        relevance: 0
    };
    const C = "[A-Za-z$_][0-9A-Za-z$_]*",
    le = ["as", "in", "of", "if", "for", "while", "finally", "var", "new", "function", "do", "return", "void", "else", "break", "catch", "instanceof", "with", "throw", "case", "default", "try", "switch", "continue", "typeof", "delete", "let", "yield", "const", "class", "debugger", "async", "await", "static", "import", "from", "export", "extends"],
    ce = ["true", "false", "null", "undefined", "NaN", "Infinity"],
    ue = ["Object", "Function", "Boolean", "Symbol", "Math", "Date", "Number", "BigInt", "String", "RegExp", "Array", "Float32Array", "Float64Array", "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Int32Array", "Uint16Array", "Uint32Array", "BigInt64Array", "BigUint64Array", "Set", "Map", "WeakSet", "WeakMap", "ArrayBuffer", "SharedArrayBuffer", "Atomics", "DataView", "JSON", "Promise", "Generator", "GeneratorFunction", "AsyncFunction", "Reflect", "Proxy", "Intl", "WebAssembly"],
    de = ["Error", "EvalError", "InternalError", "RangeError", "ReferenceError", "SyntaxError", "TypeError", "URIError"],
    pe = ["setInterval", "setTimeout", "clearInterval", "clearTimeout", "require", "exports", "eval", "isFinite", "isNaN", "parseFloat", "parseInt", "decodeURI", "decodeURIComponent", "encodeURI", "encodeURIComponent", "escape", "unescape"],
    ge = ["arguments", "this", "super", "console", "window", "document", "localStorage", "module", "global"],
    fe = [].concat(pe, ue, de);
    function he(e) {
        const t = e.regex,
        n = C,
        r = /<[A-Za-z0-9\\._:-]+/,
        i = /\/[A-Za-z0-9\\._:-]+>|\/>/,
        a = (e, t) => {
            var n,
            r,
            i = e[0].length + e.index,
            a = e.input[i];
            "<" !== a && "," !== a && (">" === a && ([a, n] = [e, i], r = "</" + a[0].slice(1), -1 === a.input.indexOf(r, n)) && t.ignoreMatch(), !(a = e.input.substring(i).match(/^\s+extends\s+/)) || 0 !== a.index) || t.ignoreMatch()
        },
        s = {
            $pattern: C,
            keyword: le,
            literal: ce,
            built_in: fe,
            "variable.language": ge
        },
        o = "\\.([0-9](_?[0-9])*)",
        l = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*",
        c = {
            className: "number",
            variants: [{
                    begin: `(\\b(${l})((${o})|\\.)?|(${o}))[eE][+-]?([0-9](_?[0-9])*)\\b`
                }, {
                    begin: `\\b(${l})\\b((${o})\\b|\\.)?|(${o})\\b`
                }, {
                    begin: "\\b(0|[1-9](_?[0-9])*)n\\b"
                }, {
                    begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b"
                }, {
                    begin: "\\b0[bB][0-1](_?[0-1])*n?\\b"
                }, {
                    begin: "\\b0[oO][0-7](_?[0-7])*n?\\b"
                }, {
                    begin: "\\b0[0-7]+n?\\b"
                }
            ],
            relevance: 0
        },
        u = {
            className: "subst",
            begin: "\\$\\{",
            end: "\\}",
            keywords: s,
            contains: []
        },
        d = {
            begin: "html`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, u],
                subLanguage: "xml"
            }
        },
        p = {
            begin: "css`",
            end: "",
            starts: {
                end: "`",
                returnEnd: !1,
                contains: [e.BACKSLASH_ESCAPE, u],
                subLanguage: "css"
            }
        },
        g = {
            className: "string",
            begin: "`",
            end: "`",
            contains: [e.BACKSLASH_ESCAPE, u]
        },
        f = {
            className: "comment",
            variants: [e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
                    relevance: 0,
                    contains: [{
                            begin: "(?=@[A-Za-z]+)",
                            relevance: 0,
                            contains: [{
                                    className: "doctag",
                                    begin: "@[A-Za-z]+"
                                }, {
                                    className: "type",
                                    begin: "\\{",
                                    end: "\\}",
                                    excludeEnd: !0,
                                    excludeBegin: !0,
                                    relevance: 0
                                }, {
                                    className: "variable",
                                    begin: n + "(?=\\s*(-)|$)",
                                    endsParent: !0,
                                    relevance: 0
                                }, {
                                    begin: /(?=[^\n])\s/,
                                    relevance: 0
                                }
                            ]
                        }
                    ]
                }), e.C_BLOCK_COMMENT_MODE, e.C_LINE_COMMENT_MODE]
        },
        h = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, d, p, g, c];
        u.contains = h.concat({
            begin: /\{/,
            end: /\}/,
            keywords: s,
            contains: ["self"].concat(h)
        });
        var m = [].concat(f, u.contains),
        m = m.concat([{
                        begin: /\(/,
                        end: /\)/,
                        keywords: s,
                        contains: ["self"].concat(m)
                    }
                ]),
        b = {
            className: "params",
            begin: /\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: s,
            contains: m
        },
        y = {
            variants: [{
                    match: [/class/, /\s+/, n, /\s+/, /extends/, /\s+/, t.concat(n, "(", t.concat(/\./, n), ")*")],
                    scope: {
                        1: "keyword",
                        3: "title.class",
                        5: "keyword",
                        7: "title.class.inherited"
                    }
                }, {
                    match: [/class/, /\s+/, n],
                    scope: {
                        1: "keyword",
                        3: "title.class"
                    }
                }
            ]
        },
        v = {
            relevance: 0,
            match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
            className: "title.class",
            keywords: {
                _: [...ue, ...de]
            }
        },
        _ = {
            variants: [{
                    match: [/function/, /\s+/, n, /(?=\s*\()/]
                }, {
                    match: [/function/, /\s*(?=\()/]
                }
            ],
            className: {
                1: "keyword",
                3: "title.function"
            },
            label: "func.def",
            contains: [b],
            illegal: /%/
        },
        E = {
            match: t.concat(/\b/, (E = [...pe, "super"], t.concat("(?!", E.join("|"), ")")), n, t.lookahead(/\(/)),
            className: "title.function",
            relevance: 0
        },
        w = {
            begin: t.concat(/\./, t.lookahead(t.concat(n, /(?![0-9A-Za-z$_(])/))),
            end: n,
            excludeBegin: !0,
            keywords: "prototype",
            className: "property",
            relevance: 0
        },
        x = {
            match: [/get|set/, /\s+/, n, /(?=\()/],
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [{
                    begin: /\(\)/
                }, b]
        },
        N = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>",
        k = {
            match: [/const|var|let/, /\s+/, n, /\s*/, /=\s*/, /(async\s*)?/, t.lookahead(N)],
            keywords: "async",
            className: {
                1: "keyword",
                3: "title.function"
            },
            contains: [b]
        };
        return {
            name: "Javascript",
            aliases: ["js", "jsx", "mjs", "cjs"],
            keywords: s,
            exports: {
                PARAMS_CONTAINS: m,
                CLASS_REFERENCE: v
            },
            illegal: /#(?![$_A-z])/,
            contains: [e.SHEBANG({
                    label: "shebang",
                    binary: "node",
                    relevance: 5
                }), {
                    label: "use_strict",
                    className: "meta",
                    relevance: 10,
                    begin: /^\s*['"]use (strict|asm)['"]/
                }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, d, p, g, f, c, v, {
                    className: "attr",
                    begin: n + t.lookahead(":"),
                    relevance: 0
                }, k, {
                    begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
                    keywords: "return throw case",
                    relevance: 0,
                    contains: [f, e.REGEXP_MODE, {
                            className: "function",
                            begin: N,
                            returnBegin: !0,
                            end: "\\s*=>",
                            contains: [{
                                    className: "params",
                                    variants: [{
                                            begin: e.UNDERSCORE_IDENT_RE,
                                            relevance: 0
                                        }, {
                                            className: null,
                                            begin: /\(\s*\)/,
                                            skip: !0
                                        }, {
                                            begin: /\(/,
                                            end: /\)/,
                                            excludeBegin: !0,
                                            excludeEnd: !0,
                                            keywords: s,
                                            contains: m
                                        }
                                    ]
                                }
                            ]
                        }, {
                            begin: /,/,
                            relevance: 0
                        }, {
                            match: /\s+/,
                            relevance: 0
                        }, {
                            variants: [{
                                    begin: "<>",
                                    end: "</>"
                                }, {
                                    match: /<[A-Za-z0-9\\._:-]+\s*\/>/
                                }, {
                                    begin: r,
                                    "on:begin": a,
                                    end: i
                                }
                            ],
                            subLanguage: "xml",
                            contains: [{
                                    begin: r,
                                    end: i,
                                    skip: !0,
                                    contains: ["self"]
                                }
                            ]
                        }
                    ]
                }, _, {
                    beginKeywords: "while if switch catch for"
                }, {
                    begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
                    returnBegin: !0,
                    label: "func.def",
                    contains: [b, e.inherit(e.TITLE_MODE, {
                            begin: n,
                            className: "title.function"
                        })]
                }, {
                    match: /\.\.\./,
                    relevance: 0
                }, w, {
                    match: "\\$" + n,
                    relevance: 0
                }, {
                    match: [/\bconstructor(?=\s*\()/],
                    className: {
                        1: "title.function"
                    },
                    contains: [b]
                }, E, {
                    relevance: 0,
                    match: /\b[A-Z][A-Z_0-9]+\b/,
                    className: "variable.constant"
                }, y, x, {
                    match: /\$[(.]/
                }
            ]
        }
    }
    const O = e => R(/\b/, e, /\w$/.test(e) ? /\b/ : /\B/),
    me = ["Protocol", "Type"].map(O),
    be = ["init", "self"].map(O),
    ye = ["Any", "Self"],
    j = ["actor", "any", "associatedtype", "async", "await", /as\?/, /as!/, "as", "break", "case", "catch", "class", "continue", "convenience", "default", "defer", "deinit", "didSet", "distributed", "do", "dynamic", "else", "enum", "extension", "fallthrough", /fileprivate\(set\)/, "fileprivate", "final", "for", "func", "get", "guard", "if", "import", "indirect", "infix", /init\?/, /init!/, "inout", /internal\(set\)/, "internal", "in", "is", "isolated", "nonisolated", "lazy", "let", "mutating", "nonmutating", /open\(set\)/, "open", "operator", "optional", "override", "postfix", "precedencegroup", "prefix", /private\(set\)/, "private", "protocol", /public\(set\)/, "public", "repeat", "required", "rethrows", "return", "set", "some", "static", "struct", "subscript", "super", "switch", "throws", "throw", /try\?/, /try!/, "try", "typealias", /unowned\(safe\)/, /unowned\(unsafe\)/, "unowned", "var", "weak", "where", "while", "willSet"],
    ve = ["false", "nil", "true"],
    _e = ["assignment", "associativity", "higherThan", "left", "lowerThan", "none", "right"],
    Ee = ["#colorLiteral", "#column", "#dsohandle", "#else", "#elseif", "#endif", "#error", "#file", "#fileID", "#fileLiteral", "#filePath", "#function", "#if", "#imageLiteral", "#keyPath", "#line", "#selector", "#sourceLocation", "#warn_unqualified_access", "#warning"],
    we = ["abs", "all", "any", "assert", "assertionFailure", "debugPrint", "dump", "fatalError", "getVaList", "isKnownUniquelyReferenced", "max", "min", "numericCast", "pointwiseMax", "pointwiseMin", "precondition", "preconditionFailure", "print", "readLine", "repeatElement", "sequence", "stride", "swap", "swift_unboxFromSwiftValueWithType", "transcode", "type", "unsafeBitCast", "unsafeDowncast", "withExtendedLifetime", "withUnsafeMutablePointer", "withUnsafePointer", "withVaList", "withoutActuallyEscaping", "zip"],
    xe = I(/[/=\-+!*%<>&|^~?]/, /[\u00A1-\u00A7]/, /[\u00A9\u00AB]/, /[\u00AC\u00AE]/, /[\u00B0\u00B1]/, /[\u00B6\u00BB\u00BF\u00D7\u00F7]/, /[\u2016-\u2017]/, /[\u2020-\u2027]/, /[\u2030-\u203E]/, /[\u2041-\u2053]/, /[\u2055-\u205E]/, /[\u2190-\u23FF]/, /[\u2500-\u2775]/, /[\u2794-\u2BFF]/, /[\u2E00-\u2E7F]/, /[\u3001-\u3003]/, /[\u3008-\u3020]/, /[\u3030]/),
    Ne = I(xe, /[\u0300-\u036F]/, /[\u1DC0-\u1DFF]/, /[\u20D0-\u20FF]/, /[\uFE00-\uFE0F]/, /[\uFE20-\uFE2F]/),
    $ = R(xe, Ne, "*"),
    ke = I(/[a-zA-Z_]/, /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/, /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/, /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/, /[\u1E00-\u1FFF]/, /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/, /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/, /[\u2C00-\u2DFF\u2E80-\u2FFF]/, /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/, /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/, /[\uFE47-\uFEFE\uFF00-\uFFFD]/),
    F = I(ke, /\d/, /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/),
    P = R(ke, F, "*"),
    q = R(/[A-Z]/, F, "*"),
    Ce = ["autoclosure", R(/convention\(/, I("swift", "block", "c"), /\)/), "discardableResult", "dynamicCallable", "dynamicMemberLookup", "escaping", "frozen", "GKInspectable", "IBAction", "IBDesignable", "IBInspectable", "IBOutlet", "IBSegueAction", "inlinable", "main", "nonobjc", "NSApplicationMain", "NSCopying", "NSManaged", R(/objc\(/, P, /\)/), "objc", "objcMembers", "propertyWrapper", "requires_stored_property_inits", "resultBuilder", "testable", "UIApplicationMain", "unknown", "usableFromInline"],
    Se = ["iOS", "iOSApplicationExtension", "macOS", "macOSApplicationExtension", "macCatalyst", "macCatalystApplicationExtension", "watchOS", "watchOSApplicationExtension", "tvOS", "tvOSApplicationExtension", "swift"];
    var Te = Object.freeze({
        __proto__: null,
        grmr_bash: e => {
            var t = e.regex,
            n = {},
            r = {
                begin: /\$\{/,
                end: /\}/,
                contains: ["self", {
                        begin: /:-/,
                        contains: [n]
                    }
                ]
            },
            t = (Object.assign(n, {
                    className: "variable",
                    variants: [{
                            begin: t.concat(/\$[\w\d#@][\w\d_]*/, "(?![\\w\\d])(?![$])")
                        }, r]
                }), {
                className: "subst",
                begin: /\$\(/,
                end: /\)/,
                contains: [e.BACKSLASH_ESCAPE]
            }),
            r = {
                begin: /<<-?\s*(?=\w+)/,
                starts: {
                    contains: [e.END_SAME_AS_BEGIN({
                            begin: /(\w+)/,
                            end: /(\w+)/,
                            className: "string"
                        })]
                }
            },
            i = {
                className: "string",
                begin: /"/,
                end: /"/,
                contains: [e.BACKSLASH_ESCAPE, n, t]
            },
            t = (t.contains.push(i), {
                begin: /\$\(\(/,
                end: /\)\)/,
                contains: [{
                        begin: /\d+#[0-9a-f]+/,
                        className: "number"
                    }, e.NUMBER_MODE, n]
            }),
            a = e.SHEBANG({
                binary: "(fish|bash|zsh|sh|csh|ksh|tcsh|dash|scsh)",
                relevance: 10
            }),
            s = {
                className: "function",
                begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
                returnBegin: !0,
                contains: [e.inherit(e.TITLE_MODE, {
                        begin: /\w[\w\d_]*/
                    })],
                relevance: 0
            };
            return {
                name: "Bash",
                aliases: ["sh"],
                keywords: {
                    $pattern: /\b[a-z][a-z0-9._-]+\b/,
                    keyword: ["if", "then", "else", "elif", "fi", "for", "while", "in", "do", "done", "case", "esac", "function"],
                    literal: ["true", "false"],
                    built_in: ["break", "cd", "continue", "eval", "exec", "exit", "export", "getopts", "hash", "pwd", "readonly", "return", "shift", "test", "times", "trap", "umask", "unset", "alias", "bind", "builtin", "caller", "command", "declare", "echo", "enable", "help", "let", "local", "logout", "mapfile", "printf", "read", "readarray", "source", "type", "typeset", "ulimit", "unalias", "set", "shopt", "autoload", "bg", "bindkey", "bye", "cap", "chdir", "clone", "comparguments", "compcall", "compctl", "compdescribe", "compfiles", "compgroups", "compquote", "comptags", "comptry", "compvalues", "dirs", "disable", "disown", "echotc", "echoti", "emulate", "fc", "fg", "float", "functions", "getcap", "getln", "history", "integer", "jobs", "kill", "limit", "log", "noglob", "popd", "print", "pushd", "pushln", "rehash", "sched", "setcap", "setopt", "stat", "suspend", "ttyctl", "unfunction", "unhash", "unlimit", "unsetopt", "vared", "wait", "whence", "where", "which", "zcompile", "zformat", "zftp", "zle", "zmodload", "zparseopts", "zprof", "zpty", "zregexparse", "zsocket", "zstyle", "ztcp", "chcon", "chgrp", "chown", "chmod", "cp", "dd", "df", "dir", "dircolors", "ln", "ls", "mkdir", "mkfifo", "mknod", "mktemp", "mv", "realpath", "rm", "rmdir", "shred", "sync", "touch", "truncate", "vdir", "b2sum", "base32", "base64", "cat", "cksum", "comm", "csplit", "cut", "expand", "fmt", "fold", "head", "join", "md5sum", "nl", "numfmt", "od", "paste", "ptx", "pr", "sha1sum", "sha224sum", "sha256sum", "sha384sum", "sha512sum", "shuf", "sort", "split", "sum", "tac", "tail", "tr", "tsort", "unexpand", "uniq", "wc", "arch", "basename", "chroot", "date", "dirname", "du", "echo", "env", "expr", "factor", "groups", "hostid", "id", "link", "logname", "nice", "nohup", "nproc", "pathchk", "pinky", "printenv", "printf", "pwd", "readlink", "runcon", "seq", "sleep", "stat", "stdbuf", "stty", "tee", "test", "timeout", "tty", "uname", "unlink", "uptime", "users", "who", "whoami", "yes"]
                },
                contains: [a, e.SHEBANG(), s, t, e.HASH_COMMENT_MODE, r, {
                        match: /(\/[a-z._-]+)+/
                    }, i, {
                        className: "",
                        begin: /\\"/
                    }, {
                        className: "string",
                        begin: /'/,
                        end: /'/
                    }, n]
            }
        },
        grmr_c: e => {
            var t = e.regex,
            n = e.COMMENT("//", "$", {
                contains: [{
                        begin: /\\\n/
                    }
                ]
            }),
            r = "[a-zA-Z_]\\w*::",
            i = "(decltype\\(auto\\)|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")",
            a = {
                className: "type",
                variants: [{
                        begin: "\\b[a-z\\d_]*_t\\b"
                    }, {
                        match: /\batomic_[a-z]{3,6}\b/
                    }
                ]
            },
            s = {
                className: "string",
                variants: [{
                        begin: '(u8?|U|L)?"',
                        end: '"',
                        illegal: "\\n",
                        contains: [e.BACKSLASH_ESCAPE]
                    }, {
                        begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
                        end: "'",
                        illegal: "."
                    }, e.END_SAME_AS_BEGIN({
                        begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                        end: /\)([^()\\ ]{0,16})"/
                    })]
            },
            o = {
                className: "number",
                variants: [{
                        begin: "\\b(0b[01']+)"
                    }, {
                        begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)"
                    }, {
                        begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                    }
                ],
                relevance: 0
            },
            l = {
                className: "meta",
                begin: /#\s*[a-z]+\b/,
                end: /$/,
                keywords: {
                    keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
                },
                contains: [{
                        begin: /\\\n/,
                        relevance: 0
                    }, e.inherit(s, {
                        className: "string"
                    }), {
                        className: "string",
                        begin: /<.*?>/
                    }, n, e.C_BLOCK_COMMENT_MODE]
            },
            c = {
                className: "title",
                begin: t.optional(r) + e.IDENT_RE,
                relevance: 0
            },
            t = t.optional(r) + e.IDENT_RE + "\\s*\\(",
            r = {
                keyword: ["asm", "auto", "break", "case", "continue", "default", "do", "else", "enum", "extern", "for", "fortran", "goto", "if", "inline", "register", "restrict", "return", "sizeof", "struct", "switch", "typedef", "union", "volatile", "while", "_Alignas", "_Alignof", "_Atomic", "_Generic", "_Noreturn", "_Static_assert", "_Thread_local", "alignas", "alignof", "noreturn", "static_assert", "thread_local", "_Pragma"],
                type: ["float", "double", "signed", "unsigned", "int", "short", "long", "char", "void", "_Bool", "_Complex", "_Imaginary", "_Decimal32", "_Decimal64", "_Decimal128", "const", "static", "complex", "bool", "imaginary"],
                literal: "true false NULL",
                built_in: "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr"
            },
            u = [l, a, n, e.C_BLOCK_COMMENT_MODE, o, s],
            d = {
                variants: [{
                        begin: /=/,
                        end: /;/
                    }, {
                        begin: /\(/,
                        end: /\)/
                    }, {
                        beginKeywords: "new throw return else",
                        end: /;/
                    }
                ],
                keywords: r,
                contains: u.concat([{
                            begin: /\(/,
                            end: /\)/,
                            keywords: r,
                            contains: u.concat(["self"]),
                            relevance: 0
                        }
                    ]),
                relevance: 0
            },
            i = {
                begin: "(" + i + "[\\*&\\s]+)+" + t,
                returnBegin: !0,
                end: /[{;=]/,
                excludeEnd: !0,
                keywords: r,
                illegal: /[^\w\s\*&:<>.]/,
                contains: [{
                        begin: "decltype\\(auto\\)",
                        keywords: r,
                        relevance: 0
                    }, {
                        begin: t,
                        returnBegin: !0,
                        contains: [e.inherit(c, {
                                className: "title.function"
                            })],
                        relevance: 0
                    }, {
                        relevance: 0,
                        match: /,/
                    }, {
                        className: "params",
                        begin: /\(/,
                        end: /\)/,
                        keywords: r,
                        relevance: 0,
                        contains: [n, e.C_BLOCK_COMMENT_MODE, s, o, a, {
                                begin: /\(/,
                                end: /\)/,
                                keywords: r,
                                relevance: 0,
                                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, s, o, a]
                            }
                        ]
                    }, a, n, e.C_BLOCK_COMMENT_MODE, l]
            };
            return {
                name: "C",
                aliases: ["h"],
                keywords: r,
                disableAutodetect: !0,
                illegal: "</",
                contains: [].concat(d, i, u, [l, {
                            begin: e.IDENT_RE + "::",
                            keywords: r
                        }, {
                            className: "class",
                            beginKeywords: "enum class struct union",
                            end: /[{;:<>=]/,
                            contains: [{
                                    beginKeywords: "final class struct"
                                }, e.TITLE_MODE]
                        }
                    ]),
                exports: {
                    preprocessor: l,
                    strings: s,
                    keywords: r
                }
            }
        },
        grmr_cpp: e => {
            var t = e.regex,
            n = e.COMMENT("//", "$", {
                contains: [{
                        begin: /\\\n/
                    }
                ]
            }),
            r = "[a-zA-Z_]\\w*::",
            i = "(?!struct)(decltype\\(auto\\)|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")",
            a = {
                className: "type",
                begin: "\\b[a-z\\d_]*_t\\b"
            },
            s = {
                className: "string",
                variants: [{
                        begin: '(u8?|U|L)?"',
                        end: '"',
                        illegal: "\\n",
                        contains: [e.BACKSLASH_ESCAPE]
                    }, {
                        begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
                        end: "'",
                        illegal: "."
                    }, e.END_SAME_AS_BEGIN({
                        begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
                        end: /\)([^()\\ ]{0,16})"/
                    })]
            },
            o = {
                className: "number",
                variants: [{
                        begin: "\\b(0b[01']+)"
                    }, {
                        begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)"
                    }, {
                        begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                    }
                ],
                relevance: 0
            },
            l = {
                className: "meta",
                begin: /#\s*[a-z]+\b/,
                end: /$/,
                keywords: {
                    keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include"
                },
                contains: [{
                        begin: /\\\n/,
                        relevance: 0
                    }, e.inherit(s, {
                        className: "string"
                    }), {
                        className: "string",
                        begin: /<.*?>/
                    }, n, e.C_BLOCK_COMMENT_MODE]
            },
            c = {
                className: "title",
                begin: t.optional(r) + e.IDENT_RE,
                relevance: 0
            },
            r = t.optional(r) + e.IDENT_RE + "\\s*\\(",
            u = {
                type: ["bool", "char", "char16_t", "char32_t", "char8_t", "double", "float", "int", "long", "short", "void", "wchar_t", "unsigned", "signed", "const", "static"],
                keyword: ["alignas", "alignof", "and", "and_eq", "asm", "atomic_cancel", "atomic_commit", "atomic_noexcept", "auto", "bitand", "bitor", "break", "case", "catch", "class", "co_await", "co_return", "co_yield", "compl", "concept", "const_cast|10", "consteval", "constexpr", "constinit", "continue", "decltype", "default", "delete", "do", "dynamic_cast|10", "else", "enum", "explicit", "export", "extern", "false", "final", "for", "friend", "goto", "if", "import", "inline", "module", "mutable", "namespace", "new", "noexcept", "not", "not_eq", "nullptr", "operator", "or", "or_eq", "override", "private", "protected", "public", "reflexpr", "register", "reinterpret_cast|10", "requires", "return", "sizeof", "static_assert", "static_cast|10", "struct", "switch", "synchronized", "template", "this", "thread_local", "throw", "transaction_safe", "transaction_safe_dynamic", "true", "try", "typedef", "typeid", "typename", "union", "using", "virtual", "volatile", "while", "xor", "xor_eq"],
                literal: ["NULL", "false", "nullopt", "nullptr", "true"],
                built_in: ["_Pragma"],
                _type_hints: ["any", "auto_ptr", "barrier", "binary_semaphore", "bitset", "complex", "condition_variable", "condition_variable_any", "counting_semaphore", "deque", "false_type", "future", "imaginary", "initializer_list", "istringstream", "jthread", "latch", "lock_guard", "multimap", "multiset", "mutex", "optional", "ostringstream", "packaged_task", "pair", "promise", "priority_queue", "queue", "recursive_mutex", "recursive_timed_mutex", "scoped_lock", "set", "shared_future", "shared_lock", "shared_mutex", "shared_timed_mutex", "shared_ptr", "stack", "string_view", "stringstream", "timed_mutex", "thread", "true_type", "tuple", "unique_lock", "unique_ptr", "unordered_map", "unordered_multimap", "unordered_multiset", "unordered_set", "variant", "vector", "weak_ptr", "wstring", "wstring_view"]
            },
            t = {
                className: "function.dispatch",
                relevance: 0,
                keywords: {
                    _hint: ["abort", "abs", "acos", "apply", "as_const", "asin", "atan", "atan2", "calloc", "ceil", "cerr", "cin", "clog", "cos", "cosh", "cout", "declval", "endl", "exchange", "exit", "exp", "fabs", "floor", "fmod", "forward", "fprintf", "fputs", "free", "frexp", "fscanf", "future", "invoke", "isalnum", "isalpha", "iscntrl", "isdigit", "isgraph", "islower", "isprint", "ispunct", "isspace", "isupper", "isxdigit", "labs", "launder", "ldexp", "log", "log10", "make_pair", "make_shared", "make_shared_for_overwrite", "make_tuple", "make_unique", "malloc", "memchr", "memcmp", "memcpy", "memset", "modf", "move", "pow", "printf", "putchar", "puts", "realloc", "scanf", "sin", "sinh", "snprintf", "sprintf", "sqrt", "sscanf", "std", "stderr", "stdin", "stdout", "strcat", "strchr", "strcmp", "strcpy", "strcspn", "strlen", "strncat", "strncmp", "strncpy", "strpbrk", "strrchr", "strspn", "strstr", "swap", "tan", "tanh", "terminate", "to_underlying", "tolower", "toupper", "vfprintf", "visit", "vprintf", "vsprintf"]
                },
                begin: t.concat(/\b/, /(?!decltype)/, /(?!if)/, /(?!for)/, /(?!switch)/, /(?!while)/, e.IDENT_RE, t.lookahead(/(<[^<>]+>|)\s*\(/))
            },
            d = [t, l, a, n, e.C_BLOCK_COMMENT_MODE, o, s],
            p = {
                variants: [{
                        begin: /=/,
                        end: /;/
                    }, {
                        begin: /\(/,
                        end: /\)/
                    }, {
                        beginKeywords: "new throw return else",
                        end: /;/
                    }
                ],
                keywords: u,
                contains: d.concat([{
                            begin: /\(/,
                            end: /\)/,
                            keywords: u,
                            contains: d.concat(["self"]),
                            relevance: 0
                        }
                    ]),
                relevance: 0
            },
            i = {
                className: "function",
                begin: "(" + i + "[\\*&\\s]+)+" + r,
                returnBegin: !0,
                end: /[{;=]/,
                excludeEnd: !0,
                keywords: u,
                illegal: /[^\w\s\*&:<>.]/,
                contains: [{
                        begin: "decltype\\(auto\\)",
                        keywords: u,
                        relevance: 0
                    }, {
                        begin: r,
                        returnBegin: !0,
                        contains: [c],
                        relevance: 0
                    }, {
                        begin: /::/,
                        relevance: 0
                    }, {
                        begin: /:/,
                        endsWithParent: !0,
                        contains: [s, o]
                    }, {
                        relevance: 0,
                        match: /,/
                    }, {
                        className: "params",
                        begin: /\(/,
                        end: /\)/,
                        keywords: u,
                        relevance: 0,
                        contains: [n, e.C_BLOCK_COMMENT_MODE, s, o, a, {
                                begin: /\(/,
                                end: /\)/,
                                keywords: u,
                                relevance: 0,
                                contains: ["self", n, e.C_BLOCK_COMMENT_MODE, s, o, a]
                            }
                        ]
                    }, a, n, e.C_BLOCK_COMMENT_MODE, l]
            };
            return {
                name: "C++",
                aliases: ["cc", "c++", "h++", "hpp", "hh", "hxx", "cxx"],
                keywords: u,
                illegal: "</",
                classNameAliases: {
                    "function.dispatch": "built_in"
                },
                contains: [].concat(p, i, t, d, [l, {
                            begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function)\\s*<(?!<)",
                            end: ">",
                            keywords: u,
                            contains: ["self", a]
                        }, {
                            begin: e.IDENT_RE + "::",
                            keywords: u
                        }, {
                            match: [/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/, /\s+/, /\w+/],
                            className: {
                                1: "keyword",
                                3: "title.class"
                            }
                        }
                    ])
            }
        },
        grmr_csharp: e => {
            var t = {
                keyword: ["abstract", "as", "base", "break", "case", "catch", "class", "const", "continue", "do", "else", "event", "explicit", "extern", "finally", "fixed", "for", "foreach", "goto", "if", "implicit", "in", "interface", "internal", "is", "lock", "namespace", "new", "operator", "out", "override", "params", "private", "protected", "public", "readonly", "record", "ref", "return", "scoped", "sealed", "sizeof", "stackalloc", "static", "struct", "switch", "this", "throw", "try", "typeof", "unchecked", "unsafe", "using", "virtual", "void", "volatile", "while"].concat(["add", "alias", "and", "ascending", "async", "await", "by", "descending", "equals", "from", "get", "global", "group", "init", "into", "join", "let", "nameof", "not", "notnull", "on", "or", "orderby", "partial", "remove", "select", "set", "unmanaged", "value|0", "var", "when", "where", "with", "yield"]),
                built_in: ["bool", "byte", "char", "decimal", "delegate", "double", "dynamic", "enum", "float", "int", "long", "nint", "nuint", "object", "sbyte", "short", "string", "ulong", "uint", "ushort"],
                literal: ["default", "false", "null", "true"]
            },
            n = e.inherit(e.TITLE_MODE, {
                begin: "[a-zA-Z](\\.?\\w)*"
            }),
            r = {
                className: "number",
                variants: [{
                        begin: "\\b(0b[01']+)"
                    }, {
                        begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)"
                    }, {
                        begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)"
                    }
                ],
                relevance: 0
            },
            i = {
                className: "string",
                begin: '@"',
                end: '"',
                contains: [{
                        begin: '""'
                    }
                ]
            },
            a = e.inherit(i, {
                illegal: /\n/
            }),
            s = {
                className: "subst",
                begin: /\{/,
                end: /\}/,
                keywords: t
            },
            o = e.inherit(s, {
                illegal: /\n/
            }),
            l = {
                className: "string",
                begin: /\$"/,
                end: '"',
                illegal: /\n/,
                contains: [{
                        begin: /\{\{/
                    }, {
                        begin: /\}\}/
                    }, e.BACKSLASH_ESCAPE, o]
            },
            c = {
                className: "string",
                begin: /\$@"/,
                end: '"',
                contains: [{
                        begin: /\{\{/
                    }, {
                        begin: /\}\}/
                    }, {
                        begin: '""'
                    }, s]
            },
            u = e.inherit(c, {
                illegal: /\n/,
                contains: [{
                        begin: /\{\{/
                    }, {
                        begin: /\}\}/
                    }, {
                        begin: '""'
                    }, o]
            }),
            s = (s.contains = [c, l, i, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, r, e.C_BLOCK_COMMENT_MODE], o.contains = [u, l, a, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, r, e.inherit(e.C_BLOCK_COMMENT_MODE, {
                        illegal: /\n/
                    })], {
                variants: [c, l, i, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
            }),
            o = {
                begin: "<",
                end: ">",
                contains: [{
                        beginKeywords: "in out"
                    }, n]
            },
            u = e.IDENT_RE + "(<" + e.IDENT_RE + "(\\s*,\\s*" + e.IDENT_RE + ")*>)?(\\[\\])?",
            a = {
                begin: "@" + e.IDENT_RE,
                relevance: 0
            };
            return {
                name: "C#",
                aliases: ["cs", "c#"],
                keywords: t,
                illegal: /::/,
                contains: [e.COMMENT("///", "$", {
                        returnBegin: !0,
                        contains: [{
                                className: "doctag",
                                variants: [{
                                        begin: "///",
                                        relevance: 0
                                    }, {
                                        begin: "\x3c!--|--\x3e"
                                    }, {
                                        begin: "</?",
                                        end: ">"
                                    }
                                ]
                            }
                        ]
                    }), e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                        className: "meta",
                        begin: "#",
                        end: "$",
                        keywords: {
                            keyword: "if else elif endif define undef warning error line region endregion pragma checksum"
                        }
                    }, s, r, {
                        beginKeywords: "class interface",
                        relevance: 0,
                        end: /[{;=]/,
                        illegal: /[^\s:,]/,
                        contains: [{
                                beginKeywords: "where class"
                            }, n, o, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, {
                        beginKeywords: "namespace",
                        relevance: 0,
                        end: /[{;=]/,
                        illegal: /[^\s:]/,
                        contains: [n, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, {
                        beginKeywords: "record",
                        relevance: 0,
                        end: /[{;=]/,
                        illegal: /[^\s:]/,
                        contains: [n, o, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, {
                        className: "meta",
                        begin: "^\\s*\\[(?=[\\w])",
                        excludeBegin: !0,
                        end: "\\]",
                        excludeEnd: !0,
                        contains: [{
                                className: "string",
                                begin: /"/,
                                end: /"/
                            }
                        ]
                    }, {
                        beginKeywords: "new return throw await else",
                        relevance: 0
                    }, {
                        className: "function",
                        begin: "(" + u + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
                        returnBegin: !0,
                        end: /\s*[{;=]/,
                        excludeEnd: !0,
                        keywords: t,
                        contains: [{
                                beginKeywords: "public private protected static internal protected abstract async extern override unsafe virtual new sealed partial",
                                relevance: 0
                            }, {
                                begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
                                returnBegin: !0,
                                contains: [e.TITLE_MODE, o],
                                relevance: 0
                            }, {
                                match: /\(\)/
                            }, {
                                className: "params",
                                begin: /\(/,
                                end: /\)/,
                                excludeBegin: !0,
                                excludeEnd: !0,
                                keywords: t,
                                relevance: 0,
                                contains: [s, r, e.C_BLOCK_COMMENT_MODE]
                            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, a]
            }
        },
        grmr_css: e => {
            var t = e.regex,
            n = m(e),
            e = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE];
            return {
                name: "CSS",
                case_insensitive: !0,
                illegal: /[=|'\$]/,
                keywords: {
                    keyframePosition: "from to"
                },
                classNameAliases: {
                    keyframePosition: "selector-tag"
                },
                contains: [n.BLOCK_COMMENT, {
                        begin: /-(webkit|moz|ms|o)-(?=[a-z])/
                    }, n.CSS_NUMBER_MODE, {
                        className: "selector-id",
                        begin: /#[A-Za-z0-9_-]+/,
                        relevance: 0
                    }, {
                        className: "selector-class",
                        begin: "\\.[a-zA-Z-][a-zA-Z0-9_-]*",
                        relevance: 0
                    }, n.ATTRIBUTE_SELECTOR_MODE, {
                        className: "selector-pseudo",
                        variants: [{
                                begin: ":(" + v.join("|") + ")"
                            }, {
                                begin: ":(:)?(" + _.join("|") + ")"
                            }
                        ]
                    }, n.CSS_VARIABLE, {
                        className: "attribute",
                        begin: "\\b(" + E.join("|") + ")\\b"
                    }, {
                        begin: /:/,
                        end: /[;}{]/,
                        contains: [n.BLOCK_COMMENT, n.HEXCOLOR, n.IMPORTANT, n.CSS_NUMBER_MODE, ...e, {
                                begin: /(url|data-uri)\(/,
                                end: /\)/,
                                relevance: 0,
                                keywords: {
                                    built_in: "url data-uri"
                                },
                                contains: [...e, {
                                        className: "string",
                                        begin: /[^)]/,
                                        endsWithParent: !0,
                                        excludeEnd: !0
                                    }
                                ]
                            }, n.FUNCTION_DISPATCH]
                    }, {
                        begin: t.lookahead(/@/),
                        end: "[{;]",
                        relevance: 0,
                        illegal: /:/,
                        contains: [{
                                className: "keyword",
                                begin: /@-?\w[\w]*(-\w+)*/
                            }, {
                                begin: /\s/,
                                endsWithParent: !0,
                                excludeEnd: !0,
                                relevance: 0,
                                keywords: {
                                    $pattern: /[a-z-]+/,
                                    keyword: "and or not only",
                                    attribute: y.join(" ")
                                },
                                contains: [{
                                        begin: /[a-z-]+(?=:)/,
                                        className: "attribute"
                                    }, ...e, n.CSS_NUMBER_MODE]
                            }
                        ]
                    }, {
                        className: "selector-tag",
                        begin: "\\b(" + b.join("|") + ")\\b"
                    }
                ]
            }
        },
        grmr_diff: e => {
            e = e.regex;
            return {
                name: "Diff",
                aliases: ["patch"],
                contains: [{
                        className: "meta",
                        relevance: 10,
                        match: e.either(/^@@ +-\d+,\d+ +\+\d+,\d+ +@@/, /^\*\*\* +\d+,\d+ +\*\*\*\*$/, /^--- +\d+,\d+ +----$/)
                    }, {
                        className: "comment",
                        variants: [{
                                begin: e.either(/Index: /, /^index/, /={3,}/, /^-{3}/, /^\*{3} /, /^\+{3}/, /^diff --git/),
                                end: /$/
                            }, {
                                match: /^\*{15}$/
                            }
                        ]
                    }, {
                        className: "addition",
                        begin: /^\+/,
                        end: /$/
                    }, {
                        className: "deletion",
                        begin: /^-/,
                        end: /$/
                    }, {
                        className: "addition",
                        begin: /^!/,
                        end: /$/
                    }
                ]
            }
        },
        grmr_go: e => {
            var t = {
                keyword: ["break", "case", "chan", "const", "continue", "default", "defer", "else", "fallthrough", "for", "func", "go", "goto", "if", "import", "interface", "map", "package", "range", "return", "select", "struct", "switch", "type", "var"],
                type: ["bool", "byte", "complex64", "complex128", "error", "float32", "float64", "int8", "int16", "int32", "int64", "string", "uint8", "uint16", "uint32", "uint64", "int", "uint", "uintptr", "rune"],
                literal: ["true", "false", "iota", "nil"],
                built_in: ["append", "cap", "close", "complex", "copy", "imag", "len", "make", "new", "panic", "print", "println", "real", "recover", "delete"]
            };
            return {
                name: "Go",
                aliases: ["golang"],
                keywords: t,
                illegal: "</",
                contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                        className: "string",
                        variants: [e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
                                begin: "`",
                                end: "`"
                            }
                        ]
                    }, {
                        className: "number",
                        variants: [{
                                begin: e.C_NUMBER_RE + "[i]",
                                relevance: 1
                            }, e.C_NUMBER_MODE]
                    }, {
                        begin: /:=/
                    }, {
                        className: "function",
                        beginKeywords: "func",
                        end: "\\s*(\\{|$)",
                        excludeEnd: !0,
                        contains: [e.TITLE_MODE, {
                                className: "params",
                                begin: /\(/,
                                end: /\)/,
                                endsParent: !0,
                                keywords: t,
                                illegal: /["']/
                            }
                        ]
                    }
                ]
            }
        },
        grmr_graphql: e => {
            var t = e.regex;
            return {
                name: "GraphQL",
                aliases: ["gql"],
                case_insensitive: !0,
                disableAutodetect: !1,
                keywords: {
                    keyword: ["query", "mutation", "subscription", "type", "input", "schema", "directive", "interface", "union", "scalar", "fragment", "enum", "on"],
                    literal: ["true", "false", "null"]
                },
                contains: [e.HASH_COMMENT_MODE, e.QUOTE_STRING_MODE, e.NUMBER_MODE, {
                        scope: "punctuation",
                        match: /[.]{3}/,
                        relevance: 0
                    }, {
                        scope: "punctuation",
                        begin: /[\!\(\)\:\=\[\]\{\|\}]{1}/,
                        relevance: 0
                    }, {
                        scope: "variable",
                        begin: /\$/,
                        end: /\W/,
                        excludeEnd: !0,
                        relevance: 0
                    }, {
                        scope: "meta",
                        match: /@\w+/,
                        excludeEnd: !0
                    }, {
                        scope: "symbol",
                        begin: t.concat(/[_A-Za-z][_0-9A-Za-z]*/, t.lookahead(/\s*:/)),
                        relevance: 0
                    }
                ],
                illegal: [/[;<']/, /BEGIN/]
            }
        },
        grmr_ini: e => {
            var t = e.regex,
            n = {
                className: "number",
                relevance: 0,
                variants: [{
                        begin: /([+-]+)?[\d]+_[\d_]+/
                    }, {
                        begin: e.NUMBER_RE
                    }
                ]
            },
            r = e.COMMENT(),
            i = (r.variants = [{
                        begin: /;/,
                        end: /$/
                    }, {
                        begin: /#/,
                        end: /$/
                    }
                ], {
                className: "variable",
                variants: [{
                        begin: /\$[\w\d"][\w\d_]*/
                    }, {
                        begin: /\$\{(.*?)\}/
                    }
                ]
            }),
            a = {
                className: "literal",
                begin: /\bon|off|true|false|yes|no\b/
            },
            e = {
                className: "string",
                contains: [e.BACKSLASH_ESCAPE],
                variants: [{
                        begin: "'''",
                        end: "'''",
                        relevance: 10
                    }, {
                        begin: '"""',
                        end: '"""',
                        relevance: 10
                    }, {
                        begin: '"',
                        end: '"'
                    }, {
                        begin: "'",
                        end: "'"
                    }
                ]
            },
            s = {
                begin: /\[/,
                end: /\]/,
                contains: [r, a, i, e, n, "self"],
                relevance: 0
            },
            o = t.either(/[A-Za-z0-9_-]+/, /"(\\"|[^"])*"/, /'[^']*'/);
            return {
                name: "TOML, also INI",
                aliases: ["toml"],
                case_insensitive: !0,
                illegal: /\S/,
                contains: [r, {
                        className: "section",
                        begin: /\[+/,
                        end: /\]+/
                    }, {
                        begin: t.concat(o, "(\\s*\\.\\s*", o, ")*", t.lookahead(/\s*=\s*[^#\s]/)),
                        className: "attr",
                        starts: {
                            end: /$/,
                            contains: [r, s, a, i, e, n]
                        }
                    }
                ]
            }
        },
        grmr_java: e => {
            var t = e.regex,
            n = "[À-ʸa-zA-Z_$][À-ʸa-zA-Z_$0-9]*",
            r = n + function t(n, r, i) {
                return -1 === i ? "" : n.replace(r, e => t(n, r, i - 1))
            }
            ("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2),
            i = {
                keyword: ["synchronized", "abstract", "private", "var", "static", "if", "const ", "for", "while", "strictfp", "finally", "protected", "import", "native", "final", "void", "enum", "else", "break", "transient", "catch", "instanceof", "volatile", "case", "assert", "package", "default", "public", "try", "switch", "continue", "throws", "protected", "public", "private", "module", "requires", "exports", "do", "sealed"],
                literal: ["false", "true", "null"],
                type: ["char", "boolean", "long", "float", "int", "byte", "short", "double"],
                built_in: ["super", "this"]
            },
            a = {
                className: "meta",
                begin: "@" + n,
                contains: [{
                        begin: /\(/,
                        end: /\)/,
                        contains: ["self"]
                    }
                ]
            },
            s = {
                className: "params",
                begin: /\(/,
                end: /\)/,
                keywords: i,
                relevance: 0,
                contains: [e.C_BLOCK_COMMENT_MODE],
                endsParent: !0
            };
            return {
                name: "Java",
                aliases: ["jsp"],
                keywords: i,
                illegal: /<\/|#/,
                contains: [e.COMMENT("/\\*\\*", "\\*/", {
                        relevance: 0,
                        contains: [{
                                begin: /\w+@/,
                                relevance: 0
                            }, {
                                className: "doctag",
                                begin: "@[A-Za-z]+"
                            }
                        ]
                    }), {
                        begin: /import java\.[a-z]+\./,
                        keywords: "import",
                        relevance: 2
                    }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, {
                        begin: /"""/,
                        end: /"""/,
                        className: "string",
                        contains: [e.BACKSLASH_ESCAPE]
                    }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
                        match: [/\b(?:class|interface|enum|extends|implements|new)/, /\s+/, n],
                        className: {
                            1: "keyword",
                            3: "title.class"
                        }
                    }, {
                        match: /non-sealed/,
                        scope: "keyword"
                    }, {
                        begin: [t.concat(/(?!else)/, n), /\s+/, n, /\s+/, /=(?!=)/],
                        className: {
                            1: "type",
                            3: "variable",
                            5: "operator"
                        }
                    }, {
                        begin: [/record/, /\s+/, n],
                        className: {
                            1: "keyword",
                            3: "title.class"
                        },
                        contains: [s, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, {
                        beginKeywords: "new throw return else",
                        relevance: 0
                    }, {
                        begin: ["(?:" + r + "\\s+)", e.UNDERSCORE_IDENT_RE, /\s*(?=\()/],
                        className: {
                            2: "title.function"
                        },
                        keywords: i,
                        contains: [{
                                className: "params",
                                begin: /\(/,
                                end: /\)/,
                                keywords: i,
                                relevance: 0,
                                contains: [a, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, w, e.C_BLOCK_COMMENT_MODE]
                            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, w, a]
            }
        },
        grmr_javascript: he,
        grmr_json: e => {
            var t = ["true", "false", "null"],
            n = {
                scope: "literal",
                beginKeywords: t.join(" ")
            };
            return {
                name: "JSON",
                keywords: {
                    literal: t
                },
                contains: [{
                        className: "attr",
                        begin: /"(\\.|[^\\"\r\n])*"(?=\s*:)/,
                        relevance: 1.01
                    }, {
                        match: /[{}[\],:]/,
                        className: "punctuation",
                        relevance: 0
                    }, e.QUOTE_STRING_MODE, n, e.C_NUMBER_MODE, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE],
                illegal: "\\S"
            }
        },
        grmr_kotlin: e => {
            var t = {
                keyword: "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
                built_in: "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
                literal: "true false null"
            },
            n = {
                className: "symbol",
                begin: e.UNDERSCORE_IDENT_RE + "@"
            },
            r = {
                className: "subst",
                begin: /\$\{/,
                end: /\}/,
                contains: [e.C_NUMBER_MODE]
            },
            i = {
                className: "variable",
                begin: "\\$" + e.UNDERSCORE_IDENT_RE
            },
            i = {
                className: "string",
                variants: [{
                        begin: '"""',
                        end: '"""(?=[^"])',
                        contains: [i, r]
                    }, {
                        begin: "'",
                        end: "'",
                        illegal: /\n/,
                        contains: [e.BACKSLASH_ESCAPE]
                    }, {
                        begin: '"',
                        end: '"',
                        illegal: /\n/,
                        contains: [e.BACKSLASH_ESCAPE, i, r]
                    }
                ]
            },
            r = (r.contains.push(i), {
                className: "meta",
                begin: "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" + e.UNDERSCORE_IDENT_RE + ")?"
            }),
            a = {
                className: "meta",
                begin: "@" + e.UNDERSCORE_IDENT_RE,
                contains: [{
                        begin: /\(/,
                        end: /\)/,
                        contains: [e.inherit(i, {
                                className: "string"
                            }), "self"]
                    }
                ]
            },
            s = w,
            o = e.COMMENT("/\\*", "\\*/", {
                contains: [e.C_BLOCK_COMMENT_MODE]
            }),
            l = {
                variants: [{
                        className: "type",
                        begin: e.UNDERSCORE_IDENT_RE
                    }, {
                        begin: /\(/,
                        end: /\)/,
                        contains: []
                    }
                ]
            },
            c = l;
            return c.variants[1].contains = [l],
            l.variants[1].contains = [c], {
                name: "Kotlin",
                aliases: ["kt", "kts"],
                keywords: t,
                contains: [e.COMMENT("/\\*\\*", "\\*/", {
                        relevance: 0,
                        contains: [{
                                className: "doctag",
                                begin: "@[A-Za-z]+"
                            }
                        ]
                    }), e.C_LINE_COMMENT_MODE, o, {
                        className: "keyword",
                        begin: /\b(break|continue|return|this)\b/,
                        starts: {
                            contains: [{
                                    className: "symbol",
                                    begin: /@\w+/
                                }
                            ]
                        }
                    }, n, r, a, {
                        className: "function",
                        beginKeywords: "fun",
                        end: "[(]|$",
                        returnBegin: !0,
                        excludeEnd: !0,
                        keywords: t,
                        relevance: 5,
                        contains: [{
                                begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
                                returnBegin: !0,
                                relevance: 0,
                                contains: [e.UNDERSCORE_TITLE_MODE]
                            }, {
                                className: "type",
                                begin: /</,
                                end: />/,
                                keywords: "reified",
                                relevance: 0
                            }, {
                                className: "params",
                                begin: /\(/,
                                end: /\)/,
                                endsParent: !0,
                                keywords: t,
                                relevance: 0,
                                contains: [{
                                        begin: /:/,
                                        end: /[=,\/]/,
                                        endsWithParent: !0,
                                        contains: [l, e.C_LINE_COMMENT_MODE, o],
                                        relevance: 0
                                    }, e.C_LINE_COMMENT_MODE, o, r, a, i, e.C_NUMBER_MODE]
                            }, o]
                    }, {
                        begin: [/class|interface|trait/, /\s+/, e.UNDERSCORE_IDENT_RE],
                        beginScope: {
                            3: "title.class"
                        },
                        keywords: "class interface trait",
                        end: /[:\{(]|$/,
                        excludeEnd: !0,
                        illegal: "extends implements",
                        contains: [{
                                beginKeywords: "public protected internal private constructor"
                            }, e.UNDERSCORE_TITLE_MODE, {
                                className: "type",
                                begin: /</,
                                end: />/,
                                excludeBegin: !0,
                                excludeEnd: !0,
                                relevance: 0
                            }, {
                                className: "type",
                                begin: /[,:]\s*/,
                                end: /[<\(,){\s]|$/,
                                excludeBegin: !0,
                                returnEnd: !0
                            }, r, a]
                    }, i, {
                        className: "meta",
                        begin: "^#!/usr/bin/env",
                        end: "$",
                        illegal: "\n"
                    }, s]
            }
        },
        grmr_less: e => {
            var t = m(e),
            n = oe,
            r = "([\\w-]+|@\\{[\\w-]+\\})",
            i = [],
            a = [],
            s = e => ({
                className: "string",
                begin: "~?" + e + ".*?" + e
            }),
            o = (e, t, n) => ({
                className: e,
                begin: t,
                relevance: n
            }),
            l = {
                $pattern: /[a-z-]+/,
                keyword: "and or not only",
                attribute: y.join(" ")
            },
            s = (a.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, s("'"), s('"'), t.CSS_NUMBER_MODE, {
                    begin: "(url|data-uri)\\(",
                    starts: {
                        className: "string",
                        end: "[\\)\\n]",
                        excludeEnd: !0
                    }
                }, t.HEXCOLOR, {
                    begin: "\\(",
                    end: "\\)",
                    contains: a,
                    keywords: l,
                    relevance: 0
                }, o("variable", "@@?[\\w-]+", 10), o("variable", "@\\{[\\w-]+\\}"), o("built_in", "~?`[^`]*?`"), {
                    className: "attribute",
                    begin: "[\\w-]+\\s*:",
                    end: ":",
                    returnBegin: !0,
                    excludeEnd: !0
                }, t.IMPORTANT, {
                    beginKeywords: "and not"
                }, t.FUNCTION_DISPATCH), a.concat({
                    begin: /\{/,
                    end: /\}/,
                    contains: i
                })),
            c = {
                beginKeywords: "when",
                endsWithParent: !0,
                contains: [{
                        beginKeywords: "and not"
                    }
                ].concat(a)
            },
            u = {
                begin: r + "\\s*:",
                returnBegin: !0,
                end: /[;}]/,
                relevance: 0,
                contains: [{
                        begin: /-(webkit|moz|ms|o)-/
                    }, t.CSS_VARIABLE, {
                        className: "attribute",
                        begin: "\\b(" + E.join("|") + ")\\b",
                        end: /(?=:)/,
                        starts: {
                            endsWithParent: !0,
                            illegal: "[<=$]",
                            relevance: 0,
                            contains: a
                        }
                    }
                ]
            },
            l = {
                className: "keyword",
                begin: "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
                starts: {
                    end: "[;{}]",
                    keywords: l,
                    returnEnd: !0,
                    contains: a,
                    relevance: 0
                }
            },
            a = {
                className: "variable",
                variants: [{
                        begin: "@[\\w-]+\\s*:",
                        relevance: 15
                    }, {
                        begin: "@[\\w-]+"
                    }
                ],
                starts: {
                    end: "[;}]",
                    returnEnd: !0,
                    contains: s
                }
            },
            r = {
                variants: [{
                        begin: "[\\.#:&\\[>]",
                        end: "[;{}]"
                    }, {
                        begin: r,
                        end: /\{/
                    }
                ],
                returnBegin: !0,
                returnEnd: !0,
                illegal: "[<='$\"]",
                relevance: 0,
                contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, c, o("keyword", "all\\b"), o("variable", "@\\{[\\w-]+\\}"), {
                        begin: "\\b(" + b.join("|") + ")\\b",
                        className: "selector-tag"
                    }, t.CSS_NUMBER_MODE, o("selector-tag", r, 0), o("selector-id", "#" + r), o("selector-class", "\\." + r, 0), o("selector-tag", "&", 0), t.ATTRIBUTE_SELECTOR_MODE, {
                        className: "selector-pseudo",
                        begin: ":(" + v.join("|") + ")"
                    }, {
                        className: "selector-pseudo",
                        begin: ":(:)?(" + _.join("|") + ")"
                    }, {
                        begin: /\(/,
                        end: /\)/,
                        relevance: 0,
                        contains: s
                    }, {
                        begin: "!important"
                    }, t.FUNCTION_DISPATCH]
            },
            o = {
                begin: `[\\w-]+:(:)?(${n.join("|")})`,
                returnBegin: !0,
                contains: [r]
            };
            return i.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, l, a, o, u, r, c, t.FUNCTION_DISPATCH), {
                name: "Less",
                case_insensitive: !0,
                illegal: "[=>'/<($\"]",
                contains: i
            }
        },
        grmr_lua: e => {
            var t = "\\[=*\\[",
            n = "\\]=*\\]",
            r = {
                begin: t,
                end: n,
                contains: ["self"]
            },
            i = [e.COMMENT("--(?!\\[=*\\[)", "$"), e.COMMENT("--\\[=*\\[", n, {
                    contains: [r],
                    relevance: 10
                })];
            return {
                name: "Lua",
                keywords: {
                    $pattern: e.UNDERSCORE_IDENT_RE,
                    literal: "true false nil",
                    keyword: "and break do else elseif end for goto if in local not or repeat return then until while",
                    built_in: "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove"
                },
                contains: i.concat([{
                            className: "function",
                            beginKeywords: "function",
                            end: "\\)",
                            contains: [e.inherit(e.TITLE_MODE, {
                                    begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*"
                                }), {
                                    className: "params",
                                    begin: "\\(",
                                    endsWithParent: !0,
                                    contains: i
                                }
                            ].concat(i)
                        }, e.C_NUMBER_MODE, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE, {
                            className: "string",
                            begin: t,
                            end: n,
                            contains: [r],
                            relevance: 5
                        }
                    ])
            }
        },
        grmr_makefile: e => {
            var t = {
                className: "variable",
                variants: [{
                        begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
                        contains: [e.BACKSLASH_ESCAPE]
                    }, {
                        begin: /\$[@%<?\^\+\*]/
                    }
                ]
            },
            n = {
                className: "string",
                begin: /"/,
                end: /"/,
                contains: [e.BACKSLASH_ESCAPE, t]
            },
            r = {
                begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)"
            };
            return {
                name: "Makefile",
                aliases: ["mk", "mak", "make"],
                keywords: {
                    $pattern: /[\w-]+/,
                    keyword: "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath"
                },
                contains: [e.HASH_COMMENT_MODE, t, n, {
                        className: "variable",
                        begin: /\$\([\w-]+\s/,
                        end: /\)/,
                        keywords: {
                            built_in: "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value"
                        },
                        contains: [t]
                    }, r, {
                        className: "meta",
                        begin: /^\.PHONY:/,
                        end: /$/,
                        keywords: {
                            $pattern: /[\.\w]+/,
                            keyword: ".PHONY"
                        }
                    }, {
                        className: "section",
                        begin: /^[^\s]+:/,
                        end: /$/,
                        contains: [t]
                    }
                ]
            }
        },
        grmr_xml: e => {
            var t = e.regex,
            n = t.concat(/[\p{L}_]/u, t.optional(/[\p{L}0-9_.-]*:/u), /[\p{L}0-9_.-]*/u),
            r = {
                className: "symbol",
                begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/
            },
            i = {
                begin: /\s/,
                contains: [{
                        className: "keyword",
                        begin: /#?[a-z_][a-z1-9_-]+/,
                        illegal: /\n/
                    }
                ]
            },
            a = e.inherit(i, {
                begin: /\(/,
                end: /\)/
            }),
            s = e.inherit(e.APOS_STRING_MODE, {
                className: "string"
            }),
            o = e.inherit(e.QUOTE_STRING_MODE, {
                className: "string"
            }),
            l = {
                endsWithParent: !0,
                illegal: /</,
                relevance: 0,
                contains: [{
                        className: "attr",
                        begin: /[\p{L}0-9._:-]+/u,
                        relevance: 0
                    }, {
                        begin: /=\s*/,
                        relevance: 0,
                        contains: [{
                                className: "string",
                                endsParent: !0,
                                variants: [{
                                        begin: /"/,
                                        end: /"/,
                                        contains: [r]
                                    }, {
                                        begin: /'/,
                                        end: /'/,
                                        contains: [r]
                                    }, {
                                        begin: /[^\s"'=<>`]+/
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };
            return {
                name: "HTML, XML",
                aliases: ["html", "xhtml", "rss", "atom", "xjb", "xsd", "xsl", "plist", "wsf", "svg"],
                case_insensitive: !0,
                unicodeRegex: !0,
                contains: [{
                        className: "meta",
                        begin: /<![a-z]/,
                        end: />/,
                        relevance: 10,
                        contains: [i, o, s, a, {
                                begin: /\[/,
                                end: /\]/,
                                contains: [{
                                        className: "meta",
                                        begin: /<![a-z]/,
                                        end: />/,
                                        contains: [i, a, o, s]
                                    }
                                ]
                            }
                        ]
                    }, e.COMMENT(/<!--/, /-->/, {
                        relevance: 10
                    }), {
                        begin: /<!\[CDATA\[/,
                        end: /\]\]>/,
                        relevance: 10
                    }, r, {
                        className: "meta",
                        end: /\?>/,
                        variants: [{
                                begin: /<\?xml/,
                                relevance: 10,
                                contains: [o]
                            }, {
                                begin: /<\?[a-z][a-z0-9]+/
                            }
                        ]
                    }, {
                        className: "tag",
                        begin: /<style(?=\s|>)/,
                        end: />/,
                        keywords: {
                            name: "style"
                        },
                        contains: [l],
                        starts: {
                            end: /<\/style>/,
                            returnEnd: !0,
                            subLanguage: ["css", "xml"]
                        }
                    }, {
                        className: "tag",
                        begin: /<script(?=\s|>)/,
                        end: />/,
                        keywords: {
                            name: "script"
                        },
                        contains: [l],
                        starts: {
                            end: /<\/script>/,
                            returnEnd: !0,
                            subLanguage: ["javascript", "handlebars", "xml"]
                        }
                    }, {
                        className: "tag",
                        begin: /<>|<\/>/
                    }, {
                        className: "tag",
                        begin: t.concat(/</, t.lookahead(t.concat(n, t.either(/\/>/, />/, /\s/)))),
                        end: /\/?>/,
                        contains: [{
                                className: "name",
                                begin: n,
                                relevance: 0,
                                starts: l
                            }
                        ]
                    }, {
                        className: "tag",
                        begin: t.concat(/<\//, t.lookahead(t.concat(n, />/))),
                        contains: [{
                                className: "name",
                                begin: n,
                                relevance: 0
                            }, {
                                begin: />/,
                                relevance: 0,
                                endsParent: !0
                            }
                        ]
                    }
                ]
            }
        },
        grmr_markdown: e => {
            var t = {
                begin: /<\/?[A-Za-z_]/,
                end: ">",
                subLanguage: "xml",
                relevance: 0
            },
            n = {
                variants: [{
                        begin: /\[.+?\]\[.*?\]/,
                        relevance: 0
                    }, {
                        begin: /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
                        relevance: 2
                    }, {
                        begin: e.regex.concat(/\[.+?\]\(/, /[A-Za-z][A-Za-z0-9+.-]*/, /:\/\/.*?\)/),
                        relevance: 2
                    }, {
                        begin: /\[.+?\]\([./?&#].*?\)/,
                        relevance: 1
                    }, {
                        begin: /\[.*?\]\(.*?\)/,
                        relevance: 0
                    }
                ],
                returnBegin: !0,
                contains: [{
                        match: /\[(?=\])/
                    }, {
                        className: "string",
                        relevance: 0,
                        begin: "\\[",
                        end: "\\]",
                        excludeBegin: !0,
                        returnEnd: !0
                    }, {
                        className: "link",
                        relevance: 0,
                        begin: "\\]\\(",
                        end: "\\)",
                        excludeBegin: !0,
                        excludeEnd: !0
                    }, {
                        className: "symbol",
                        relevance: 0,
                        begin: "\\]\\[",
                        end: "\\]",
                        excludeBegin: !0,
                        excludeEnd: !0
                    }
                ]
            },
            r = {
                className: "strong",
                contains: [],
                variants: [{
                        begin: /_{2}/,
                        end: /_{2}/
                    }, {
                        begin: /\*{2}/,
                        end: /\*{2}/
                    }
                ]
            },
            i = {
                className: "emphasis",
                contains: [],
                variants: [{
                        begin: /\*(?!\*)/,
                        end: /\*/
                    }, {
                        begin: /_(?!_)/,
                        end: /_/,
                        relevance: 0
                    }
                ]
            },
            a = e.inherit(r, {
                contains: []
            }),
            e = e.inherit(i, {
                contains: []
            });
            r.contains.push(e),
            i.contains.push(a);
            let s = [t, n];
            return [r, i, a, e].forEach(e => {
                e.contains = e.contains.concat(s)
            }), {
                name: "Markdown",
                aliases: ["md", "mkdown", "mkd"],
                contains: [{
                        className: "section",
                        variants: [{
                                begin: "^#{1,6}",
                                end: "$",
                                contains: s = s.concat(r, i)
                            }, {
                                begin: "(?=^.+?\\n[=-]{2,}$)",
                                contains: [{
                                        begin: "^[=-]*$"
                                    }, {
                                        begin: "^",
                                        end: "\\n",
                                        contains: s
                                    }
                                ]
                            }
                        ]
                    }, t, {
                        className: "bullet",
                        begin: "^[ \t]*([*+-]|(\\d+\\.))(?=\\s+)",
                        end: "\\s+",
                        excludeEnd: !0
                    }, r, i, {
                        className: "quote",
                        begin: "^>\\s+",
                        contains: s,
                        end: "$"
                    }, {
                        className: "code",
                        variants: [{
                                begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*"
                            }, {
                                begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*"
                            }, {
                                begin: "```",
                                end: "```+[ ]*$"
                            }, {
                                begin: "~~~",
                                end: "~~~+[ ]*$"
                            }, {
                                begin: "`.+?`"
                            }, {
                                begin: "(?=^( {4}|\\t))",
                                contains: [{
                                        begin: "^( {4}|\\t)",
                                        end: "(\\n)$"
                                    }
                                ],
                                relevance: 0
                            }
                        ]
                    }, {
                        begin: "^[-\\*]{3,}",
                        end: "$"
                    }, n, {
                        begin: /^\[[^\n]+\]:/,
                        returnBegin: !0,
                        contains: [{
                                className: "symbol",
                                begin: /\[/,
                                end: /\]/,
                                excludeBegin: !0,
                                excludeEnd: !0
                            }, {
                                className: "link",
                                begin: /:\s*/,
                                end: /$/,
                                excludeBegin: !0
                            }
                        ]
                    }
                ]
            }
        },
        grmr_objectivec: e => {
            var t = /[a-zA-Z@][a-zA-Z0-9_]*/,
            n = {
                $pattern: t,
                keyword: ["@interface", "@class", "@protocol", "@implementation"]
            };
            return {
                name: "Objective-C",
                aliases: ["mm", "objc", "obj-c", "obj-c++", "objective-c++"],
                keywords: {
                    "variable.language": ["this", "super"],
                    $pattern: t,
                    keyword: ["while", "export", "sizeof", "typedef", "const", "struct", "for", "union", "volatile", "static", "mutable", "if", "do", "return", "goto", "enum", "else", "break", "extern", "asm", "case", "default", "register", "explicit", "typename", "switch", "continue", "inline", "readonly", "assign", "readwrite", "self", "@synchronized", "id", "typeof", "nonatomic", "IBOutlet", "IBAction", "strong", "weak", "copy", "in", "out", "inout", "bycopy", "byref", "oneway", "__strong", "__weak", "__block", "__autoreleasing", "@private", "@protected", "@public", "@try", "@property", "@end", "@throw", "@catch", "@finally", "@autoreleasepool", "@synthesize", "@dynamic", "@selector", "@optional", "@required", "@encode", "@package", "@import", "@defs", "@compatibility_alias", "__bridge", "__bridge_transfer", "__bridge_retained", "__bridge_retain", "__covariant", "__contravariant", "__kindof", "_Nonnull", "_Nullable", "_Null_unspecified", "__FUNCTION__", "__PRETTY_FUNCTION__", "__attribute__", "getter", "setter", "retain", "unsafe_unretained", "nonnull", "nullable", "null_unspecified", "null_resettable", "class", "instancetype", "NS_DESIGNATED_INITIALIZER", "NS_UNAVAILABLE", "NS_REQUIRES_SUPER", "NS_RETURNS_INNER_POINTER", "NS_INLINE", "NS_AVAILABLE", "NS_DEPRECATED", "NS_ENUM", "NS_OPTIONS", "NS_SWIFT_UNAVAILABLE", "NS_ASSUME_NONNULL_BEGIN", "NS_ASSUME_NONNULL_END", "NS_REFINED_FOR_SWIFT", "NS_SWIFT_NAME", "NS_SWIFT_NOTHROW", "NS_DURING", "NS_HANDLER", "NS_ENDHANDLER", "NS_VALUERETURN", "NS_VOIDRETURN"],
                    literal: ["false", "true", "FALSE", "TRUE", "nil", "YES", "NO", "NULL"],
                    built_in: ["dispatch_once_t", "dispatch_queue_t", "dispatch_sync", "dispatch_async", "dispatch_once"],
                    type: ["int", "float", "char", "unsigned", "signed", "short", "long", "double", "wchar_t", "unichar", "void", "bool", "BOOL", "id|0", "_Bool"]
                },
                illegal: "</",
                contains: [{
                        className: "built_in",
                        begin: "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+"
                    }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, e.C_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, {
                        className: "string",
                        variants: [{
                                begin: '@"',
                                end: '"',
                                illegal: "\\n",
                                contains: [e.BACKSLASH_ESCAPE]
                            }
                        ]
                    }, {
                        className: "meta",
                        begin: /#\s*[a-z]+\b/,
                        end: /$/,
                        keywords: {
                            keyword: "if else elif endif define undef warning error line pragma ifdef ifndef include"
                        },
                        contains: [{
                                begin: /\\\n/,
                                relevance: 0
                            }, e.inherit(e.QUOTE_STRING_MODE, {
                                className: "string"
                            }), {
                                className: "string",
                                begin: /<.*?>/,
                                end: /$/,
                                illegal: "\\n"
                            }, e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE]
                    }, {
                        className: "class",
                        begin: "(" + n.keyword.join("|") + ")\\b",
                        end: /(\{|$)/,
                        excludeEnd: !0,
                        keywords: n,
                        contains: [e.UNDERSCORE_TITLE_MODE]
                    }, {
                        begin: "\\." + e.UNDERSCORE_IDENT_RE,
                        relevance: 0
                    }
                ]
            }
        },
        grmr_perl: e => {
            const i = e.regex,
            a = /[dualxmsipngr]{0,12}/,
            t = {
                $pattern: /[\w.]+/,
                keyword: "abs accept alarm and atan2 bind binmode bless break caller chdir chmod chomp chop chown chr chroot close closedir connect continue cos crypt dbmclose dbmopen defined delete die do dump each else elsif endgrent endhostent endnetent endprotoent endpwent endservent eof eval exec exists exit exp fcntl fileno flock for foreach fork format formline getc getgrent getgrgid getgrnam gethostbyaddr gethostbyname gethostent getlogin getnetbyaddr getnetbyname getnetent getpeername getpgrp getpriority getprotobyname getprotobynumber getprotoent getpwent getpwnam getpwuid getservbyname getservbyport getservent getsockname getsockopt given glob gmtime goto grep gt hex if index int ioctl join keys kill last lc lcfirst length link listen local localtime log lstat lt ma map mkdir msgctl msgget msgrcv msgsnd my ne next no not oct open opendir or ord our pack package pipe pop pos print printf prototype push q|0 qq quotemeta qw qx rand read readdir readline readlink readpipe recv redo ref rename require reset return reverse rewinddir rindex rmdir say scalar seek seekdir select semctl semget semop send setgrent sethostent setnetent setpgrp setpriority setprotoent setpwent setservent setsockopt shift shmctl shmget shmread shmwrite shutdown sin sleep socket socketpair sort splice split sprintf sqrt srand stat state study sub substr symlink syscall sysopen sysread sysseek system syswrite tell telldir tie tied time times tr truncate uc ucfirst umask undef unless unlink unpack unshift untie until use utime values vec wait waitpid wantarray warn when while write x|0 xor y|0"
            },
            n = {
                className: "subst",
                begin: "[$@]\\{",
                end: "\\}",
                keywords: t
            },
            r = {
                begin: /->\{/,
                end: /\}/
            },
            s = {
                variants: [{
                        begin: /\$\d/
                    }, {
                        begin: i.concat(/[$%@](\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/, "(?![A-Za-z])(?![@$%])")
                    }, {
                        begin: /[$%@][^\s\w{]/,
                        relevance: 0
                    }
                ]
            },
            o = [e.BACKSLASH_ESCAPE, n, s],
            l = [/!/, /\//, /\|/, /\?/, /'/, /"/, /#/],
            c = (e, t, n = "\\1") => {
                var r = "\\1" === n ? n : i.concat(n, t);
                return i.concat(i.concat("(?:", e, ")"), t, /(?:\\.|[^\\\/])*?/, r, /(?:\\.|[^\\\/])*?/, n, a)
            },
            u = (e, t, n) => i.concat(i.concat("(?:", e, ")"), t, /(?:\\.|[^\\\/])*?/, n, a),
            d = [s, e.HASH_COMMENT_MODE, e.COMMENT(/^=\w/, /=cut/, {
                    endsWithParent: !0
                }), r, {
                    className: "string",
                    contains: o,
                    variants: [{
                            begin: "q[qwxr]?\\s*\\(",
                            end: "\\)",
                            relevance: 5
                        }, {
                            begin: "q[qwxr]?\\s*\\[",
                            end: "\\]",
                            relevance: 5
                        }, {
                            begin: "q[qwxr]?\\s*\\{",
                            end: "\\}",
                            relevance: 5
                        }, {
                            begin: "q[qwxr]?\\s*\\|",
                            end: "\\|",
                            relevance: 5
                        }, {
                            begin: "q[qwxr]?\\s*<",
                            end: ">",
                            relevance: 5
                        }, {
                            begin: "qw\\s+q",
                            end: "q",
                            relevance: 5
                        }, {
                            begin: "'",
                            end: "'",
                            contains: [e.BACKSLASH_ESCAPE]
                        }, {
                            begin: '"',
                            end: '"'
                        }, {
                            begin: "`",
                            end: "`",
                            contains: [e.BACKSLASH_ESCAPE]
                        }, {
                            begin: /\{\w+\}/,
                            relevance: 0
                        }, {
                            begin: "-?\\w+\\s*=>",
                            relevance: 0
                        }
                    ]
                }, {
                    className: "number",
                    begin: "(\\b0[0-7_]+)|(\\b0x[0-9a-fA-F_]+)|(\\b[1-9][0-9_]*(\\.[0-9_]+)?)|[0_]\\b",
                    relevance: 0
                }, {
                    begin: "(\\/\\/|" + e.RE_STARTERS_RE + "|\\b(split|return|print|reverse|grep)\\b)\\s*",
                    keywords: "split return print reverse grep",
                    relevance: 0,
                    contains: [e.HASH_COMMENT_MODE, {
                            className: "regexp",
                            variants: [{
                                    begin: c("s|tr|y", i.either(...l, {
                                            capture: !0
                                        }))
                                }, {
                                    begin: c("s|tr|y", "\\(", "\\)")
                                }, {
                                    begin: c("s|tr|y", "\\[", "\\]")
                                }, {
                                    begin: c("s|tr|y", "\\{", "\\}")
                                }
                            ],
                            relevance: 2
                        }, {
                            className: "regexp",
                            variants: [{
                                    begin: /(m|qr)\/\//,
                                    relevance: 0
                                }, {
                                    begin: u("(?:m|qr)?", /\//, /\//)
                                }, {
                                    begin: u("m|qr", i.either(...l, {
                                            capture: !0
                                        }), /\1/)
                                }, {
                                    begin: u("m|qr", /\(/, /\)/)
                                }, {
                                    begin: u("m|qr", /\[/, /\]/)
                                }, {
                                    begin: u("m|qr", /\{/, /\}/)
                                }
                            ]
                        }
                    ]
                }, {
                    className: "function",
                    beginKeywords: "sub",
                    end: "(\\s*\\(.*?\\))?[;{]",
                    excludeEnd: !0,
                    relevance: 5,
                    contains: [e.TITLE_MODE]
                }, {
                    begin: "-\\w\\b",
                    relevance: 0
                }, {
                    begin: "^__DATA__$",
                    end: "^__END__$",
                    subLanguage: "mojolicious",
                    contains: [{
                            begin: "^@@.*",
                            end: "$",
                            className: "comment"
                        }
                    ]
                }
            ];
            return n.contains = d, {
                name: "Perl",
                aliases: ["pl", "pm"],
                keywords: t,
                contains: r.contains = d
            }
        },
        grmr_php: e => {
            const t = e.regex,
            n = /(?![A-Za-z0-9])(?![$])/,
            r = t.concat(/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/, n),
            i = t.concat(/(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/, n),
            a = {
                scope: "variable",
                match: "\\$+" + r
            },
            s = {
                scope: "subst",
                variants: [{
                        begin: /\$\w+/
                    }, {
                        begin: /\{\$/,
                        end: /\}/
                    }
                ]
            },
            o = e.inherit(e.APOS_STRING_MODE, {
                illegal: null
            }),
            l = "[ \t\n]",
            c = {
                scope: "string",
                variants: [e.inherit(e.QUOTE_STRING_MODE, {
                        illegal: null,
                        contains: e.QUOTE_STRING_MODE.contains.concat(s)
                    }), o, e.END_SAME_AS_BEGIN({
                        begin: /<<<[ \t]*(\w+)\n/,
                        end: /[ \t]*(\w+)\b/,
                        contains: e.QUOTE_STRING_MODE.contains.concat(s)
                    })]
            },
            u = {
                scope: "number",
                variants: [{
                        begin: "\\b0[bB][01]+(?:_[01]+)*\\b"
                    }, {
                        begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b"
                    }, {
                        begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b"
                    }, {
                        begin: "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?"
                    }
                ],
                relevance: 0
            },
            d = ["false", "null", "true"],
            p = ["__CLASS__", "__DIR__", "__FILE__", "__FUNCTION__", "__COMPILER_HALT_OFFSET__", "__LINE__", "__METHOD__", "__NAMESPACE__", "__TRAIT__", "die", "echo", "exit", "include", "include_once", "print", "require", "require_once", "array", "abstract", "and", "as", "binary", "bool", "boolean", "break", "callable", "case", "catch", "class", "clone", "const", "continue", "declare", "default", "do", "double", "else", "elseif", "empty", "enddeclare", "endfor", "endforeach", "endif", "endswitch", "endwhile", "enum", "eval", "extends", "final", "finally", "float", "for", "foreach", "from", "global", "goto", "if", "implements", "instanceof", "insteadof", "int", "integer", "interface", "isset", "iterable", "list", "match|0", "mixed", "new", "never", "object", "or", "private", "protected", "public", "readonly", "real", "return", "string", "switch", "throw", "trait", "try", "unset", "use", "var", "void", "while", "xor", "yield"],
            g = ["Error|0", "AppendIterator", "ArgumentCountError", "ArithmeticError", "ArrayIterator", "ArrayObject", "AssertionError", "BadFunctionCallException", "BadMethodCallException", "CachingIterator", "CallbackFilterIterator", "CompileError", "Countable", "DirectoryIterator", "DivisionByZeroError", "DomainException", "EmptyIterator", "ErrorException", "Exception", "FilesystemIterator", "FilterIterator", "GlobIterator", "InfiniteIterator", "InvalidArgumentException", "IteratorIterator", "LengthException", "LimitIterator", "LogicException", "MultipleIterator", "NoRewindIterator", "OutOfBoundsException", "OutOfRangeException", "OuterIterator", "OverflowException", "ParentIterator", "ParseError", "RangeException", "RecursiveArrayIterator", "RecursiveCachingIterator", "RecursiveCallbackFilterIterator", "RecursiveDirectoryIterator", "RecursiveFilterIterator", "RecursiveIterator", "RecursiveIteratorIterator", "RecursiveRegexIterator", "RecursiveTreeIterator", "RegexIterator", "RuntimeException", "SeekableIterator", "SplDoublyLinkedList", "SplFileInfo", "SplFileObject", "SplFixedArray", "SplHeap", "SplMaxHeap", "SplMinHeap", "SplObjectStorage", "SplObserver", "SplPriorityQueue", "SplQueue", "SplStack", "SplSubject", "SplTempFileObject", "TypeError", "UnderflowException", "UnexpectedValueException", "UnhandledMatchError", "ArrayAccess", "BackedEnum", "Closure", "Fiber", "Generator", "Iterator", "IteratorAggregate", "Serializable", "Stringable", "Throwable", "Traversable", "UnitEnum", "WeakReference", "WeakMap", "Directory", "__PHP_Incomplete_Class", "parent", "php_user_filter", "self", "static", "stdClass"],
            f = {
                keyword: p,
                literal: (() => {
                    const t = [];
                    return d.forEach(e => {
                        t.push(e),
                        e.toLowerCase() === e ? t.push(e.toUpperCase()) : t.push(e.toLowerCase())
                    }),
                    t
                })(),
                built_in: g
            },
            h = e => e.map(e => e.replace(/\|\d+$/, "")),
            m = {
                variants: [{
                        match: [/new/, t.concat(l, "+"), t.concat("(?!", h(g).join("\\b|"), "\\b)"), i],
                        scope: {
                            1: "keyword",
                            4: "title.class"
                        }
                    }
                ]
            },
            b = t.concat(r, "\\b(?!\\()"),
            y = {
                variants: [{
                        match: [t.concat(/::/, t.lookahead(/(?!class\b)/)), b],
                        scope: {
                            2: "variable.constant"
                        }
                    }, {
                        match: [/::/, /class/],
                        scope: {
                            2: "variable.language"
                        }
                    }, {
                        match: [i, t.concat(/::/, t.lookahead(/(?!class\b)/)), b],
                        scope: {
                            1: "title.class",
                            3: "variable.constant"
                        }
                    }, {
                        match: [i, t.concat("::", t.lookahead(/(?!class\b)/))],
                        scope: {
                            1: "title.class"
                        }
                    }, {
                        match: [i, /::/, /class/],
                        scope: {
                            1: "title.class",
                            3: "variable.language"
                        }
                    }
                ]
            },
            v = {
                scope: "attr",
                match: t.concat(r, t.lookahead(":"), t.lookahead(/(?!::)/))
            },
            _ = {
                relevance: 0,
                begin: /\(/,
                end: /\)/,
                keywords: f,
                contains: [v, a, y, e.C_BLOCK_COMMENT_MODE, c, u, m]
            },
            E = {
                relevance: 0,
                match: [/\b/, t.concat("(?!fn\\b|function\\b|", h(p).join("\\b|"), "|", h(g).join("\\b|"), "\\b)"), r, t.concat(l, "*"), t.lookahead(/(?=\()/)],
                scope: {
                    3: "title.function.invoke"
                },
                contains: [_]
            };
            _.contains.push(E);
            var w = [v, y, e.C_BLOCK_COMMENT_MODE, c, u, m];
            return {
                case_insensitive: !1,
                keywords: f,
                contains: [{
                        begin: t.concat(/#\[\s*/, i),
                        beginScope: "meta",
                        end: /]/,
                        endScope: "meta",
                        keywords: {
                            literal: d,
                            keyword: ["new", "array"]
                        },
                        contains: [{
                                begin: /\[/,
                                end: /]/,
                                keywords: {
                                    literal: d,
                                    keyword: ["new", "array"]
                                },
                                contains: ["self", ...w]
                            }, ...w, {
                                scope: "meta",
                                match: i
                            }
                        ]
                    }, e.HASH_COMMENT_MODE, e.COMMENT("//", "$"), e.COMMENT("/\\*", "\\*/", {
                        contains: [{
                                scope: "doctag",
                                match: "@[A-Za-z]+"
                            }
                        ]
                    }), {
                        match: /__halt_compiler\(\);/,
                        keywords: "__halt_compiler",
                        starts: {
                            scope: "comment",
                            end: e.MATCH_NOTHING_RE,
                            contains: [{
                                    match: /\?>/,
                                    scope: "meta",
                                    endsParent: !0
                                }
                            ]
                        }
                    }, {
                        scope: "meta",
                        variants: [{
                                begin: /<\?php/,
                                relevance: 10
                            }, {
                                begin: /<\?=/
                            }, {
                                begin: /<\?/,
                                relevance: .1
                            }, {
                                begin: /\?>/
                            }
                        ]
                    }, {
                        scope: "variable.language",
                        match: /\$this\b/
                    }, a, E, y, {
                        match: [/const/, /\s/, r],
                        scope: {
                            1: "keyword",
                            3: "variable.constant"
                        }
                    }, m, {
                        scope: "function",
                        relevance: 0,
                        beginKeywords: "fn function",
                        end: /[;{]/,
                        excludeEnd: !0,
                        illegal: "[$%\\[]",
                        contains: [{
                                beginKeywords: "use"
                            }, e.UNDERSCORE_TITLE_MODE, {
                                begin: "=>",
                                endsParent: !0
                            }, {
                                scope: "params",
                                begin: "\\(",
                                end: "\\)",
                                excludeBegin: !0,
                                excludeEnd: !0,
                                keywords: f,
                                contains: ["self", a, y, e.C_BLOCK_COMMENT_MODE, c, u]
                            }
                        ]
                    }, {
                        scope: "class",
                        variants: [{
                                beginKeywords: "enum",
                                illegal: /[($"]/
                            }, {
                                beginKeywords: "class interface trait",
                                illegal: /[:($"]/
                            }
                        ],
                        relevance: 0,
                        end: /\{/,
                        excludeEnd: !0,
                        contains: [{
                                beginKeywords: "extends implements"
                            }, e.UNDERSCORE_TITLE_MODE]
                    }, {
                        beginKeywords: "namespace",
                        relevance: 0,
                        end: ";",
                        illegal: /[.']/,
                        contains: [e.inherit(e.UNDERSCORE_TITLE_MODE, {
                                scope: "title.class"
                            })]
                    }, {
                        beginKeywords: "use",
                        relevance: 0,
                        end: ";",
                        contains: [{
                                match: /\b(as|const|function)\b/,
                                scope: "keyword"
                            }, e.UNDERSCORE_TITLE_MODE]
                    }, c, u]
            }
        },
        grmr_php_template: e => ({
            name: "PHP template",
            subLanguage: "xml",
            contains: [{
                    begin: /<\?(php|=)?/,
                    end: /\?>/,
                    subLanguage: "php",
                    contains: [{
                            begin: "/\\*",
                            end: "\\*/",
                            skip: !0
                        }, {
                            begin: 'b"',
                            end: '"',
                            skip: !0
                        }, {
                            begin: "b'",
                            end: "'",
                            skip: !0
                        }, e.inherit(e.APOS_STRING_MODE, {
                            illegal: null,
                            className: null,
                            contains: null,
                            skip: !0
                        }), e.inherit(e.QUOTE_STRING_MODE, {
                            illegal: null,
                            className: null,
                            contains: null,
                            skip: !0
                        })]
                }
            ]
        }),
        grmr_plaintext: e => ({
            name: "Plain text",
            aliases: ["text", "txt"],
            disableAutodetect: !0
        }),
        grmr_python: e => {
            var t = e.regex,
            n = /[\p{XID_Start}_]\p{XID_Continue}*/u,
            r = ["and", "as", "assert", "async", "await", "break", "case", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "match", "nonlocal|10", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield"],
            i = {
                $pattern: /[A-Za-z]\w+|__\w+__/,
                keyword: r,
                built_in: ["__import__", "abs", "all", "any", "ascii", "bin", "bool", "breakpoint", "bytearray", "bytes", "callable", "chr", "classmethod", "compile", "complex", "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr", "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance", "issubclass", "iter", "len", "list", "locals", "map", "max", "memoryview", "min", "next", "object", "oct", "open", "ord", "pow", "print", "property", "range", "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super", "tuple", "type", "vars", "zip"],
                literal: ["__debug__", "Ellipsis", "False", "None", "NotImplemented", "True"],
                type: ["Any", "Callable", "Coroutine", "Dict", "List", "Literal", "Generic", "Optional", "Sequence", "Set", "Tuple", "Type", "Union"]
            },
            a = {
                className: "meta",
                begin: /^(>>>|\.\.\.) /
            },
            s = {
                className: "subst",
                begin: /\{/,
                end: /\}/,
                keywords: i,
                illegal: /#/
            },
            o = {
                begin: /\{\{/,
                relevance: 0
            },
            o = {
                className: "string",
                contains: [e.BACKSLASH_ESCAPE],
                variants: [{
                        begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
                        end: /'''/,
                        contains: [e.BACKSLASH_ESCAPE, a],
                        relevance: 10
                    }, {
                        begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
                        end: /"""/,
                        contains: [e.BACKSLASH_ESCAPE, a],
                        relevance: 10
                    }, {
                        begin: /([fF][rR]|[rR][fF]|[fF])'''/,
                        end: /'''/,
                        contains: [e.BACKSLASH_ESCAPE, a, o, s]
                    }, {
                        begin: /([fF][rR]|[rR][fF]|[fF])"""/,
                        end: /"""/,
                        contains: [e.BACKSLASH_ESCAPE, a, o, s]
                    }, {
                        begin: /([uU]|[rR])'/,
                        end: /'/,
                        relevance: 10
                    }, {
                        begin: /([uU]|[rR])"/,
                        end: /"/,
                        relevance: 10
                    }, {
                        begin: /([bB]|[bB][rR]|[rR][bB])'/,
                        end: /'/
                    }, {
                        begin: /([bB]|[bB][rR]|[rR][bB])"/,
                        end: /"/
                    }, {
                        begin: /([fF][rR]|[rR][fF]|[fF])'/,
                        end: /'/,
                        contains: [e.BACKSLASH_ESCAPE, o, s]
                    }, {
                        begin: /([fF][rR]|[rR][fF]|[fF])"/,
                        end: /"/,
                        contains: [e.BACKSLASH_ESCAPE, o, s]
                    }, e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
            },
            l = "[0-9](_?[0-9])*",
            c = `(\\b(${l}))?\\.(${l})|\\b(${l})\\.`,
            r = "\\b|" + r.join("|"),
            c = {
                className: "number",
                relevance: 0,
                variants: [{
                        begin: `(\\b(${l})|(${c}))[eE][+-]?(${l})[jJ]?(?=${r})`
                    }, {
                        begin: `(${c})[jJ]?`
                    }, {
                        begin: `\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=${r})`
                    }, {
                        begin: `\\b0[bB](_?[01])+[lL]?(?=${r})`
                    }, {
                        begin: `\\b0[oO](_?[0-7])+[lL]?(?=${r})`
                    }, {
                        begin: `\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=${r})`
                    }, {
                        begin: `\\b(${l})[jJ](?=${r})`
                    }
                ]
            },
            l = {
                className: "comment",
                begin: t.lookahead(/# type:/),
                end: /$/,
                keywords: i,
                contains: [{
                        begin: /# type:/
                    }, {
                        begin: /#/,
                        end: /\b\B/,
                        endsWithParent: !0
                    }
                ]
            },
            r = {
                className: "params",
                variants: [{
                        className: "",
                        begin: /\(\s*\)/,
                        skip: !0
                    }, {
                        begin: /\(/,
                        end: /\)/,
                        excludeBegin: !0,
                        excludeEnd: !0,
                        keywords: i,
                        contains: ["self", a, c, o, e.HASH_COMMENT_MODE]
                    }
                ]
            };
            return s.contains = [o, c, a], {
                name: "Python",
                aliases: ["py", "gyp", "ipython"],
                unicodeRegex: !0,
                keywords: i,
                illegal: /(<\/|->|\?)|=>/,
                contains: [a, c, {
                        begin: /\bself\b/
                    }, {
                        beginKeywords: "if",
                        relevance: 0
                    }, o, l, e.HASH_COMMENT_MODE, {
                        match: [/\bdef/, /\s+/, n],
                        scope: {
                            1: "keyword",
                            3: "title.function"
                        },
                        contains: [r]
                    }, {
                        variants: [{
                                match: [/\bclass/, /\s+/, n, /\s*/, /\(\s*/, n, /\s*\)/]
                            }, {
                                match: [/\bclass/, /\s+/, n]
                            }
                        ],
                        scope: {
                            1: "keyword",
                            3: "title.class",
                            6: "title.class.inherited"
                        }
                    }, {
                        className: "meta",
                        begin: /^[\t ]*@/,
                        end: /(?=#)|$/,
                        contains: [c, r, o]
                    }
                ]
            }
        },
        grmr_python_repl: e => ({
            aliases: ["pycon"],
            contains: [{
                    className: "meta.prompt",
                    starts: {
                        end: / |$/,
                        starts: {
                            end: "$",
                            subLanguage: "python"
                        }
                    },
                    variants: [{
                            begin: /^>>>(?=[ ]|$)/
                        }, {
                            begin: /^\.\.\.(?=[ ]|$)/
                        }
                    ]
                }
            ]
        }),
        grmr_r: e => {
            var t = e.regex,
            n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/,
            r = t.either(/0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/, /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/, /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/),
            i = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/,
            a = t.either(/[()]/, /[{}]/, /\[\[/, /[[\]]/, /\\/, /,/);
            return {
                name: "R",
                keywords: {
                    $pattern: n,
                    keyword: "function if in break next repeat else for while",
                    literal: "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
                    built_in: "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm"
                },
                contains: [e.COMMENT(/#'/, /$/, {
                        contains: [{
                                scope: "doctag",
                                match: /@examples/,
                                starts: {
                                    end: t.lookahead(t.either(/\n^#'\s*(?=@[a-zA-Z]+)/, /\n^(?!#')/)),
                                    endsParent: !0
                                }
                            }, {
                                scope: "doctag",
                                begin: "@param",
                                end: /$/,
                                contains: [{
                                        scope: "variable",
                                        variants: [{
                                                match: n
                                            }, {
                                                match: /`(?:\\.|[^`\\])+`/
                                            }
                                        ],
                                        endsParent: !0
                                    }
                                ]
                            }, {
                                scope: "doctag",
                                match: /@[a-zA-Z]+/
                            }, {
                                scope: "keyword",
                                match: /\\[a-zA-Z]+/
                            }
                        ]
                    }), e.HASH_COMMENT_MODE, {
                        scope: "string",
                        contains: [e.BACKSLASH_ESCAPE],
                        variants: [e.END_SAME_AS_BEGIN({
                                begin: /[rR]"(-*)\(/,
                                end: /\)(-*)"/
                            }), e.END_SAME_AS_BEGIN({
                                begin: /[rR]"(-*)\{/,
                                end: /\}(-*)"/
                            }), e.END_SAME_AS_BEGIN({
                                begin: /[rR]"(-*)\[/,
                                end: /\](-*)"/
                            }), e.END_SAME_AS_BEGIN({
                                begin: /[rR]'(-*)\(/,
                                end: /\)(-*)'/
                            }), e.END_SAME_AS_BEGIN({
                                begin: /[rR]'(-*)\{/,
                                end: /\}(-*)'/
                            }), e.END_SAME_AS_BEGIN({
                                begin: /[rR]'(-*)\[/,
                                end: /\](-*)'/
                            }), {
                                begin: '"',
                                end: '"',
                                relevance: 0
                            }, {
                                begin: "'",
                                end: "'",
                                relevance: 0
                            }
                        ]
                    }, {
                        relevance: 0,
                        variants: [{
                                scope: {
                                    1: "operator",
                                    2: "number"
                                },
                                match: [i, r]
                            }, {
                                scope: {
                                    1: "operator",
                                    2: "number"
                                },
                                match: [/%[^%]*%/, r]
                            }, {
                                scope: {
                                    1: "punctuation",
                                    2: "number"
                                },
                                match: [a, r]
                            }, {
                                scope: {
                                    2: "number"
                                },
                                match: [/[^a-zA-Z0-9._]|^/, r]
                            }
                        ]
                    }, {
                        scope: {
                            3: "operator"
                        },
                        match: [n, /\s+/, /<-/, /\s+/]
                    }, {
                        scope: "operator",
                        relevance: 0,
                        variants: [{
                                match: i
                            }, {
                                match: /%[^%]*%/
                            }
                        ]
                    }, {
                        scope: "punctuation",
                        relevance: 0,
                        match: a
                    }, {
                        begin: "`",
                        end: "`",
                        contains: [{
                                begin: /\\./
                            }
                        ]
                    }
                ]
            }
        },
        grmr_ruby: e => {
            var t = e.regex,
            n = "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)",
            r = t.either(/\b([A-Z]+[a-z0-9]+)+/, /\b([A-Z]+[a-z0-9]+)+[A-Z]+/),
            r = t.concat(r, /(::\w+)*/),
            i = {
                "variable.constant": ["__FILE__", "__LINE__"],
                "variable.language": ["self", "super"],
                keyword: ["alias", "and", "attr_accessor", "attr_reader", "attr_writer", "begin", "BEGIN", "break", "case", "class", "defined", "do", "else", "elsif", "end", "END", "ensure", "for", "if", "in", "include", "module", "next", "not", "or", "redo", "require", "rescue", "retry", "return", "then", "undef", "unless", "until", "when", "while", "yield"],
                built_in: ["proc", "lambda"],
                literal: ["true", "false", "nil"]
            },
            a = {
                className: "doctag",
                begin: "@[A-Za-z]+"
            },
            s = {
                begin: "#<",
                end: ">"
            },
            a = [e.COMMENT("#", "$", {
                    contains: [a]
                }), e.COMMENT("^=begin", "^=end", {
                    contains: [a],
                    relevance: 10
                }), e.COMMENT("^__END__", e.MATCH_NOTHING_RE)],
            o = {
                className: "subst",
                begin: /#\{/,
                end: /\}/,
                keywords: i
            },
            t = {
                className: "string",
                contains: [e.BACKSLASH_ESCAPE, o],
                variants: [{
                        begin: /'/,
                        end: /'/
                    }, {
                        begin: /"/,
                        end: /"/
                    }, {
                        begin: /`/,
                        end: /`/
                    }, {
                        begin: /%[qQwWx]?\(/,
                        end: /\)/
                    }, {
                        begin: /%[qQwWx]?\[/,
                        end: /\]/
                    }, {
                        begin: /%[qQwWx]?\{/,
                        end: /\}/
                    }, {
                        begin: /%[qQwWx]?</,
                        end: />/
                    }, {
                        begin: /%[qQwWx]?\//,
                        end: /\//
                    }, {
                        begin: /%[qQwWx]?%/,
                        end: /%/
                    }, {
                        begin: /%[qQwWx]?-/,
                        end: /-/
                    }, {
                        begin: /%[qQwWx]?\|/,
                        end: /\|/
                    }, {
                        begin: /\B\?(\\\d{1,3})/
                    }, {
                        begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/
                    }, {
                        begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/
                    }, {
                        begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/
                    }, {
                        begin: /\B\?\\(c|C-)[\x20-\x7e]/
                    }, {
                        begin: /\B\?\\?\S/
                    }, {
                        begin: t.concat(/<<[-~]?'?/, t.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)),
                        contains: [e.END_SAME_AS_BEGIN({
                                begin: /(\w+)/,
                                end: /(\w+)/,
                                contains: [e.BACKSLASH_ESCAPE, o]
                            })]
                    }
                ]
            },
            l = "[0-9](_?[0-9])*",
            l = {
                className: "number",
                relevance: 0,
                variants: [{
                        begin: `\\b([1-9](_?[0-9])*|0)(\\.(${l}))?([eE][+-]?(${l})|r)?i?\\b`
                    }, {
                        begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b"
                    }, {
                        begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b"
                    }, {
                        begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b"
                    }, {
                        begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b"
                    }, {
                        begin: "\\b0(_?[0-7])+r?i?\\b"
                    }
                ]
            },
            c = {
                variants: [{
                        match: /\(\)/
                    }, {
                        className: "params",
                        begin: /\(/,
                        end: /(?=\))/,
                        excludeBegin: !0,
                        endsParent: !0,
                        keywords: i
                    }
                ]
            },
            r = [t, {
                    variants: [{
                            match: [/class\s+/, r, /\s+<\s+/, r]
                        }, {
                            match: [/class\s+/, r]
                        }
                    ],
                    scope: {
                        2: "title.class",
                        4: "title.class.inherited"
                    },
                    keywords: i
                }, {
                    relevance: 0,
                    match: [r, /\.new[ (]/],
                    scope: {
                        1: "title.class"
                    }
                }, {
                    relevance: 0,
                    match: /\b[A-Z][A-Z_0-9]+\b/,
                    className: "variable.constant"
                }, {
                    match: [/def/, /\s+/, n],
                    scope: {
                        1: "keyword",
                        3: "title.function"
                    },
                    contains: [c]
                }, {
                    begin: e.IDENT_RE + "::"
                }, {
                    className: "symbol",
                    begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
                    relevance: 0
                }, {
                    className: "symbol",
                    begin: ":(?!\\s)",
                    contains: [t, {
                            begin: n
                        }
                    ],
                    relevance: 0
                }, l, {
                    className: "variable",
                    begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])"
                }, {
                    className: "params",
                    begin: /\|/,
                    end: /\|/,
                    excludeBegin: !0,
                    excludeEnd: !0,
                    relevance: 0,
                    keywords: i
                }, {
                    begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
                    keywords: "unless",
                    contains: [{
                            className: "regexp",
                            contains: [e.BACKSLASH_ESCAPE, o],
                            illegal: /\n/,
                            variants: [{
                                    begin: "/",
                                    end: "/[a-z]*"
                                }, {
                                    begin: /%r\{/,
                                    end: /\}[a-z]*/
                                }, {
                                    begin: "%r\\(",
                                    end: "\\)[a-z]*"
                                }, {
                                    begin: "%r!",
                                    end: "![a-z]*"
                                }, {
                                    begin: "%r\\[",
                                    end: "\\][a-z]*"
                                }
                            ]
                        }
                    ].concat(s, a),
                    relevance: 0
                }
            ].concat(s, a),
            t = (o.contains = r, [{
                        begin: /^\s*=>/,
                        starts: {
                            end: "$",
                            contains: c.contains = r
                        }
                    }, {
                        className: "meta.prompt",
                        begin: "^([>?]>|[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]|(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>)(?=[ ])",
                        starts: {
                            end: "$",
                            keywords: i,
                            contains: r
                        }
                    }
                ]);
            return a.unshift(s), {
                name: "Ruby",
                aliases: ["rb", "gemspec", "podspec", "thor", "irb"],
                keywords: i,
                illegal: /\/\*/,
                contains: [e.SHEBANG({
                        binary: "ruby"
                    })].concat(t).concat(a).concat(r)
            }
        },
        grmr_rust: e => {
            var t = e.regex,
            t = {
                className: "title.function.invoke",
                relevance: 0,
                begin: t.concat(/\b/, /(?!let\b)/, e.IDENT_RE, t.lookahead(/\s*\(/))
            },
            n = "([ui](8|16|32|64|128|size)|f(32|64))?",
            r = ["drop ", "Copy", "Send", "Sized", "Sync", "Drop", "Fn", "FnMut", "FnOnce", "ToOwned", "Clone", "Debug", "PartialEq", "PartialOrd", "Eq", "Ord", "AsRef", "AsMut", "Into", "From", "Default", "Iterator", "Extend", "IntoIterator", "DoubleEndedIterator", "ExactSizeIterator", "SliceConcatExt", "ToString", "assert!", "assert_eq!", "bitflags!", "bytes!", "cfg!", "col!", "concat!", "concat_idents!", "debug_assert!", "debug_assert_eq!", "env!", "panic!", "file!", "format!", "format_args!", "include_bytes!", "include_str!", "line!", "local_data_key!", "module_path!", "option_env!", "print!", "println!", "select!", "stringify!", "try!", "unimplemented!", "unreachable!", "vec!", "write!", "writeln!", "macro_rules!", "assert_ne!", "debug_assert_ne!"],
            i = ["i8", "i16", "i32", "i64", "i128", "isize", "u8", "u16", "u32", "u64", "u128", "usize", "f32", "f64", "str", "char", "bool", "Box", "Option", "Result", "String", "Vec"];
            return {
                name: "Rust",
                aliases: ["rs"],
                keywords: {
                    $pattern: e.IDENT_RE + "!?",
                    type: i,
                    keyword: ["abstract", "as", "async", "await", "become", "box", "break", "const", "continue", "crate", "do", "dyn", "else", "enum", "extern", "false", "final", "fn", "for", "if", "impl", "in", "let", "loop", "macro", "match", "mod", "move", "mut", "override", "priv", "pub", "ref", "return", "self", "Self", "static", "struct", "super", "trait", "true", "try", "type", "typeof", "unsafe", "unsized", "use", "virtual", "where", "while", "yield"],
                    literal: ["true", "false", "Some", "None", "Ok", "Err"],
                    built_in: r
                },
                illegal: "</",
                contains: [e.C_LINE_COMMENT_MODE, e.COMMENT("/\\*", "\\*/", {
                        contains: ["self"]
                    }), e.inherit(e.QUOTE_STRING_MODE, {
                        begin: /b?"/,
                        illegal: null
                    }), {
                        className: "string",
                        variants: [{
                                begin: /b?r(#*)"(.|\n)*?"\1(?!#)/
                            }, {
                                begin: /b?'\\?(x\w{2}|u\w{4}|U\w{8}|.)'/
                            }
                        ]
                    }, {
                        className: "symbol",
                        begin: /'[a-zA-Z_][a-zA-Z0-9_]*/
                    }, {
                        className: "number",
                        variants: [{
                                begin: "\\b0b([01_]+)" + n
                            }, {
                                begin: "\\b0o([0-7_]+)" + n
                            }, {
                                begin: "\\b0x([A-Fa-f0-9_]+)" + n
                            }, {
                                begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + n
                            }
                        ],
                        relevance: 0
                    }, {
                        begin: [/fn/, /\s+/, e.UNDERSCORE_IDENT_RE],
                        className: {
                            1: "keyword",
                            3: "title.function"
                        }
                    }, {
                        className: "meta",
                        begin: "#!?\\[",
                        end: "\\]",
                        contains: [{
                                className: "string",
                                begin: /"/,
                                end: /"/
                            }
                        ]
                    }, {
                        begin: [/let/, /\s+/, /(?:mut\s+)?/, e.UNDERSCORE_IDENT_RE],
                        className: {
                            1: "keyword",
                            3: "keyword",
                            4: "variable"
                        }
                    }, {
                        begin: [/for/, /\s+/, e.UNDERSCORE_IDENT_RE, /\s+/, /in/],
                        className: {
                            1: "keyword",
                            3: "variable",
                            5: "keyword"
                        }
                    }, {
                        begin: [/type/, /\s+/, e.UNDERSCORE_IDENT_RE],
                        className: {
                            1: "keyword",
                            3: "title.class"
                        }
                    }, {
                        begin: [/(?:trait|enum|struct|union|impl|for)/, /\s+/, e.UNDERSCORE_IDENT_RE],
                        className: {
                            1: "keyword",
                            3: "title.class"
                        }
                    }, {
                        begin: e.IDENT_RE + "::",
                        keywords: {
                            keyword: "Self",
                            built_in: r,
                            type: i
                        }
                    }, {
                        className: "punctuation",
                        begin: "->"
                    }, t]
            }
        },
        grmr_scss: e => {
            var t = m(e),
            n = _,
            r = v,
            i = "@[a-z-]+",
            a = {
                className: "variable",
                begin: "(\\$[a-zA-Z-][a-zA-Z0-9_-]*)\\b",
                relevance: 0
            };
            return {
                name: "SCSS",
                case_insensitive: !0,
                illegal: "[=/|']",
                contains: [e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, t.CSS_NUMBER_MODE, {
                        className: "selector-id",
                        begin: "#[A-Za-z0-9_-]+",
                        relevance: 0
                    }, {
                        className: "selector-class",
                        begin: "\\.[A-Za-z0-9_-]+",
                        relevance: 0
                    }, t.ATTRIBUTE_SELECTOR_MODE, {
                        className: "selector-tag",
                        begin: "\\b(" + b.join("|") + ")\\b",
                        relevance: 0
                    }, {
                        className: "selector-pseudo",
                        begin: ":(" + r.join("|") + ")"
                    }, {
                        className: "selector-pseudo",
                        begin: ":(:)?(" + n.join("|") + ")"
                    }, a, {
                        begin: /\(/,
                        end: /\)/,
                        contains: [t.CSS_NUMBER_MODE]
                    }, t.CSS_VARIABLE, {
                        className: "attribute",
                        begin: "\\b(" + E.join("|") + ")\\b"
                    }, {
                        begin: "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b"
                    }, {
                        begin: /:/,
                        end: /[;}{]/,
                        relevance: 0,
                        contains: [t.BLOCK_COMMENT, a, t.HEXCOLOR, t.CSS_NUMBER_MODE, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, t.IMPORTANT, t.FUNCTION_DISPATCH]
                    }, {
                        begin: "@(page|font-face)",
                        keywords: {
                            $pattern: i,
                            keyword: "@page @font-face"
                        }
                    }, {
                        begin: "@",
                        end: "[{;]",
                        returnBegin: !0,
                        keywords: {
                            $pattern: /[a-z-]+/,
                            keyword: "and or not only",
                            attribute: y.join(" ")
                        },
                        contains: [{
                                begin: i,
                                className: "keyword"
                            }, {
                                begin: /[a-z-]+(?=:)/,
                                className: "attribute"
                            }, a, e.QUOTE_STRING_MODE, e.APOS_STRING_MODE, t.HEXCOLOR, t.CSS_NUMBER_MODE]
                    }, t.FUNCTION_DISPATCH]
            }
        },
        grmr_shell: e => ({
            name: "Shell Session",
            aliases: ["console", "shellsession"],
            contains: [{
                    className: "meta.prompt",
                    begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
                    starts: {
                        end: /[^\\](?=\s*$)/,
                        subLanguage: "bash"
                    }
                }
            ]
        }),
        grmr_sql: e => {
            const t = e.regex,
            n = e.COMMENT("--", "$"),
            r = ["true", "false", "unknown"],
            i = ["bigint", "binary", "blob", "boolean", "char", "character", "clob", "date", "dec", "decfloat", "decimal", "float", "int", "integer", "interval", "nchar", "nclob", "national", "numeric", "real", "row", "smallint", "time", "timestamp", "varchar", "varying", "varbinary"],
            a = ["abs", "acos", "array_agg", "asin", "atan", "avg", "cast", "ceil", "ceiling", "coalesce", "corr", "cos", "cosh", "count", "covar_pop", "covar_samp", "cume_dist", "dense_rank", "deref", "element", "exp", "extract", "first_value", "floor", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "last_value", "lead", "listagg", "ln", "log", "log10", "lower", "max", "min", "mod", "nth_value", "ntile", "nullif", "percent_rank", "percentile_cont", "percentile_disc", "position", "position_regex", "power", "rank", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "row_number", "sin", "sinh", "sqrt", "stddev_pop", "stddev_samp", "substring", "substring_regex", "sum", "tan", "tanh", "translate", "translate_regex", "treat", "trim", "trim_array", "unnest", "upper", "value_of", "var_pop", "var_samp", "width_bucket"],
            s = ["create table", "insert into", "primary key", "foreign key", "not null", "alter table", "add constraint", "grouping sets", "on overflow", "character set", "respect nulls", "ignore nulls", "nulls first", "nulls last", "depth first", "breadth first"],
            o = a,
            l = ["abs", "acos", "all", "allocate", "alter", "and", "any", "are", "array", "array_agg", "array_max_cardinality", "as", "asensitive", "asin", "asymmetric", "at", "atan", "atomic", "authorization", "avg", "begin", "begin_frame", "begin_partition", "between", "bigint", "binary", "blob", "boolean", "both", "by", "call", "called", "cardinality", "cascaded", "case", "cast", "ceil", "ceiling", "char", "char_length", "character", "character_length", "check", "classifier", "clob", "close", "coalesce", "collate", "collect", "column", "commit", "condition", "connect", "constraint", "contains", "convert", "copy", "corr", "corresponding", "cos", "cosh", "count", "covar_pop", "covar_samp", "create", "cross", "cube", "cume_dist", "current", "current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_row", "current_schema", "current_time", "current_timestamp", "current_path", "current_role", "current_transform_group_for_type", "current_user", "cursor", "cycle", "date", "day", "deallocate", "dec", "decimal", "decfloat", "declare", "default", "define", "delete", "dense_rank", "deref", "describe", "deterministic", "disconnect", "distinct", "double", "drop", "dynamic", "each", "element", "else", "empty", "end", "end_frame", "end_partition", "end-exec", "equals", "escape", "every", "except", "exec", "execute", "exists", "exp", "external", "extract", "false", "fetch", "filter", "first_value", "float", "floor", "for", "foreign", "frame_row", "free", "from", "full", "function", "fusion", "get", "global", "grant", "group", "grouping", "groups", "having", "hold", "hour", "identity", "in", "indicator", "initial", "inner", "inout", "insensitive", "insert", "int", "integer", "intersect", "intersection", "interval", "into", "is", "join", "json_array", "json_arrayagg", "json_exists", "json_object", "json_objectagg", "json_query", "json_table", "json_table_primitive", "json_value", "lag", "language", "large", "last_value", "lateral", "lead", "leading", "left", "like", "like_regex", "listagg", "ln", "local", "localtime", "localtimestamp", "log", "log10", "lower", "match", "match_number", "match_recognize", "matches", "max", "member", "merge", "method", "min", "minute", "mod", "modifies", "module", "month", "multiset", "national", "natural", "nchar", "nclob", "new", "no", "none", "normalize", "not", "nth_value", "ntile", "null", "nullif", "numeric", "octet_length", "occurrences_regex", "of", "offset", "old", "omit", "on", "one", "only", "open", "or", "order", "out", "outer", "over", "overlaps", "overlay", "parameter", "partition", "pattern", "per", "percent", "percent_rank", "percentile_cont", "percentile_disc", "period", "portion", "position", "position_regex", "power", "precedes", "precision", "prepare", "primary", "procedure", "ptf", "range", "rank", "reads", "real", "recursive", "ref", "references", "referencing", "regr_avgx", "regr_avgy", "regr_count", "regr_intercept", "regr_r2", "regr_slope", "regr_sxx", "regr_sxy", "regr_syy", "release", "result", "return", "returns", "revoke", "right", "rollback", "rollup", "row", "row_number", "rows", "running", "savepoint", "scope", "scroll", "search", "second", "seek", "select", "sensitive", "session_user", "set", "show", "similar", "sin", "sinh", "skip", "smallint", "some", "specific", "specifictype", "sql", "sqlexception", "sqlstate", "sqlwarning", "sqrt", "start", "static", "stddev_pop", "stddev_samp", "submultiset", "subset", "substring", "substring_regex", "succeeds", "sum", "symmetric", "system", "system_time", "system_user", "table", "tablesample", "tan", "tanh", "then", "time", "timestamp", "timezone_hour", "timezone_minute", "to", "trailing", "translate", "translate_regex", "translation", "treat", "trigger", "trim", "trim_array", "true", "truncate", "uescape", "union", "unique", "unknown", "unnest", "update", "upper", "user", "using", "value", "values", "value_of", "var_pop", "var_samp", "varbinary", "varchar", "varying", "versioning", "when", "whenever", "where", "width_bucket", "window", "with", "within", "without", "year", "add", "asc", "collation", "desc", "final", "first", "last", "view"].filter(e => !a.includes(e)),
            c = {
                begin: t.concat(/\b/, t.either(...o), /\s*\(/),
                relevance: 0,
                keywords: {
                    built_in: o
                }
            };
            return {
                name: "SQL",
                case_insensitive: !0,
                illegal: /[{}]|<\//,
                keywords: {
                    $pattern: /\b[\w\.]+/,
                    keyword: (({
                            exceptions: t,
                            when: e
                        }) => {
                        const n = e;
                        return t = t || [],
                        l.map(e => !e.match(/\|\d+$/) && !t.includes(e) && n(e) ? e + "|0" : e)
                    })({
                        when: e => e.length < 3
                    }),
                    literal: r,
                    type: i,
                    built_in: ["current_catalog", "current_date", "current_default_transform_group", "current_path", "current_role", "current_schema", "current_transform_group_for_type", "current_user", "session_user", "system_time", "system_user", "current_time", "localtime", "current_timestamp", "localtimestamp"]
                },
                contains: [{
                        begin: t.either(...s),
                        relevance: 0,
                        keywords: {
                            $pattern: /[\w\.]+/,
                            keyword: l.concat(s),
                            literal: r,
                            type: i
                        }
                    }, {
                        className: "type",
                        begin: t.either("double precision", "large object", "with timezone", "without timezone")
                    }, c, {
                        className: "variable",
                        begin: /@[a-z0-9]+/
                    }, {
                        className: "string",
                        variants: [{
                                begin: /'/,
                                end: /'/,
                                contains: [{
                                        begin: /''/
                                    }
                                ]
                            }
                        ]
                    }, {
                        begin: /"/,
                        end: /"/,
                        contains: [{
                                begin: /""/
                            }
                        ]
                    }, e.C_NUMBER_MODE, e.C_BLOCK_COMMENT_MODE, n, {
                        className: "operator",
                        begin: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
                        relevance: 0
                    }
                ]
            }
        },
        grmr_swift: e => {
            const t = {
                match: /\s+/,
                relevance: 0
            },
            n = e.COMMENT("/\\*", "\\*/", {
                contains: ["self"]
            }),
            r = [e.C_LINE_COMMENT_MODE, n],
            i = {
                match: [/\./, I(...me, ...be)],
                className: {
                    2: "keyword"
                }
            },
            a = {
                match: R(/\./, I(...j)),
                relevance: 0
            },
            s = j.filter(e => "string" == typeof e).concat(["_|0"]),
            o = {
                variants: [{
                        className: "keyword",
                        match: I(...j.filter(e => "string" != typeof e).concat(ye).map(O), ...be)
                    }
                ]
            },
            l = {
                $pattern: I(/\b\w+/, /#\w+/),
                keyword: s.concat(Ee),
                literal: ve
            },
            c = [i, a, o],
            u = [{
                    match: R(/\./, I(...we)),
                    relevance: 0
                }, {
                    className: "built_in",
                    match: R(/\b/, I(...we), /(?=\()/)
                }
            ],
            d = {
                match: /->/,
                relevance: 0
            },
            p = [d, {
                    className: "operator",
                    relevance: 0,
                    variants: [{
                            match: $
                        }, {
                            match: `\\.(\\.|${Ne})+`
                        }
                    ]
                }
            ],
            g = "([0-9a-fA-F]_*)+",
            f = {
                className: "number",
                relevance: 0,
                variants: [{
                        match: "\\b(([0-9]_*)+)(\\.(([0-9]_*)+))?([eE][+-]?(([0-9]_*)+))?\\b"
                    }, {
                        match: `\\b0x(${g})(\\.(${g}))?([pP][+-]?(([0-9]_*)+))?\\b`
                    }, {
                        match: /\b0o([0-7]_*)+\b/
                    }, {
                        match: /\b0b([01]_*)+\b/
                    }
                ]
            },
            h = (e = "") => ({
                className: "subst",
                variants: [{
                        match: R(/\\/, e, /[0\\tnr"']/)
                    }, {
                        match: R(/\\/, e, /u\{[0-9a-fA-F]{1,8}\}/)
                    }
                ]
            }),
            m = (e = "") => ({
                className: "subst",
                label: "interpol",
                begin: R(/\\/, e, /\(/),
                end: /\)/
            }),
            b = (e = "") => {
                return {
                    begin: R(e, /"""/),
                    end: R(/"""/, e),
                    contains: [h(e), ([t = ""] = [e], {
                            className: "subst",
                            match: R(/\\/, t, /[\t ]*(?:[\r\n]|\r\n)/)
                        }), m(e)]
                };
                var t
            },
            y = (e = "") => ({
                begin: R(e, /"/),
                end: R(/"/, e),
                contains: [h(e), m(e)]
            }),
            v = {
                className: "string",
                variants: [b(), b("#"), b("##"), b("###"), y(), y("#"), y("##"), y("###")]
            },
            _ = {
                match: R(/`/, P, /`/)
            },
            E = [_, {
                    className: "variable",
                    match: /\$\d+/
                }, {
                    className: "variable",
                    match: `\\$${F}+`
                }
            ],
            w = [{
                    match: /(@|#(un)?)available/,
                    className: "keyword",
                    starts: {
                        contains: [{
                                begin: /\(/,
                                end: /\)/,
                                keywords: Se,
                                contains: [...p, f, v]
                            }
                        ]
                    }
                }, {
                    className: "keyword",
                    match: R(/@/, I(...Ce))
                }, {
                    className: "meta",
                    match: R(/@/, P)
                }
            ],
            x = {
                match: D(/\b[A-Z]/),
                relevance: 0,
                contains: [{
                        className: "type",
                        match: R(/(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/, F, "+")
                    }, {
                        className: "type",
                        match: q,
                        relevance: 0
                    }, {
                        match: /[?!]+/,
                        relevance: 0
                    }, {
                        match: /\.\.\./,
                        relevance: 0
                    }, {
                        match: R(/\s+&\s+/, D(q)),
                        relevance: 0
                    }
                ]
            },
            N = {
                begin: /</,
                end: />/,
                keywords: l,
                contains: [...r, ...c, ...w, d, x]
            };
            x.contains.push(N);
            var k = {
                begin: /\(/,
                end: /\)/,
                relevance: 0,
                keywords: l,
                contains: ["self", {
                        match: R(P, /\s*:/),
                        keywords: "_|0",
                        relevance: 0
                    }, ...r, ...c, ...u, ...p, f, v, ...E, ...w, x]
            },
            C = {
                begin: /</,
                end: />/,
                contains: [...r, x]
            },
            S = {
                begin: /\(/,
                end: /\)/,
                keywords: l,
                contains: [{
                        begin: I(D(R(P, /\s*:/)), D(R(P, /\s+/, P, /\s*:/))),
                        end: /:/,
                        relevance: 0,
                        contains: [{
                                className: "keyword",
                                match: /\b_\b/
                            }, {
                                className: "params",
                                match: P
                            }
                        ]
                    }, ...r, ...c, ...p, f, v, ...w, x, k],
                endsParent: !0,
                illegal: /["']/
            },
            T = {
                match: [/func/, /\s+/, I(_.match, P, $)],
                className: {
                    1: "keyword",
                    3: "title.function"
                },
                contains: [C, S, t],
                illegal: [/\[/, /%/]
            },
            C = {
                match: [/\b(?:subscript|init[?!]?)/, /\s*(?=[<(])/],
                className: {
                    1: "keyword"
                },
                contains: [C, S, t],
                illegal: /\[|%/
            },
            S = {
                match: [/operator/, /\s+/, $],
                className: {
                    1: "keyword",
                    3: "title"
                }
            },
            A = {
                begin: [/precedencegroup/, /\s+/, q],
                className: {
                    1: "keyword",
                    3: "title"
                },
                contains: [x],
                keywords: [..._e, ...ve],
                end: /}/
            };
            for (const e of v.variants) {
                const t = e.contains.find(e => "interpol" === e.label),
                n = (t.keywords = l, [...c, ...u, ...p, f, v, ...E]);
                t.contains = [...n, {
                        begin: /\(/,
                        end: /\)/,
                        contains: ["self", ...n]
                    }
                ]
            }
            return {
                name: "Swift",
                keywords: l,
                contains: [...r, T, C, {
                        beginKeywords: "struct protocol class extension enum actor",
                        end: "\\{",
                        excludeEnd: !0,
                        keywords: l,
                        contains: [e.inherit(e.TITLE_MODE, {
                                className: "title.class",
                                begin: /[A-Za-z$_][\u00C0-\u02B80-9A-Za-z$_]*/
                            }), ...c]
                    }, S, A, {
                        beginKeywords: "import",
                        end: /$/,
                        contains: [...r],
                        relevance: 0
                    }, ...c, ...u, ...p, f, v, ...E, ...w, x, k]
            }
        },
        grmr_typescript: e => {
            var t = he(e),
            n = ["any", "void", "number", "boolean", "string", "object", "never", "symbol", "bigint", "unknown"],
            r = {
                beginKeywords: "namespace",
                end: /\{/,
                excludeEnd: !0,
                contains: [t.exports.CLASS_REFERENCE]
            },
            i = {
                beginKeywords: "interface",
                end: /\{/,
                excludeEnd: !0,
                keywords: {
                    keyword: "interface extends",
                    built_in: n
                },
                contains: [t.exports.CLASS_REFERENCE]
            },
            n = {
                $pattern: C,
                keyword: le.concat(["type", "namespace", "interface", "public", "private", "protected", "implements", "declare", "abstract", "readonly", "enum", "override"]),
                literal: ce,
                built_in: fe.concat(n),
                "variable.language": ge
            },
            a = {
                className: "meta",
                begin: "@[A-Za-z$_][0-9A-Za-z$_]*"
            },
            s = (e, t, n) => {
                var r = e.contains.findIndex(e => e.label === t);
                if (-1 === r)
                    throw Error("can not find mode to replace");
                e.contains.splice(r, 1, n)
            };
            return Object.assign(t.keywords, n),
            t.exports.PARAMS_CONTAINS.push(a),
            t.contains = t.contains.concat([a, r, i]),
            s(t, "shebang", e.SHEBANG()),
            s(t, "use_strict", {
                className: "meta",
                relevance: 10,
                begin: /^\s*['"]use strict['"]/
            }),
            t.contains.find(e => "func.def" === e.label).relevance = 0,
            Object.assign(t, {
                name: "TypeScript",
                aliases: ["ts", "tsx"]
            }),
            t
        },
        grmr_vbnet: e => {
            var t = e.regex,
            n = /\d{1,2}\/\d{1,2}\/\d{4}/,
            r = /\d{4}-\d{1,2}-\d{1,2}/,
            i = /(\d|1[012])(:\d+){0,2} *(AM|PM)/,
            a = /\d{1,2}(:\d{1,2}){1,2}/,
            r = {
                className: "literal",
                variants: [{
                        begin: t.concat(/# */, t.either(r, n), / *#/)
                    }, {
                        begin: t.concat(/# */, a, / *#/)
                    }, {
                        begin: t.concat(/# */, i, / *#/)
                    }, {
                        begin: t.concat(/# */, t.either(r, n), / +/, t.either(i, a), / *#/)
                    }
                ]
            },
            n = e.COMMENT(/'''/, /$/, {
                contains: [{
                        className: "doctag",
                        begin: /<\/?/,
                        end: />/
                    }
                ]
            }),
            t = e.COMMENT(null, /$/, {
                variants: [{
                        begin: /'/
                    }, {
                        begin: /([\t ]|^)REM(?=\s)/
                    }
                ]
            });
            return {
                name: "Visual Basic .NET",
                aliases: ["vb"],
                case_insensitive: !0,
                classNameAliases: {
                    label: "symbol"
                },
                keywords: {
                    keyword: "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
                    built_in: "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort",
                    type: "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort",
                    literal: "true false nothing"
                },
                illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
                contains: [{
                        className: "string",
                        begin: /"(""|[^/n])"C\b/
                    }, {
                        className: "string",
                        begin: /"/,
                        end: /"/,
                        illegal: /\n/,
                        contains: [{
                                begin: /""/
                            }
                        ]
                    }, r, {
                        className: "number",
                        relevance: 0,
                        variants: [{
                                begin: /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/
                            }, {
                                begin: /\b\d[\d_]*((U?[SIL])|[%&])?/
                            }, {
                                begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/
                            }, {
                                begin: /&O[0-7_]+((U?[SIL])|[%&])?/
                            }, {
                                begin: /&B[01_]+((U?[SIL])|[%&])?/
                            }
                        ]
                    }, {
                        className: "label",
                        begin: /^\w+:/
                    }, n, t, {
                        className: "meta",
                        begin: /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
                        end: /$/,
                        keywords: {
                            keyword: "const disable else elseif enable end externalsource if region then"
                        },
                        contains: [t]
                    }
                ]
            }
        },
        grmr_wasm: e => {
            e.regex;
            var t = e.COMMENT(/\(;/, /;\)/);
            return t.contains.push("self"), {
                name: "WebAssembly",
                keywords: {
                    $pattern: /[\w.]+/,
                    keyword: ["anyfunc", "block", "br", "br_if", "br_table", "call", "call_indirect", "data", "drop", "elem", "else", "end", "export", "func", "global.get", "global.set", "local.get", "local.set", "local.tee", "get_global", "get_local", "global", "if", "import", "local", "loop", "memory", "memory.grow", "memory.size", "module", "mut", "nop", "offset", "param", "result", "return", "select", "set_global", "set_local", "start", "table", "tee_local", "then", "type", "unreachable"]
                },
                contains: [e.COMMENT(/;;/, /$/), t, {
                        match: [/(?:offset|align)/, /\s*/, /=/],
                        className: {
                            1: "keyword",
                            3: "operator"
                        }
                    }, {
                        className: "variable",
                        begin: /\$[\w_]+/
                    }, {
                        match: /(\((?!;)|\))+/,
                        className: "punctuation",
                        relevance: 0
                    }, {
                        begin: [/(?:func|call|call_indirect)/, /\s+/, /\$[^\s)]+/],
                        className: {
                            1: "keyword",
                            3: "title.function"
                        }
                    }, e.QUOTE_STRING_MODE, {
                        match: /(i32|i64|f32|f64)(?!\.)/,
                        className: "type"
                    }, {
                        className: "keyword",
                        match: /\b(f32|f64|i32|i64)(?:\.(?:abs|add|and|ceil|clz|const|convert_[su]\/i(?:32|64)|copysign|ctz|demote\/f64|div(?:_[su])?|eqz?|extend_[su]\/i32|floor|ge(?:_[su])?|gt(?:_[su])?|le(?:_[su])?|load(?:(?:8|16|32)_[su])?|lt(?:_[su])?|max|min|mul|nearest|neg?|or|popcnt|promote\/f32|reinterpret\/[fi](?:32|64)|rem_[su]|rot[lr]|shl|shr_[su]|store(?:8|16|32)?|sqrt|sub|trunc(?:_[su]\/f(?:32|64))?|wrap\/i64|xor))\b/
                    }, {
                        className: "number",
                        relevance: 0,
                        match: /[+-]?\b(?:\d(?:_?\d)*(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?|0x[\da-fA-F](?:_?[\da-fA-F])*(?:\.[\da-fA-F](?:_?[\da-fA-D])*)?(?:[pP][+-]?\d(?:_?\d)*)?)\b|\binf\b|\bnan(?::0x[\da-fA-F](?:_?[\da-fA-D])*)?\b/
                    }
                ]
            }
        },
        grmr_yaml: e => {
            var t = "true false yes no null",
            n = "[\\w#;/?:@&=+$,.~*'()[\\]]+",
            r = {
                className: "string",
                relevance: 0,
                variants: [{
                        begin: /'/,
                        end: /'/
                    }, {
                        begin: /"/,
                        end: /"/
                    }, {
                        begin: /\S+/
                    }
                ],
                contains: [e.BACKSLASH_ESCAPE, {
                        className: "template-variable",
                        variants: [{
                                begin: /\{\{/,
                                end: /\}\}/
                            }, {
                                begin: /%\{/,
                                end: /\}/
                            }
                        ]
                    }
                ]
            },
            i = e.inherit(r, {
                variants: [{
                        begin: /'/,
                        end: /'/
                    }, {
                        begin: /"/,
                        end: /"/
                    }, {
                        begin: /[^\s,{}[\]]+/
                    }
                ]
            }),
            a = {
                end: ",",
                endsWithParent: !0,
                excludeEnd: !0,
                keywords: t,
                relevance: 0
            },
            n = [{
                    className: "attr",
                    variants: [{
                            begin: "\\w[\\w :\\/.-]*:(?=[ \t]|$)"
                        }, {
                            begin: '"\\w[\\w :\\/.-]*":(?=[ \t]|$)'
                        }, {
                            begin: "'\\w[\\w :\\/.-]*':(?=[ \t]|$)"
                        }
                    ]
                }, {
                    className: "meta",
                    begin: "^---\\s*$",
                    relevance: 10
                }, {
                    className: "string",
                    begin: "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"
                }, {
                    begin: "<%[%=-]?",
                    end: "[%-]?%>",
                    subLanguage: "ruby",
                    excludeBegin: !0,
                    excludeEnd: !0,
                    relevance: 0
                }, {
                    className: "type",
                    begin: "!\\w+!" + n
                }, {
                    className: "type",
                    begin: "!<" + n + ">"
                }, {
                    className: "type",
                    begin: "!" + n
                }, {
                    className: "type",
                    begin: "!!" + n
                }, {
                    className: "meta",
                    begin: "&" + e.UNDERSCORE_IDENT_RE + "$"
                }, {
                    className: "meta",
                    begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$"
                }, {
                    className: "bullet",
                    begin: "-(?=[ ]|$)",
                    relevance: 0
                }, e.HASH_COMMENT_MODE, {
                    beginKeywords: t,
                    keywords: {
                        literal: t
                    }
                }, {
                    className: "number",
                    begin: "\\b[0-9]{4}(-[0-9][0-9]){0,2}([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?(\\.[0-9]*)?([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?\\b"
                }, {
                    className: "number",
                    begin: e.C_NUMBER_RE + "\\b",
                    relevance: 0
                }, {
                    begin: /\{/,
                    end: /\}/,
                    contains: [a],
                    illegal: "\\n",
                    relevance: 0
                }, {
                    begin: "\\[",
                    end: "\\]",
                    contains: [a],
                    illegal: "\\n",
                    relevance: 0
                }, r],
            t = [...n];
            return t.pop(),
            t.push(i),
            a.contains = t, {
                name: "YAML",
                case_insensitive: !0,
                aliases: ["yml"],
                contains: n
            }
        }
    }),
    Ae = s;
    for (const p of Object.keys(Te)) {
        const n = p.replace("grmr_", "").replace("_", "-");
        Ae.registerLanguage(n, Te[p])
    }
    return Ae
}
();
"object" == typeof exports && "undefined" != typeof module && (module.exports = hljs), jQuery(function (a) {
    var s = a("html"),
    t = a(window);
    function e() {
        s.toggleClass("menu-active")
    }
    a("#menu").on({
        click: function () {
            e()
        }
    }),
    a(".nav-menu").on({
        click: function () {
            e()
        }
    }),
    a(".nav-close").on({
        click: function () {
            e()
        }
    }),
    t.on({
        resize: function () {
            s.removeClass("menu-active")
        },
        orientationchange: function () {
            s.removeClass("menu-active")
        }
    });
    var n = a(".cover"),
    r = 0;
    function i() {
        var e;
        1 <= n.length && (e = t.scrollTop(), r = 0 < e ? Math.floor(.25 * e) : 0, n.css({
                "-webkit-transform": "translate3d(0, " + r + "px, 0)",
                transform: "translate3d(0, " + r + "px, 0)"
            }), t.scrollTop() < n.height() ? s.addClass("cover-active") : s.removeClass("cover-active"))
    }
    i(),
    t.on({
        scroll: function () {
            i()
        },
        resize: function () {
            i()
        },
        orientationchange: function () {
            i()
        }
    }),
    function () {
        "use strict";
        document.querySelectorAll(".kg-gallery-image img").forEach(function (e) {
            var t = e.closest(".kg-gallery-image"),
            n = e.attributes.width.value,
            e = e.attributes.height.value;
            t.style.flex = n / e + " 1 0%"
        })
    }
    (),
    function () {
        "use strict";
        var e = a(".js-theme"),
        t = e.find(".theme-text");
        function n() {
            s.removeClass(["theme-dark", "theme-light"]),
            localStorage.removeItem("attila_theme"),
            t.text(e.attr("data-system"))
        }
        function r() {
            s.removeClass("theme-light").addClass("theme-dark"),
            localStorage.setItem("attila_theme", "dark"),
            t.text(e.attr("data-dark"))
        }
        function i() {
            s.removeClass("theme-dark").addClass("theme-light"),
            localStorage.setItem("attila_theme", "light"),
            t.text(e.attr("data-light"))
        }
        switch (localStorage.getItem("attila_theme")) {
        case "dark":
            r();
            break;
        case "light":
            i();
            break;
        default:
            n()
        }
        e.on("click", function (e) {
            e.preventDefault(),
            (s.hasClass("theme-dark") || s.hasClass("theme-light") ? s.hasClass("theme-dark") ? i : n : r)()
        })
    }
    ()
    // Mobile-friendly dropdown menu handling
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('.menu-item-has-children > a').forEach(parent => {
            parent.addEventListener('click', function (e) {
                if (window.innerWidth <= 768) { // Only for mobile screens
                    e.preventDefault();
                    let submenu = this.nextElementSibling;
                    submenu.classList.toggle('submenu-open'); // Toggle class instead of display
                }
            });
        });
    });
});
